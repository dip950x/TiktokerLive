function init() {
    const width = 300;
    const height = 300;

    // حدود الماسك الفعلية
    const maskTop = 95;
    const maskBottom = 230;
    const maskHeight = maskBottom - maskTop;

    // فقاعات
    const bubblesGroup = document.getElementById("bubbles");
    const bubbles = [];

    const progressText = document.getElementById("progressText");

    // 💾 تحميل الهدف من localStorage فوراً (تجنب عرض 50 كقيمة افتراضية)
    const cachedGoalValue = localStorage.getItem('heart_me_goal_value');
    const cachedCurrentValue = localStorage.getItem('heart_me_goal_current');

    let goalValue = cachedGoalValue ? parseInt(cachedGoalValue) : 50;
    let currentValue = cachedCurrentValue ? parseInt(cachedCurrentValue) : 0;
    let isTestRunning = false; // متغير لمنع تشغيل اختبارات متعددة
    let widgetReady = false; // حالة جاهزية الويدجت للعرض



    // الحصول على التوكن من URL
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');

    // ====== دالة إظهار الويدجت بعد اكتمال التحميل ======
    function showWidget() {
        if (!widgetReady) {
            widgetReady = true;
            document.body.classList.add('loaded');

        }
    }

    // تحميل الإعدادات والقيمة الحالية من السيرفر (في الخلفية)
    if (token) {
        loadGoalData(token);
    } else {
        // إذا لم يكن هناك token، إظهار الويدجت بالإعدادات المحفوظة
        setTimeout(() => showWidget(), 100);
    }

    // إظهار الويدجت بعد 1 ثانية كحد أقصى (fallback للأمان)
    setTimeout(() => showWidget(), 1000);

    // موجتين فقط
    const waves = [{
            el: document.getElementById("wave1"),
            amp: 8,
            freq: 0.045,
            speed: 1.1,
            dir: 1,
            phase: 0
        },
        {
            el: document.getElementById("wave3"),
            amp: 8,
            freq: 0.035,
            speed: 0.6,
            dir: -1,
            phase: 5
        }
    ];

    let progress = currentValue / goalValue;

    let time = 0;
    let currentWaveSurface = []; // لتخزين نقاط سطح الموجة

    function draw() {
        time += 0.03;

        // مستوى الماء داخل الماسك فقط
        const baseWater = maskBottom - progress * maskHeight;

        // ميل الماء (يخف مع الامتلاء)
        const tilt = Math.sin(time * 0.8) * 20 * (1 - progress);

        // مسح مصفوفة سطح الموجة
        currentWaveSurface = [];

        // رسم الموجات
        waves.forEach((w, index) => {
            if (!w.el) return; // إذا كان العنصر غير موجود، تجاهل

            let d = `M 0 ${height}`;

            for (let x = 0; x <= width; x++) {
                const slope = tilt * (x / width - 0.5);

                const wave =
                    Math.sin(x * w.freq + w.dir * time * w.speed + w.phase) *
                    w.amp *
                    (1 - progress * 0.8);

                const edge = Math.sin(Math.PI * x / width);

                let y = baseWater + slope + wave * edge;

                // منع الفيضان
                y = Math.max(y, maskTop + 4);

                // حفظ سطح الموجة الأمامية فقط (wave3 هي الأمامية)
                if (index === 1 && x % 10 === 0) {
                    currentWaveSurface.push({
                        x,
                        y
                    });
                }

                d += ` L ${x} ${y}`;
            }

            d += ` L ${width} ${height} Z`;
            w.el.setAttribute("d", d);
        });

        // 🫧 توليد فقاعة من سطح الموجة (عدد أقل)
        if (Math.random() < 0.02 && currentWaveSurface.length > 0) {
            // اختيار نقطة عشوائية من سطح الموجة
            const randomPoint = currentWaveSurface[Math.floor(Math.random() * currentWaveSurface.length)];
            // تأكد من وجود نقطة صالحة
            if (randomPoint && typeof randomPoint.x === 'number' && typeof randomPoint.y === 'number') {
                // أوجّه بدء الفقاعة لتكون قليلاً أسفل سطح الموجة (6-12 بكسل عشوائياً)
                const belowOffset = 6 + Math.random() * 6;
                spawnBubble(randomPoint.x, randomPoint.y + belowOffset);
            }
        }

        // تحديث النص
        if (progressText) {
            progressText.textContent = `${currentValue} / ${goalValue}`;
        }

        // التحقق من الوصول للهدف وإطلاق الاحتفال بشكل متكرر
        if (currentValue >= goalValue && Math.random() < 0.01) {
            triggerCelebration();
        }

        updateBubbles();
        requestAnimationFrame(draw);
    }

    // 🫧 إنشاء فقاعة دائرية
    function spawnBubble(x, y) {
        if (!bubblesGroup) return; // تأكد أن مجموعة الفقاعات موجودة
        // تحقق من صحة الإحداثيات
        if (typeof x !== 'number' || typeof y !== 'number' || isNaN(x) || isNaN(y)) {
            console.error('spawnBubble: إحداثيات غير صالحة', {
                x,
                y
            });
            return;
        }

        const radius = 2.5 + Math.random() * 19; // أحجام أصغر ومتنوعة (1.5-5)

        // نستخدم عنصر صورة SVG بحيث تظهر النجوم بدل الدائرة، مع الحفاظ على نفس الحركات
        const img = document.createElementNS("http://www.w3.org/2000/svg", "image");
        const size = radius * 2;
        // وضع الإشارة للصورة (xlink namespace) للتوافق الأوسع
        try {
            img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', '/assets/img/heart_me_star.png');
        } catch (e) {
            img.setAttribute('href', '/assets/img/heart_me_star.png');
        }
        img.setAttribute('width', size);
        img.setAttribute('height', size);
        // نضع نقطة الارتكاز في المنتصف عند التحديث (سنضبط x/y بناءً على المركز)
        img.setAttribute('opacity', '1');
        img.setAttribute('filter', 'url(#bubbleGlow)');

        bubblesGroup.appendChild(img);

        bubbles.push({
            el: img,
            radius: radius,
            width: size,
            height: size,
            x: x,
            y: y,
            startY: y,
            startX: x,
            life: 0,
            speed: 0.08 + Math.random() * 0.12, // بطيئة جداً مثل الموجات
            wobbleSpeed: 0.05 + Math.random() * 0.05, // تذبذب بطيء جداً
            wobbleAmount: 2 + Math.random() * 3, // حركة أفقية خفيفة
            drift: (Math.random() - 0.5) * 0.3 // انحراف عشوائي للأعلى
        });
    }

    // 🫧 تحريك الفقاعات
    function updateBubbles() {
        for (let i = bubbles.length - 1; i >= 0; i--) {
            const b = bubbles[i];

            // حركة عشوائية بطيئة للأعلى
            b.y -= b.speed;
            b.life += 1;

            // حركة أفقية خفيفة وعشوائية
            const wobble = Math.sin(b.life * b.wobbleSpeed * 0.1) * b.wobbleAmount;
            const randomDrift = Math.sin(b.life * 0.02) * b.drift;
            b.x = b.startX + wobble + randomDrift;

            // تطبيق الموضع الجديد
            // إذا كان العنصر دائرة SVG فنستخدم cx/cy، وإذا كانت صورة نستخدم x/y مع تحويل للمركز
            const tag = (b.el.tagName || '').toLowerCase();
            if (tag === 'circle') {
                b.el.setAttribute("cy", b.y);
                b.el.setAttribute("cx", b.x);
            } else if (tag === 'image' || tag === 'svgimage') {
                const w = b.width || (b.radius ? b.radius * 2 : 6);
                const h = b.height || (b.radius ? b.radius * 2 : 6);
                const newX = b.x - w / 2;
                const newY = b.y - h / 2;
                // تحقق من صحة القيم قبل التحديث
                if (!isNaN(newX) && !isNaN(newY)) {
                    b.el.setAttribute('x', newX);
                    b.el.setAttribute('y', newY);
                }
            } else {
                // افتراضي: حاول ضبط cx/cy
                try {
                    b.el.setAttribute("cy", b.y);
                    b.el.setAttribute("cx", b.x);
                } catch (e) {}
            }

            // تختفي بعد 30px أو إذا خرجت من حدود الماسك
            const distanceTraveled = b.startY - b.y;
            if (distanceTraveled > 120 || b.y < maskTop || b.x < 0 || b.x > width) {
                b.el.remove();
                bubbles.splice(i, 1);
            }
        }
    }

    // 🎉 إطلاق احتفال النجوم
    function triggerCelebration() {
        const container = document.querySelector('.container');
        const containerRect = container.getBoundingClientRect();
        const centerX = containerRect.left + containerRect.width / 2;
        const centerY = containerRect.top + containerRect.height / 2;

        // إطلاق 6-10 نجوم بشكل عشوائي (قابل للتعديل)
        const starCount = 6 + Math.floor(Math.random() * 5);

        for (let i = 0; i < starCount; i++) {
            // تأخير عشوائي لإطلاق النجوم
            setTimeout(() => {
                createStar(centerX, centerY);
            }, i * 50 + Math.random() * 200);
        }
    }

    // 🌟 إنشاء نجمة واحدة
    function createStar(centerX, centerY) {
        const star = document.createElement('img');
        star.src = '/assets/img/heart_me_star.png';
        star.style.position = 'fixed';
        star.style.width = '50px';
        star.style.height = '50px';
        star.style.left = centerX + 'px';
        star.style.top = centerY + 'px';
        star.style.transform = 'translate(-50%, -50%)';
        star.style.pointerEvents = 'none';
        star.style.zIndex = '-100';
        star.style.opacity = '1';

        document.body.appendChild(star);

        // زاوية عشوائية (360 درجة)
        const angle = Math.random() * Math.PI * 2;
        // قوة الانطلاق العشوائية
        const force = 100 + Math.random() * 200;
        const velocityX = Math.cos(angle) * force;
        const velocityY = Math.sin(angle) * force - 200; // دفع للأعلى قليلاً

        // سرعة الدوران العشوائية
        const rotationSpeed = (Math.random() - 0.5) * 20;

        let posX = centerX;
        let posY = centerY;
        let velX = velocityX;
        let velY = velocityY;
        let rotation = 0;
        let opacity = 1;
        let scale = 0.5 + Math.random() * 1; // حجم عشوائي

        const gravity = 500; // الجاذبية
        const fadeStart = 1000 + Math.random() * 500; // متى تبدأ الاختفاء
        let elapsed = 0;

        function animateStar(timestamp) {
            if (!animateStar.lastTime) animateStar.lastTime = timestamp;
            const delta = (timestamp - animateStar.lastTime) / 1000; // بالثواني
            animateStar.lastTime = timestamp;

            elapsed += delta * 1000;

            // تطبيق الجاذبية
            velY += gravity * delta;

            // تحديث الموضع
            posX += velX * delta;
            posY += velY * delta;

            // تحديث الدوران
            rotation += rotationSpeed;

            // الاختفاء التدريجي بعد فترة
            if (elapsed > fadeStart) {
                opacity -= delta * 2;
                scale -= delta * 0.5;
            }

            // تطبيق التحويلات
            star.style.left = posX + 'px';
            star.style.top = posY + 'px';
            star.style.opacity = Math.max(0, opacity);
            star.style.transform = `translate(-50%, -50%) rotate(${rotation}deg) scale(${Math.max(0, scale)})`;

            // الاستمرار في الحركة أو الإزالة
            if (opacity > 0 && posY < window.innerHeight + 100) {
                requestAnimationFrame(animateStar);
            } else {
                star.remove();
            }
        }

        requestAnimationFrame(animateStar);
    }

    draw();

    // تحميل البيانات من السيرفر
    async function loadGoalData(widgetToken) {
        try {
            const response = await fetch(`/api/widget/goal-data/${widgetToken}`);
            if (response.ok) {
                const data = await response.json();

                // 🔧 إصلاح: تأكد من أن القيم أرقام وليست objects
                if (data.goal_value !== undefined) {
                    const newGoalValue = parseInt(data.goal_value);
                    if (!isNaN(newGoalValue)) {
                        goalValue = newGoalValue;
                        localStorage.setItem('heart_me_goal_value', goalValue);

                    } else {
                        console.error('⚠️ goal_value غير صالحة من السيرفر:', data.goal_value);
                    }
                }

                if (data.current_value !== undefined) {
                    const newCurrentValue = parseInt(data.current_value);
                    if (!isNaN(newCurrentValue)) {
                        currentValue = newCurrentValue;
                        localStorage.setItem('heart_me_goal_current', currentValue);

                    } else {
                        console.error('⚠️ current_value غير صالحة من السيرفر:', data.current_value);
                    }
                }

                progress = currentValue / goalValue;

                // إظهار الويدجت بعد اكتمال التحميل
                setTimeout(() => showWidget(), 50);
            }
        } catch (error) {
            console.error('خطأ في تحميل بيانات الهدف:', error);
            // إظهار الويدجت حتى في حالة الخطأ
            setTimeout(() => showWidget(), 500);
        }
    }

    // الاتصال بـ Socket.io
    if (token && typeof io !== 'undefined') {
        const socket = io(window.location.origin, {
            path: '/socket.io',
            transports: ['websocket', 'polling'],
            reconnection: true,
            reconnectionDelay: 1000,
            reconnectionDelayMax: 5000,
            reconnectionAttempts: Infinity,
            timeout: 20000,
            withCredentials: true
        });

        // 🔄 دالة موحدة لإعادة الانضمام (تُستدعى عند connect و reconnect)
        function registerSocket() {
            socket.emit('joinWidget', {
                token: token,
                type: 'heart_me_goal'
            });
        }

        // الاتصال بالسيرفر (يعمل عند الاتصال الأولي و reconnect تلقائياً)
        socket.on('connect', () => {
            registerSocket();
        });

        // الاستماع لحالة الاتصال
        socket.on('widgetConnectionStatus', (data) => {

        });

        // تتبع حالة الانقطاع
        socket.on('disconnect', (reason) => {

        });

        socket.on('error', (error) => {
            console.error('❌ خطأ في Socket.io:', error);
        });

        // الاستماع لحدث الهدية (تم إلغاء الحفظ اليدوي - السيرفر يتولى الأمر)
        socket.on('gift', (data) => {


            // فحص إذا كانت هدية Heart Me
            if (data.giftId === 7934 || data.giftName === 'Heart Me') {

            }
            // لا حاجة لأي كود هنا - السيرفر يرسل updateGoalProgress تلقائياً
        });

        // 🔄 الاستماع لتحديث التقدم (من السيرفر عند الاتصال أو من نوافذ أخرى)
        socket.on('updateGoalProgress', (data) => {

            if (data.goal_type === 'heart_me_goal') {


                const newCurrentValue = parseInt(data.current_value);


                if (!isNaN(newCurrentValue)) {
                    currentValue = newCurrentValue;
                    localStorage.setItem('heart_me_goal_current', currentValue);
                } else {
                    console.error('⚠️ current_value غير صالحة:', data.current_value);
                }

                if (data.goal_value !== undefined) {
                    const newGoalValue = parseInt(data.goal_value);
                    if (!isNaN(newGoalValue)) {
                        goalValue = newGoalValue;
                        localStorage.setItem('heart_me_goal_value', goalValue);
                    } else {
                        console.error('⚠️ goal_value غير صالحة:', data.goal_value);
                    }
                }

                progress = currentValue / goalValue;
            }
        });

        // الاستماع لتحديث الإعدادات
        socket.on('updateGoalSettings', (data) => {

            if (data.goal_value) {
                goalValue = data.goal_value;
                localStorage.setItem('heart_me_goal_value', goalValue); // 💾 حفظ
                progress = currentValue / goalValue;
            }
        });

        // الاستماع لإعادة التعيين
        socket.on('resetGoal', (data) => {
            if (data.goal_type === 'heart_me_goal') {
                currentValue = 0;
                localStorage.setItem('heart_me_goal_current', 0); // 💾 حفظ
                progress = 0;
            }
        });

        // الاستماع لاختبار الهدف
        socket.on('testGoal', (data) => {
            // تجاهل الاختبار إذا كان هناك اختبار قيد التشغيل
            if (isTestRunning) {
                console.error('⚠️ اختبار آخر قيد التشغيل - تم تجاهل الطلب');
                return;
            }

            isTestRunning = true; // تفعيل علم الاختبار

            // حفظ القيم الأصلية
            const originalGoalValue = goalValue;
            const originalCurrentValue = currentValue;

            // تعيين قيم الاختبار
            const testGoalValue = data.goalValue || 50;
            const testDuration = data.duration || 3000;

            goalValue = testGoalValue;
            currentValue = 0;
            progress = 0;

            // الزيادة التدريجية
            const steps = testGoalValue;
            const stepDuration = testDuration / steps;

            let step = 0;
            const interval = setInterval(() => {
                if (step < testGoalValue) {
                    step++;
                    currentValue = step;
                    progress = currentValue / goalValue;

                } else {
                    clearInterval(interval);


                    setTimeout(() => {
                        // العودة للقيم الأصلية
                        goalValue = originalGoalValue;
                        currentValue = originalCurrentValue;
                        progress = currentValue / goalValue;
                        isTestRunning = false; // إيقاف علم الاختبار

                    }, 2000);
                }
            }, stepDuration);
        });
    } else {
        console.error('⚠️ Socket.io غير متاح أو لا يوجد توكن');
    }

    // الاستماع لرسائل من الـ dashboard
    window.addEventListener('message', (event) => {
        if (event.data.type === 'updateGoal') {
            goalValue = event.data.goalValue;
            progress = currentValue / goalValue;
        } else if (event.data.type === 'resetGoal') {
            currentValue = 0;
            progress = 0;
        }
    });
}

document.addEventListener('DOMContentLoaded', init);