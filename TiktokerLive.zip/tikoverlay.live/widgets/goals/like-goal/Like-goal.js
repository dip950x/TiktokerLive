// ====== إعدادات الهدف ======
// 💾 تحميل القيم من localStorage فوراً (تجنب عرض القيم الافتراضية)
const cachedTarget = localStorage.getItem('like_goal_value');
const cachedCurrent = localStorage.getItem('like_goal_current');
const cachedColor = localStorage.getItem('like_goal_color');

let current = cachedCurrent ? parseInt(cachedCurrent) : 0; // عدد اللايكات الحالي
let target = cachedTarget ? parseInt(cachedTarget) : 10000; // الهدف
let isTestRunning = false; // متغير لمنع تشغيل اختبارات متعددة
let currentColor = cachedColor || '#ff1515'; // اللون الافتراضي
let widgetReady = false; // حالة جاهزية الويدجت للعرض



// الحصول على التوكن من URL
const urlParams = new URLSearchParams(window.location.search);
const token = urlParams.get('token');

// ====== دالة إظهار الويدجت بعد اكتمال التحميل ======
function showWidget() {
    if (!widgetReady) {
        widgetReady = true;
        document.body.classList.add('loaded');

    }
}

// ====== عناصر البار ======
const fill = document.getElementById("fill");
const counter = document.getElementById("counter");
const bar = document.querySelector(".bar");
const title = document.querySelector(".title");
const icon = document.querySelector(".icon");

// ====== تحويل Hex إلى RGB ======
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

// ====== دالة تطبيق اللون مع التدرجات ======
function applyColor(color) {
    currentColor = color;
    const rgb = hexToRgb(color);
    if (!rgb) return;

    // تطبيق الألوان على العناصر
    // 1. اللون الأساسي للعنوان
    if (title) {
        title.style.color = color;
        title.style.textShadow = `
      0 0 6px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6),
      0 0 14px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.4)
    `;
    }

    // 2. لون الأيقونة
    if (icon) {
        icon.style.fill = color;
        icon.style.filter = `
      drop-shadow(0 0 12px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}))
      drop-shadow(0 0 20px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9))
    `;
    }

    // 3. لون الشريط (Bar)
    if (bar) {
        bar.style.background = `linear-gradient(to bottom, rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.356), transparent)`;
        bar.style.borderColor = color;
        bar.style.boxShadow = `
      0 0 12px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}),
      0 0 30px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9),
      0 0 50px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)
    `;
    }

    // 4. التعبئة (Fill)
    if (fill) {
        // إنشاء تدرج داكن إلى فاتح
        const darkRgb = {
            r: Math.floor(rgb.r * 0.3),
            g: Math.floor(rgb.g * 0.3),
            b: Math.floor(rgb.b * 0.3)
        };

        fill.style.background = `linear-gradient(to right, rgb(${darkRgb.r}, ${darkRgb.g}, ${darkRgb.b}), rgb(${rgb.r}, ${rgb.g}, ${rgb.b}))`;
        fill.style.boxShadow = `0 0 22px rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
    }

    // 5. العداد (Counter)
    if (counter) {
        counter.style.color = color;
        counter.style.textShadow = `
      0 0 6px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6),
      0 0 14px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.4)
    `;
    }

    // 6. النجوم المتحركة (Sparks)
    const sparks = document.querySelectorAll('.spark svg');
    sparks.forEach(spark => {
        spark.style.fill = color;
        spark.style.filter = `
      drop-shadow(0 0 16px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}))
      drop-shadow(0 0 40px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9))
      drop-shadow(0 0 70px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6))
    `;
    });

    // 7. ألوان حالة الاكتمال (Goal Complete)
    const style = document.createElement('style');
    style.id = 'dynamic-goal-complete-style';

    // إزالة الـ style القديم إن وجد
    const oldStyle = document.getElementById('dynamic-goal-complete-style');
    if (oldStyle) {
        oldStyle.remove();
    }

    style.textContent = `
    .fill.goal-complete {
      box-shadow:
        0 0 12px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}),
        0 0 30px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9),
        0 0 50px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6) !important;
    }
    
    .fill.goal-complete::after {
      background: rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.85) !important;
      box-shadow:
        0 0 12px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}),
        0 0 30px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9),
        0 0 50px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6) !important;
    }
    
    @keyframes barGlowPulse {
      0% {
        box-shadow:
          0 0 12px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6),
          0 0 30px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.4),
          0 0 50px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.3);
      }
      50% {
        box-shadow:
          0 0 18px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}),
          0 0 45px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9),
          0 0 80px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.8);
      }
      100% {
        box-shadow:
          0 0 12px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6),
          0 0 30px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.4),
          0 0 50px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.3);
      }
    }
  `;

    document.head.appendChild(style);


}

// ====== تحديث البار + الوميض ======
function updateBar() {
    const percent = Math.min((current / target) * 100, 100);

    fill.style.width = percent + "%";
    counter.innerText = `${current} / ${target}`;

    // ✨ تفعيل وميض الاكتمال
    if (current >= target) {
        fill.classList.add("goal-complete");
        bar.classList.add("goal-complete"); // 👈 تفعيل وميض الشادو
    } else {
        fill.classList.remove("goal-complete");
        bar.classList.remove("goal-complete");
    }
}

// تحميل البيانات من السيرفر
async function loadGoalData(widgetToken) {
    try {
        const response = await fetch(`/api/widget/like-goal-data/${widgetToken}`);
        if (response.ok) {
            const data = await response.json();

            // 🔧 إصلاح: تأكد من أن القيم أرقام
            const newTarget = parseInt(data.goal_value);
            const newCurrent = parseInt(data.current_value);

            if (!isNaN(newTarget)) {
                target = newTarget;
                localStorage.setItem('like_goal_value', target);
            }

            if (!isNaN(newCurrent)) {
                current = newCurrent;
                localStorage.setItem('like_goal_current', current);
            }



            // تطبيق اللون إذا كان موجوداً
            if (data.goal_color) {
                applyColor(data.goal_color);
                localStorage.setItem('like_goal_color', data.goal_color);

            }

            updateBar();

            // إظهار الويدجت بعد اكتمال التحميل
            setTimeout(() => showWidget(), 50);
        }
    } catch (error) {
        console.error('خطأ في تحميل بيانات الهدف:', error);
        // إظهار الويدجت حتى في حالة الخطأ
        setTimeout(() => showWidget(), 500);
    }
}


// تطبيق اللون المحفوظ من localStorage فوراً
if (cachedColor) {
    applyColor(cachedColor);
}

// تحميل البيانات إذا كان هناك توكن
if (token) {
    loadGoalData(token);
} else {
    // إذا لم يكن هناك token، إظهار الويدجت بالإعدادات المحفوظة
    setTimeout(() => showWidget(), 100);
}

// تشغيل أولي
updateBar();

// إظهار الويدجت بعد 1 ثانية كحد أقصى (fallback للأمان)
setTimeout(() => showWidget(), 1000);

// الاتصال بـ Socket.io
if (token && typeof io !== 'undefined') {
    const socket = io(window.location.origin, {
        path: '/socket.io',
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: Infinity,
        timeout: 20000,
        withCredentials: true // مهم للـ sticky sessions
    });

    // دالة موحدة لإعادة الانضمام
    function registerSocket() {
        socket.emit('joinWidget', {
            token: token,
            type: 'like_goal'
        });
    }

    // الاتصال بالسيرفر
    socket.on('connect', () => {

        registerSocket();
    });

    // تتبع حالة الانقطاع
    socket.on('disconnect', (reason) => {

    });

    socket.on('error', (error) => {
        console.error('❌ خطأ في Socket.io:', error);
    });

    // الاستماع لحدث اللايكات (تم إلغاء الحفظ اليدوي - السيرفر يتولى الأمر)
    socket.on('newLike', (data) => {

    });

    // 🔄 الاستماع لتحديث التقدم (من السيرفر عند الاتصال أو من نوافذ أخرى)
    socket.on('updateGoalProgress', (data) => {
        if (data.goal_type === 'like_goal') {

            // 🔧 إصلاح: تأكد من أن القيم أرقام
            const newCurrent = parseInt(data.current_value);
            if (!isNaN(newCurrent)) {
                current = newCurrent;
                localStorage.setItem('like_goal_current', current);
            }

            if (data.goal_value !== undefined) {
                const newTarget = parseInt(data.goal_value);
                if (!isNaN(newTarget)) {
                    target = newTarget;
                    localStorage.setItem('like_goal_value', target);
                }
            }

            updateBar();

        }
    });

    // الاستماع لتحديث الإعدادات - مع تحديث فوري
    socket.on('updateLikeGoalSettings', (data) => {

        if (data.goal_value !== undefined) {
            target = data.goal_value;
            localStorage.setItem('like_goal_value', target); // 💾 حفظ
            updateBar();

        }

        // تطبيق اللون إذا كان موجوداً
        if (data.goal_color) {
            applyColor(data.goal_color);
            localStorage.setItem('like_goal_color', data.goal_color); // 💾 حفظ
        }
    });

    // الاستماع لإعادة التعيين
    socket.on('resetGoal', (data) => {

        if (data.goal_type === 'like_goal') {
            current = 0;
            localStorage.setItem('like_goal_current', 0); // 💾 حفظ
            updateBar();
        }
    });

    // الاستماع لاختبار الهدف
    socket.on('testLikeGoal', (data) => {
        if (isTestRunning) return;
        isTestRunning = true;



        const originalTarget = target;
        const originalCurrent = current;

        target = data.goalValue || 100;
        const duration = data.duration || 3000;

        const startTime = performance.now();
        current = 0;
        updateBar();

        function animate(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            current = Math.floor(progress * target);
            updateBar();

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {

                setTimeout(() => {
                    target = originalTarget;
                    current = originalCurrent;
                    updateBar();
                    isTestRunning = false;
                }, 1500);
            }
        }

        requestAnimationFrame(animate);
    });
}

// ===================================================================
// ====================== نظام النجوم البراقة =========================
// ===================================================================

const layer = document.querySelector(".sparkles-layer");

const SPARK_COUNT = 50; // عدد النقاط
const MOVE_X = 20; // مقدار الحركة للأمام
const LIFE_MIN = 600; // أقل مدة
const LIFE_MAX = 2600; // أعلى مدة

function random(min, max) {
    return Math.random() * (max - min) + min;
}

function spawnSpark() {
    const spark = document.createElement("div");
    spark.className = "spark";

    spark.innerHTML = `
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" height="800px" width="800px" version="1.1" id="Capa_1" viewBox="0 0 472.7 472.7" xml:space="preserve">
<g>
	<path id="XMLID_810_" d="M433.5,67c-25.3-25.3-59-39.3-94.8-39.3s-69.6,14-94.9,39.4l-7.3,7.3l-7.5-7.5   c-25.4-25.4-59.1-39.4-95-39.4c-35.8,0-69.4,13.9-94.7,39.3C13.9,92.2,0,125.9,0,161.7s14,69.5,39.4,94.8l182.7,182.7   c3.8,3.8,9,6,14.5,6c5.4,0,10.6-2.2,14.5-6l182.2-182.4c25.4-25.4,39.3-59.1,39.4-94.9S458.8,92.4,433.5,67z M132.5,117.2   c-23.9,0-43.4,19.5-43.4,43.4c0,11-8.9,19.9-19.9,19.9s-19.9-8.9-19.9-19.9c0-45.8,37.3-83.1,83.1-83.1c11,0,19.9,8.9,19.9,19.9   C152.4,108.4,143.5,117.2,132.5,117.2z"/>
</g>
</svg>
  `;

    // تطبيق اللون الحالي على القلب
    const sparkSvg = spark.querySelector('svg');
    if (sparkSvg && currentColor) {
        const rgb = hexToRgb(currentColor);
        if (rgb) {
            sparkSvg.style.fill = currentColor;
            sparkSvg.style.filter = `
        drop-shadow(0 0 16px rgb(${rgb.r}, ${rgb.g}, ${rgb.b}))
        drop-shadow(0 0 40px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.9))
        drop-shadow(0 0 70px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6))
      `;
        }
    }

    // حجم عشوائي
    const size = random(5.2, 17.2);
    spark.style.width = `${size}px`;
    spark.style.height = `${size}px`;

    // موقع عشوائي
    spark.style.left = `${random(0, layer.clientWidth)}px`;
    spark.style.top = `${random(0, layer.clientHeight)}px`;

    layer.appendChild(spark);

    const life = random(LIFE_MIN, LIFE_MAX);

    spark.animate(
        [{
                transform: "translateX(0px)",
                opacity: 0
            },
            {
                opacity: 1
            },
            {
                transform: `translateX(${MOVE_X}px)`,
                opacity: 0
            }
        ], {
            duration: life,
            easing: "ease-out"
        }
    );

    setTimeout(() => spark.remove(), life);
}

// توليد مستمر لكن عشوائي
setInterval(() => {
    if (layer.children.length < SPARK_COUNT) {
        spawnSpark();
    }
}, 100);