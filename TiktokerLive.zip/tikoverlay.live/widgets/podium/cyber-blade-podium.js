// cyber-blade-podium.js - تصميم Cyber Blade لأفضل 3 متفاعلين
(function() {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    let maxRanksToShow = 3; // القيمة الافتراضية

    // إعدادات الأنيميشن
    const SHOW_TIME = 10000;
    const HIDE_TIME = 4000;
    const STAGGER = 300;

    // عناصر الواجهة - 3 مراكز
    const rows = [{
            element: document.getElementById('row-1'),
            avatar: document.querySelector('#row-1 .avatar-img'),
            name: document.querySelector('#row-1 .name'),
            score: document.querySelector('#row-1 .score-val')
        },
        {
            element: document.getElementById('row-2'),
            avatar: document.querySelector('#row-2 .avatar-img'),
            name: document.querySelector('#row-2 .name'),
            score: document.querySelector('#row-2 .score-val')
        },
        {
            element: document.getElementById('row-3'),
            avatar: document.querySelector('#row-3 .avatar-img'),
            name: document.querySelector('#row-3 .name'),
            score: document.querySelector('#row-3 .score-val')
        }
    ];

    let animationLoopTimer = null;
    let currentData = null;

    // دالة لتحويل الأرقام الكبيرة إلى صيغة K
    function formatNumber(num) {
        if (num >= 1000) {
            return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
        }
        return num.toLocaleString('en-US');
    }

    // دالة لقص الاسم
    function truncateName(name, maxChars = 12) {
        if (!name || name === '—') return name;
        if (name.length > maxChars) {
            return name.substring(0, maxChars);
        }
        return name;
    }

    // جلب إعدادات العرض من السيرفر
    async function loadDisplaySettings() {
        if (!token) {
            maxRanksToShow = 3;
            return Promise.resolve();
        }
        try {
            const response = await fetch(`/api/widget/settings/${token}`);
            if (response.ok) {
                const settings = await response.json();
                maxRanksToShow = settings.podium_ranks_count || 3;
            } else {
                maxRanksToShow = 3;
                maxRanksToShow = 3;
            }
        } catch (error) {
            maxRanksToShow = 3;
            maxRanksToShow = 3;
        }
    }

    // إخفاء المراكز التي تتجاوز الحد (بدون تغيير البيانات)
    function applyRankLimit() {
        rows.forEach((row, index) => {
            const rank = index + 1;
            if (row && row.element) {
                row.element.style.display = rank <= maxRanksToShow ? 'flex' : 'none';
            }
        });

    }

    // دالة لتحديث مركز واحد (بدون تشغيل الأنيميشن)
    function updateRankData(index, user) {
        const row = rows[index];
        if (!row || !row.element || !row.name || !row.score || !row.avatar) {
            return;
        }

        // إخفاء المركز إذا لا يوجد مستخدم أو النقاط = 0
        if (!user || !user.likesCount || user.likesCount === 0) {
            row.element.style.display = 'none';
            return;
        }

        // إظهار المركز مع البيانات الحقيقية
        row.element.style.display = 'flex';

        // تحديث الاسم
        const displayName = truncateName(user.username || user.uniqueId || user.nickname || '—');
        row.name.textContent = displayName;

        // تحديث النقاط - نحتفظ بأيقونة القلب
        row.score.innerHTML = formatNumber(user.likesCount) + ' <i class="fas fa-heart heart"></i>';

        // تحديث الصورة
        const avatarUrl = user.profilePicture || user.profilePictureUrl || '/assets/img/avatar' + (index + 1) + '.png';
        row.avatar.src = avatarUrl;
        row.avatar.onerror = function() {
            this.src = '/assets/img/avatar' + (index + 1) + '.png';
        };


    }

    // دالة أنيميشن الظهور والاختفاء
    function startAnimationLoop() {
        // إيقاف أي loop سابق
        if (animationLoopTimer) {
            clearTimeout(animationLoopTimer);
        }

        // دالة لعرض الصفوف (فقط المراكز الظاهرة)
        function showRows() {
            rows.forEach((row, idx) => {
                if (idx + 1 <= maxRanksToShow) {
                    setTimeout(() => {
                        row.element.classList.add('active');
                    }, idx * STAGGER);
                }
            });
        }

        // دالة لإخفاء الصفوف (فقط المراكز الظاهرة)
        function hideRows() {
            const visibleRows = rows.slice(0, maxRanksToShow);
            visibleRows.forEach((row, idx) => {
                const reverseIdx = (visibleRows.length - 1) - idx;
                setTimeout(() => {
                    row.element.classList.remove('active');
                }, reverseIdx * STAGGER);
            });
        }

        // تشغيل الـloop
        function loop() {
            showRows();

            setTimeout(() => {
                hideRows();
            }, SHOW_TIME);

            animationLoopTimer = setTimeout(loop, SHOW_TIME + HIDE_TIME);
        }

        loop();
    }

    // دالة لعرض أفضل المتفاعلين (حسب maxRanksToShow)
    function renderTop3(data) {


        currentData = data;

        let displayData = data;
        if (!Array.isArray(data) || data.length === 0) {
            console.log('⚠️ [Cyber-Blade] لا توجد بيانات - استخدام قيم افتراضية');
            displayData = [];
        }

        // تحديث البيانات فقط (بدون تشغيل الأنيميشن)
        for (let i = 0; i < 3; i++) {
            const user = displayData[i];
            updateRankData(i, user);
        }

        // تطبيق حد المراكز
        applyRankLimit();


    }

    // الاتصال بالسوكت (فقط إذا كان هناك token)
    if (!token) {
        console.warn('⚠️ [Cyber-Blade] لا يوجد token في الرابط - سيتم عرض بيانات تجريبية عند تحميل الصفحة');
        return;
    }

    // تحميل الإعدادات عند بدء التشغيل
    (async () => {
        await loadDisplaySettings();
        applyRankLimit(); // تطبيق حد المراكز على البيانات التجريبية
    })();



    const socket = io(window.location.origin, {
        path: '/socket.io',
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: Infinity
    });

    socket.on('connect', () => {
        socket.emit('joinWidget', {
            token: token,
            type: 'cyber-blade-podium'
        });
    });

    socket.on('disconnect', () => {});

    // استقبال البيانات الأولية
    socket.on('topLikers', (data) => {

        renderTop3(data);
    });

    // تحديثات فورية
    socket.on('update-topLikers', (data) => {

        renderTop3(data);
    });

    // استقبال أمر تغيير التصميم - إعادة تحميل الصفحة
    socket.on('themeChanged', (data) => {
        location.reload();
    });

    // بدء التطبيق
    async function initializeApp() {


        // جلب إعدادات الاتجاه
        if (token) {
            try {
                const response = await fetch(`/api/widget/settings/${token}`);
                if (response.ok) {
                    const settings = await response.json();

                    // تطبيق اتجاه التصميم
                    if (settings.podium_flip_direction) {
                        const htmlEl = document.documentElement;
                        // التصميم الأصلي هو RTL، نغير لـ LTR إذا طُلب
                        if (settings.podium_flip_direction === 'ltr') {
                            htmlEl.setAttribute('dir', 'ltr');
                        } else {
                            htmlEl.setAttribute('dir', 'rtl');
                        }
                    }
                }
            } catch (error) {
                console.warn('خطأ في جلب الإعدادات:', error.message);
            }
        }

        // التحقق من تحميل جميع العناصر
        rows.forEach((row, idx) => {
            if (!row.element || !row.name || !row.score || !row.avatar) {
                console.error(`❌ [Cyber-Blade] عناصر المركز ${idx + 1} غير موجودة!`, row);
            }
        });

        // تشغيل الأنيميشن
        startAnimationLoop();

        // إذا لم يكن هناك token، عرض بيانات تجريبية
        if (!token) {

            renderTop3([{
                    username: 'THE LEGEND',
                    likesCount: 5240,
                    profilePicture: '/assets/img/avatar1.png'
                },
                {
                    username: 'DANIEL.PRO',
                    likesCount: 3100,
                    profilePicture: '/assets/img/avatar2.png'
                },
                {
                    username: 'NIGHT_RIDER',
                    likesCount: 1850,
                    profilePicture: '/assets/img/avatar3.png'
                }
            ]);
        }
    }

    // الانتظار حتى تحميل الصفحة
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeApp);
    } else {
        initializeApp();
    }


})();