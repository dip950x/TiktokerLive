// ====== إعدادات الاتصال ======
const urlParams = new URLSearchParams(window.location.search);
const token = urlParams.get('token');
const isDashboardView = urlParams.get('isDashboardView') === 'true' || window.location.href.includes('isDashboardView=true');

let socket = null;
let settings = {};
let isConnected = false;
// مقياس عام للتحكم بحجم كل عناصر الألعاب النارية (0.0 - 1.0)
const FIREWORK_SCALE = 0.5; // اضبط القيمة هنا لتصغير/تكبير كل العناصر بسرعة
// مدة ظهور اسم المستخدم بالملي ثانية (يجب أن تكون أطول أو مساوية لمدة الانميشن في CSS)
const USERNAME_DISPLAY_MS = 3800;

// ====== نظام الطابور للحد الأقصى من الألعاب النارية ======
let activeFireworks = 0;
let fireworkQueue = [];

// ====== إنشاء فقاعة هدية ======
function createGiftBubble(username, profilePictureUrl, giftImageUrl) {
    // debug: gift creation started (removed non-error console output)

    const bubblesLayer = document.getElementById('bubblesLayer');

    // حساب إزاحة عشوائية يميناً أو يساراً (-200 إلى +200 بكسل)
    const randomOffsetX = (Math.random() - 0.5) * 400;

    // 1. إنشاء صورة المستخدم الرئيسية التي ترتفع
    const mainBubble = document.createElement('div');
    mainBubble.className = 'gift-bubble';
    mainBubble.style.setProperty('--offset-x', `${randomOffsetX}px`);
    mainBubble.innerHTML = `
        <img src="${profilePictureUrl}" alt="Profile" class="profile-image" onerror="this.src='/assets/img/avatar1.png'">
    `;
    // تغيير الحجم الداخلي للفقاعة الرئيسية لضمان التصغير
    const mainSize = Math.round(100 * FIREWORK_SCALE);
    mainBubble.style.width = mainSize + 'px';
    mainBubble.style.height = mainSize + 'px';
    bubblesLayer.appendChild(mainBubble);
    // تشغيل صوت إطلاق الصاروخ عند بدء صعود الفقاعة
    playLaunchSound();

    // 2. بعد ثانيتين (عندما تصل المنتصف)، إنشاء الانفجار
    setTimeout(() => {
        // حساب موقع الانفجار بناءً على موقع الصورة النهائي
        const explosionX = `calc(50% + ${randomOffsetX}px)`;
        const explosionY = '50vh';

        // إخفاء الصورة الرئيسية
        mainBubble.style.opacity = '0';

        // إنشاء 10 صور للمستخدم بشكل دائري
        for (let i = 0; i < 10; i++) {
            const angle = (Math.PI * 2 * i) / 10; // توزيع دائري
            const distance = Math.round(200 * FIREWORK_SCALE); // المسافة من المركز (مصغرة)

            const profileClone = document.createElement('img');
            profileClone.className = 'explosion-profile';
            profileClone.src = profilePictureUrl;
            profileClone.onerror = () => profileClone.src = '/assets/img/avatar1.png';

            // تعيين موقع البداية في مركز الانفجار
            profileClone.style.left = explosionX;
            profileClone.style.top = explosionY;
            // تأكيد الحجم عبر الأنماط الداخلية لضمان التجانس
            const profileSize = Math.round(80 * FIREWORK_SCALE);
            profileClone.style.width = profileSize + 'px';
            profileClone.style.height = profileSize + 'px';

            // حساب اتجاه الانفجار
            const dx = Math.cos(angle) * distance;
            const dy = Math.sin(angle) * distance;
            const rotate = Math.random() * 360;

            profileClone.style.setProperty('--dx', `${dx}px`);
            profileClone.style.setProperty('--dy', `${dy}px`);
            profileClone.style.setProperty('--rotate', `${rotate}deg`);

            bubblesLayer.appendChild(profileClone);

            // إزالة بعد انتهاء الانيميشن
            setTimeout(() => profileClone.remove(), 2500);
        }

        // إنشاء 10 صور للهدية بشكل دائري (بزاوية مختلفة قليلاً)
        for (let i = 0; i < 10; i++) {
            const angle = (Math.PI * 2 * i) / 10 + Math.PI / 10; // إزاحة بسيطة
            const distance = Math.round(180 * FIREWORK_SCALE);

            const giftClone = document.createElement('img');
            giftClone.className = 'explosion-gift';
            giftClone.src = giftImageUrl;
            giftClone.onerror = () => giftClone.src = '/assets/img/gifts/heart_me_7934.webp';

            giftClone.style.left = explosionX;
            giftClone.style.top = explosionY;
            // تأكيد الحجم عبر الأنماط الداخلية لضمان التجانس
            const giftSize = Math.round(70 * FIREWORK_SCALE);
            giftClone.style.width = giftSize + 'px';
            giftClone.style.height = giftSize + 'px';

            const dx = Math.cos(angle) * distance;
            const dy = Math.sin(angle) * distance;
            const rotate = Math.random() * 360;

            giftClone.style.setProperty('--dx', `${dx}px`);
            giftClone.style.setProperty('--dy', `${dy}px`);
            giftClone.style.setProperty('--rotate', `${rotate}deg`);

            bubblesLayer.appendChild(giftClone);

            setTimeout(() => giftClone.remove(), 2500);
        }

        // إظهار اسم المستخدم في مركز الانفجار (مضمن بدقة وبأنماط داخلية لحماية من أي تجاوزات CSS)
        const usernameElement = document.createElement('div');
        usernameElement.className = 'explosion-username';

        // حساب الموقع بالبكسل لضمان الدقة وتجنب مشاكل RTL
        const pixelX = Math.round((window.innerWidth / 2) + randomOffsetX);
        const pixelY = Math.round(window.innerHeight / 2);

        // تعيين أنماط داخلية قوية لضمان الظهور كما هو متوقع
        usernameElement.style.position = 'absolute';
        usernameElement.style.left = `${pixelX}px`;
        usernameElement.style.top = `${pixelY}px`;
        usernameElement.style.transform = 'translate(-50%, -50%)';
        usernameElement.style.direction = 'ltr';
        usernameElement.style.color = '#ff0000ff';
        usernameElement.style.fontSize = `${Math.round(64 * FIREWORK_SCALE)}px`;
        usernameElement.style.fontWeight = '900';
        usernameElement.style.textTransform = 'uppercase';
        usernameElement.style.letterSpacing = `${Math.max(1, Math.round(4 * FIREWORK_SCALE))}px`;
        usernameElement.style.whiteSpace = 'nowrap';
        usernameElement.style.fontFamily = "Impact, 'Arial Black', sans-serif";
        usernameElement.style.textShadow = '0 0 10px rgba(255,255,255,1), 0 0 20px rgba(255,215,0,1), 0 0 30px rgba(255,215,0,1), 0 0 40px rgba(255,215,0,1), 0 0 60px rgba(255,105,180,1), 0 0 80px rgba(255,105,180,0.9), 0 0 100px rgba(138,43,226,0.8)';
        usernameElement.style.zIndex = '9999';
        usernameElement.style.pointerEvents = 'none';
        usernameElement.style.filter = 'brightness(1.5)';

        usernameElement.textContent = username;

        // أضف الاسم إلى طبقة النصوص المخصصة لضمان أنها فوق كل العناصر المتحركة
        const textLayer = document.getElementById('textLayer') || bubblesLayer;
        // أضف صنف الانميشن ليبدأ الاسم صغيرًا ثم يكبر مع الانفجار
        usernameElement.classList.add('username-pop');
        textLayer.appendChild(usernameElement);

        // إزالة الاسم بعد انتهاء الانيميشن
        // إزالة الاسم بعد انتهاء الانيميشن (مطابقة لِـ USERNAME_DISPLAY_MS)
        setTimeout(() => usernameElement.remove(), USERNAME_DISPLAY_MS);

        // تشغيل صوت الانفجار
        playExplosionSound();

        // إزالة الصورة الرئيسية
        setTimeout(() => mainBubble.remove(), 500);
    }, 2000);

    // إنشاء جزيئات متلألئة (مع تأخير للتزامن مع الصعود)
    setTimeout(() => {
        createSparkles(mainBubble);
    }, 200);
}

// ====== إنشاء جزيئات متلألئة ======
function createSparkles(bubbleElement) {
    // تقليل عدد الجزيئات لتحسين الأداء مع الحفاظ على المظهر
    const sparkleCount = 18;
    const rect = bubbleElement.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const bubblesLayer = document.getElementById('bubblesLayer');

    for (let i = 0; i < sparkleCount; i++) {
        setTimeout(() => {
            const sparkle = document.createElement('div');
            sparkle.className = 'sparkle';

            sparkle.style.left = centerX + 'px';
            sparkle.style.top = centerY + 'px';

            // حجم أصغر قليلاً لتقليل العبء البصري
            const sparkleSize = Math.max(3, Math.round(8 * FIREWORK_SCALE));
            sparkle.style.width = sparkleSize + 'px';
            sparkle.style.height = sparkleSize + 'px';

            const angle = Math.random() * Math.PI * 2;
            const distance = Math.round((25 + Math.random() * 50) * FIREWORK_SCALE);
            sparkle.style.setProperty('--dx', `${Math.cos(angle) * distance}px`);
            sparkle.style.setProperty('--dy', `${Math.sin(angle) * distance}px`);

            bubblesLayer.appendChild(sparkle);

            // مدة أقصر لتقليل عدد العناصر في DOM
            setTimeout(() => sparkle.remove(), 1400);
        }, i * 50);
    }
}

// ====== تشغيل صوت الانفجار ======
function playExplosionSound() {
    // debug: playExplosionSound invoked (removed non-error console output)
    // كتم الصوت في وضع المعاينة بالداشبورد
    if (isDashboardView) {
        // preview mode: skip sound
        return;
    }
    // تحقق من تفعيل الصوت في الإعدادات
    if (settings.firework_soundenabled === false) {
        // sound disabled in settings: skip
        return;
    }

    const audio = new Audio(`/assets/sounds/firework/rocket_boom/${Math.floor(Math.random() * 8) + 1}.mp3`);
    // تقليل مستوى الصوت العام للألعاب النارية للحفاظ على كونها "أصغر" صوتياً
    const volumeValue = settings.firework_soundvolume !== null && settings.firework_soundvolume !== undefined ? settings.firework_soundvolume : 80;

    // إذا كان مستوى الصوت 0، لا تقم بتشغيل الصوت نهائياً
    if (volumeValue === 0) {
        // volume 0: skip
        return;
    }

    audio.volume = (volumeValue / 100) * 0.6;
    audio.play().catch(err => console.error('Audio play failed:', err));
}

// تشغيل صوت الإطلاق (Minecraft firework) عند بداية صعود الفقاعة
function playLaunchSound() {
    // debug: playLaunchSound invoked (removed non-error console output)
    // كتم الصوت في وضع المعاينة بالداشبورد
    if (isDashboardView) {
        // preview mode: skip launch sound
        return;
    }
    if (settings.firework_soundenabled === false) {
        // sound disabled in settings: skip launch
        return;
    }
    try {
        const candidates = ['/assets/sounds/firework/rocket_boom/minecraft-firework.mp3'];
        const volumeValue = settings.firework_soundvolume !== null && settings.firework_soundvolume !== undefined ? settings.firework_soundvolume : 80;

        // إذا كان مستوى الصوت 0، لا تقم بتشغيل الصوت نهائياً
        if (volumeValue === 0) {
            // volume 0: skip
            return;
        }

        const volume = (volumeValue / 100) * 0.7;
        // debug: launch volume computed (removed non-error console output)

        // Try sources sequentially until one plays
        let idx = 0;
        const tryNext = () => {
            if (idx >= candidates.length) {
                // No launch sound found in candidate paths
                return;
            }
            const src = candidates[idx++];
            const audio = new Audio(src);
            audio.volume = volume;
            let tried = false;

            const cleanupAndNext = (err) => {
                if (tried) return;
                tried = true;
                audio.removeEventListener('error', cleanupAndNext);
                audio.pause();
                tryNext();
            };

            audio.addEventListener('error', cleanupAndNext);
            audio.play().then(() => {
                // played successfully
            }).catch((err) => {
                cleanupAndNext(err);
            });
        };

        tryNext();
    } catch (e) {
        console.error('Launch audio error:', e);
    }
}

// ====== معالج استقبال الهدايا ======
function handleGift(giftData) {
    // debug: new gift received (removed non-error console output)

    // التحقق من الحد الأدنى للعملات (إذا كانت موجودة في الإعدادات)
    const minCoins = settings.firework_mincoins || 1;
    if (giftData.diamondCount < minCoins) {
        // below min coins: ignore
        return;
    }

    const username = giftData.nickname || giftData.uniqueId || 'مجهول';
    const profilePictureUrl = giftData.profilePictureUrl || '/assets/img/avatar1.png';
    const giftImageUrl = giftData.giftPictureUrl || giftData.giftImage || '/assets/img/gifts/heart_me_7934.webp';

    // debug: queued firework item (removed non-error console output)

    // ✨ استخدام repeatCount من الكومبو (5 وردات = 5 مفرقعات)
    // إذا لم يكن موجوداً، تحديد عدد التكرارات بناءً على حجم الهدية
    let repeatCount = giftData.repeatCount || 1;
    if (!giftData.repeatCount) {
        if (giftData.diamondCount > 1000) repeatCount = 2;
        if (giftData.diamondCount > 5000) repeatCount = 3;
    }

    // إضافة الفقاعات إلى الطابور
    for (let i = 0; i < repeatCount; i++) {
        fireworkQueue.push({
            username,
            profilePictureUrl,
            giftImageUrl
        });
    }

    // معالجة الطابور
    processFireworkQueue();
}

// ====== معالجة طابور الألعاب النارية ======
function processFireworkQueue() {
    // استخدام القيمة من الإعدادات، وإذا لم تكن موجودة استخدم 1 كقيمة افتراضية
    const maxConcurrent = settings.firework_maxconcurrent !== undefined && settings.firework_maxconcurrent !== null ?
        Math.min(Math.max(settings.firework_maxconcurrent, 1), 7) :
        1;
    // debug: processing firework queue (removed non-error console output)

    while (activeFireworks < maxConcurrent && fireworkQueue.length > 0) {
        const item = fireworkQueue.shift();
        activeFireworks++;

        createGiftBubble(item.username, item.profilePictureUrl, item.giftImageUrl);

        // تقليل العداد بعد انتهاء الانفجار (4.5 ثانية = 2000ms صعود + 2500ms انفجار)
        setTimeout(() => {
            activeFireworks--;
            processFireworkQueue(); // معالجة العناصر المتبقية في الطابور
        }, 4500);
    }
}

// ====== الاتصال بـ Socket.IO ======
function connectSocket() {
    if (!token) {
        console.error('❌ لا يوجد توكن في الرابط');
        return;
    }

    socket = io(window.location.origin, {
        path: '/socket.io',
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: Infinity,
        timeout: 20000,
        withCredentials: true
    });

    socket.on('connect', () => {
        // connected to server (removed non-error console output)
        isConnected = true;

        // تسجيل الويدجت في السيرفر
        socket.emit('joinWidget', {
            token: token,
            type: 'firework'
        });
        // joinWidget emitted with token (removed non-error console output)
    });

    socket.on('disconnect', () => {
        // disconnected from server (removed non-error console output)
        isConnected = false;
    });

    // استقبال الإعدادات
    socket.on('settings', (receivedSettings) => {
        settings = receivedSettings || {};
    });

    // استقبال الهدايا - حدث واحد فقط
    // نتجاهل فقط الهدايا التي فيها source: 'live_stream' (المخصصة للـ Logic/Actions)
    socket.on('gift', (giftData) => {
        if (giftData.source === 'live_stream') {
            return; // تجاهل هدايا الـ Logic
        }
        // gift received (removed non-error console output)
        handleGift(giftData);
    });

    // معالجة أخطاء الاتصال
    socket.on('error', (error) => {
        console.error('❌ خطأ:', error);
    });
}

// ====== بدء الاتصال عند تحميل الصفحة ======
window.addEventListener('load', () => {
    connectSocket();

    // اختبار عرض تجريبي إذا كان في وضع المعاينة
    if (window.location.href.includes('preview=1')) {
        setTimeout(() => {
            handleGift({
                nickname: 'Test User',
                profilePictureUrl: 'https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/d41aaaa5e8d90a3f45375b93ef48ebb4.webp',
                giftPictureUrl: 'https://p19-webcast.tiktokcdn.com/img/maliva/webcast-va/eba3a9bb85c33e017f3648eaf88d7189~tplv-obj.png',
                diamondCount: 100
            });
        }, 2000);
    }
});

// ====== وظيفة اختبار للـ Dashboard ======
window.testFirework = function() {
    handleGift({
        nickname: 'Test User 🎉',
        profilePictureUrl: 'https://p16-sign-sg.tiktokcdn.com/aweme/100x100/tos-alisg-avt-0068/d41aaaa5e8d90a3f45375b93ef48ebb4.webp',
        giftPictureUrl: 'https://p19-webcast.tiktokcdn.com/img/maliva/webcast-va/eba3a9bb85c33e017f3648eaf88d7189~tplv-obj.png',
        diamondCount: 500
    });
};