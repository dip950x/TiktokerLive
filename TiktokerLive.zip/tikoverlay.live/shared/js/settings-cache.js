/**
 * 💾 نظام موحد لإدارة الإعدادات مع localStorage
 * =====================================
 * 
 * الهدف: تحسين تجربة المستخدم بعرض الإعدادات المحفوظة فوراً
 * بدلاً من الانتظار لتحميلها من السيرفر
 */

class SettingsCache {
    constructor() {
        this.prefix = 'tiktok_settings_';
        this.userId = null;
    }

    /**
     * تعيين معرف المستخدم
     */
    setUserId(userId) {
        this.userId = userId;
    }

    /**
     * إنشاء مفتاح فريد لكل إعداد
     */
    _getKey(settingName) {
        if (!this.userId) {
            console.warn('⚠️ User ID not set for SettingsCache');
            return `${this.prefix}${settingName}`;
        }
        return `${this.prefix}${this.userId}_${settingName}`;
    }

    /**
     * حفظ إعداد في localStorage
     * @param {string} settingName - اسم الإعداد
     * @param {any} value - القيمة (object, string, number, etc.)
     */
    save(settingName, value) {
        try {
            const key = this._getKey(settingName);
            const data = {
                value: value,
                timestamp: Date.now(),
                version: 1
            };
            localStorage.setItem(key, JSON.stringify(data));

            return true;
        } catch (e) {
            console.error(`❌ فشل حفظ ${settingName} في localStorage:`, e);
            return false;
        }
    }

    /**
     * جلب إعداد من localStorage
     * @param {string} settingName - اسم الإعداد
     * @param {any} defaultValue - القيمة الافتراضية إذا لم يُعثر على الإعداد
     * @returns {any} القيمة المحفوظة أو القيمة الافتراضية
     */
    get(settingName, defaultValue = null) {
        try {
            const key = this._getKey(settingName);
            const stored = localStorage.getItem(key);

            if (!stored) {
                return defaultValue;
            }

            const data = JSON.parse(stored);


            console.log(`📖 تم جلب إعداد ${settingName} من localStorage`);
            return data.value;
        } catch (e) {
            console.error(`❌ فشل جلب ${settingName} من localStorage:`, e);
            return defaultValue;
        }
    }

    /**
     * حذف إعداد من localStorage
     */
    remove(settingName) {
        try {
            const key = this._getKey(settingName);
            localStorage.removeItem(key);
            console.log(`🗑️ تم حذف إعداد ${settingName} من localStorage`);
            return true;
        } catch (e) {
            console.error(`❌ فشل حذف ${settingName}:`, e);
            return false;
        }
    }

    /**
     * مسح جميع الإعدادات للمستخدم الحالي
     */
    clear() {
        try {
            const keysToRemove = [];
            const prefix = this.userId ? `${this.prefix}${this.userId}_` : this.prefix;

            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key.startsWith(prefix)) {
                    keysToRemove.push(key);
                }
            }

            keysToRemove.forEach(key => localStorage.removeItem(key));
            console.log(`🧹 تم مسح ${keysToRemove.length} إعداد من localStorage`);
            return true;
        } catch (e) {
            console.error('❌ فشل مسح الإعدادات:', e);
            return false;
        }
    }

    /**
     * حفظ + مزامنة مع السيرفر
     * @param {string} settingName - اسم الإعداد
     * @param {any} value - القيمة
     * @param {string} apiEndpoint - API endpoint للحفظ في السيرفر
     * @param {object} additionalData - بيانات إضافية للإرسال
     */
    async saveAndSync(settingName, value, apiEndpoint, additionalData = {}) {
        // 1. حفظ محلي فوراً (UX سريع)
        this.save(settingName, value);

        // 2. مزامنة مع السيرفر في الخلفية
        try {
            const response = await fetch(apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    ...additionalData,
                    [settingName]: value
                })
            });

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}`);
            }

            console.log(`✅ تمت مزامنة ${settingName} مع السيرفر`);
            return true;
        } catch (error) {
            console.error(`❌ فشلت مزامنة ${settingName} مع السيرفر:`, error);
            return false;
        }
    }

    /**
     * جلب من localStorage ثم التحديث من السيرفر في الخلفية
     * @param {string} settingName - اسم الإعداد
     * @param {string} apiEndpoint - API endpoint للجلب من السيرفر
     * @param {function} onUpdate - دالة callback عند تحديث القيمة
     * @param {any} defaultValue - القيمة الافتراضية
     */
    async getAndSync(settingName, apiEndpoint, onUpdate, defaultValue = null) {
        // 1. جلب من localStorage فوراً
        const cachedValue = this.get(settingName, defaultValue);

        // 2. استدعاء callback بالقيمة المحفوظة (عرض فوري)
        if (cachedValue !== null && cachedValue !== defaultValue) {
            onUpdate(cachedValue, true); // true = من cache
        } else if (defaultValue !== null) {
            onUpdate(defaultValue, false);
        }

        // 3. جلب من السيرفر في الخلفية
        try {
            const response = await fetch(apiEndpoint);

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}`);
            }

            const data = await response.json();

            // استخراج القيمة من الاستجابة
            let serverValue = data[settingName];
            if (serverValue === undefined && data.data) {
                serverValue = data.data[settingName];
            }
            if (serverValue === undefined && data.settings) {
                serverValue = data.settings[settingName];
            }

            // تحديث localStorage بالقيمة الجديدة
            if (serverValue !== undefined) {
                this.save(settingName, serverValue);

                // تحديث الواجهة إذا اختلفت القيمة
                if (JSON.stringify(serverValue) !== JSON.stringify(cachedValue)) {
                    onUpdate(serverValue, false); // false = من server
                }
            }

            return serverValue;
        } catch (error) {
            console.error(`❌ فشل جلب ${settingName} من السيرفر:`, error);
            return cachedValue;
        }
    }

    /**
     * حفظ إعدادات متعددة دفعة واحدة
     */
    saveMultiple(settings) {
        Object.entries(settings).forEach(([key, value]) => {
            this.save(key, value);
        });
    }

    /**
     * جلب إعدادات متعددة دفعة واحدة
     */
    getMultiple(settingNames, defaults = {}) {
        const result = {};
        settingNames.forEach(name => {
            result[name] = this.get(name, defaults[name]);
        });
        return result;
    }
}

// إنشاء instance عام
const settingsCache = new SettingsCache();

// تصدير للاستخدام في ملفات أخرى
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        SettingsCache,
        settingsCache
    };
}