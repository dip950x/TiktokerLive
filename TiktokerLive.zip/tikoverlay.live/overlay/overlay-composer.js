/* ==========================================
   Overlay Composer JavaScript
   ========================================== */

// متغيرات عامة
let composerWidgets = [];
let selectedWidget = null;
let isDragging = false;
let isResizing = false;
let dragStartX = 0;
let dragStartY = 0;
let widgetStartX = 0;
let widgetStartY = 0;
let canvasWidth = 1920;
let canvasHeight = 1080;
let widgetIdCounter = 0;
let rafId = null; // لتتبع requestAnimationFrame
// لوحة حالة مفاتيح الكيبورد للحركة
let keysPressed = {};
let keyboardMoveRafId = null;
let lastKeyboardMoveTime = 0;
const KEYBOARD_MOVE_STEP = 1; // بكسل لكل "خطوة" عند الضغط
const KEYBOARD_MOVE_INTERVAL = 10; // مللي ثانية بين كل خطوة أثناء الاستمرار

// تهيئة Overlay Composer عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    // تحديث رابط Composer
    updateComposerViewUrl();

    // ملاحظة: loadComposerLayout() يتم استدعاؤه من dashboard.js عند فتح الصفحة
    // لضمان أن currentUser.user_id محمل بالفعل

    // إضافة مستمعي الأحداث
    setupCanvasEventListeners();

    // تطبيق العرض الافتراضي مع تأخير للتأكد من تحميل DOM
    setTimeout(() => updateCanvasDisplay(), 200);
    setTimeout(() => updateCanvasDisplay(), 500);
});

// إعادة حساب scale عند تغيير حجم النافذة
window.addEventListener('resize', function() {
    clearTimeout(window.resizeTimer);
    window.resizeTimer = setTimeout(() => updateCanvasDisplay(), 100);
});

// تحديث رابط العرض النهائي
function updateComposerViewUrl() {
    const composerViewUrl = document.getElementById('composerViewUrl');
    if (composerViewUrl && widgetToken) {
        const baseUrl = window.location.origin;
        composerViewUrl.textContent = `${baseUrl}/overlay-composer-view?token=${widgetToken}`;
    }
}

// تطبيق preset الأبعاد
function applyCanvasPreset() {
    const preset = document.getElementById('canvasSizePreset').value;
    const customToolbar = document.getElementById('canvasCustomToolbar');

    if (preset === 'custom') {
        if (customToolbar) {
            customToolbar.style.display = 'flex';
        }
    } else {
        if (customToolbar) {
            customToolbar.style.display = 'none';
        }
        const [width, height] = preset.split('x').map(Number);
        setCanvasDimensions(width, height);
    }
}

// تطبيق الأبعاد المخصصة
function applyCustomDimensions() {
    const width = parseInt(document.getElementById('canvasWidth').value);
    const height = parseInt(document.getElementById('canvasHeight').value);

    if (width >= 100 && width <= 3840 && height >= 100 && height <= 2160) {
        setCanvasDimensions(width, height);
        showMessage('تم تطبيق الأبعاد المخصصة', 'success');
    } else {
        showMessage('الأبعاد غير صالحة. يجب أن تكون بين 100 و 3840/2160', 'error');
    }
}

// تعيين أبعاد Canvas
function setCanvasDimensions(width, height) {
    canvasWidth = width;
    canvasHeight = height;

    const dimensionsDisplay = document.getElementById('canvasDimensionsDisplay');
    dimensionsDisplay.textContent = `${width} × ${height}`;

    // تحديث العرض
    updateCanvasDisplay();
}

// تحديث عرض Canvas مع scale تلقائي
function updateCanvasDisplay() {
    const canvas = document.getElementById('composerCanvas');
    const wrapper = document.getElementById('composerCanvasWrapper');

    if (!canvas || !wrapper) return;

    // تعيين الأبعاد المنطقية (الحقيقية) للـ Canvas
    canvas.style.width = `${canvasWidth}px`;
    canvas.style.height = `${canvasHeight}px`;

    // الحصول على المساحة الفعلية المتاحة (بعد انتظار render)
    requestAnimationFrame(() => {
        // طرح الـ padding من المساحة المتاحة (20px من كل جانب = 40px)
        const wrapperWidth = wrapper.clientWidth - 40;
        const wrapperHeight = wrapper.clientHeight - 40;

        // حساب scale ليظهر Canvas كاملاً بدون scroll مع هامش أمان
        const scaleX = wrapperWidth / canvasWidth;
        const scaleY = wrapperHeight / canvasHeight;
        const scale = Math.min(scaleX, scaleY, 1); // لا نكبر أكبر من الحجم الأصلي

        // تطبيق الـ scale (center center يجعله في المنتصف)
        canvas.style.transform = `scale(${scale})`;


    });
}


// فتح نافذة اختيار Widget
function openWidgetSelector() {
    const modal = document.getElementById('widgetSelectorModal');
    modal.style.display = 'flex';
}

// إغلاق نافذة اختيار Widget
function closeWidgetSelector() {
    const modal = document.getElementById('widgetSelectorModal');
    modal.style.display = 'none';
}

// إضافة Widget إلى Canvas
async function addWidgetToCanvas(type) {
    if (!widgetToken) {
        showMessage('يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    // إنشاء Widget جديد (الطبقة الجديدة تكون في الأعلى)
    const maxZIndex = composerWidgets.length > 0 ?
        Math.max(...composerWidgets.map(w => w.zIndex)) :
        0;

    const widget = {
        id: `widget-${++widgetIdCounter}`,
        type: type,
        x: 100,
        y: 100,
        width: 800,
        height: 600,
        scale: 1,
        zIndex: maxZIndex + 1,
        visible: true,
        locked: false,
        url: await getWidgetUrl(type)
    };

    composerWidgets.push(widget);
    renderWidget(widget);
    selectWidgetInCanvas(widget.id);
    closeWidgetSelector();
    showMessage(`تم إضافة ${getWidgetName(type)}`, 'success');
}

// الحصول على URL الخاص بـ Widget
async function getWidgetUrl(type) {
    const baseUrl = window.location.origin;
    const token = widgetToken;

    // للويدجتات الخاصة بالتصاميم (podium, podium-supporters)، نجلب التصميم المحفوظ
    if (type === 'podium' && currentUser) {
        try {
            const response = await fetch('/api/user-theme/likers', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'x-user-id': currentUser.id
                }
            });

            if (response.ok) {
                const data = await response.json();
                const theme = data.theme || 'horizontal-podium';

                // تحديد URL بناءً على التصميم
                if (theme === 'bear-top3') {
                    return `/widgets/bear-top3/bear-top3.html?token=${token}`;
                } else if (theme === 'cyber-blade-podium') {
                    return `/widgets/podium/Podium.html?token=${token}`;
                } else {
                    return `/widgets/podium/horizontal-podium.html?token=${token}`;
                }
            }
        } catch (error) {
            console.error('خطأ في جلب التصميم:', error);
        }
    }

    const widgetUrls = {
        'comments': `/widget/comments?token=${token}`,
        'likes': `/widget/likes?token=${token}`,
        'follows': `/widget/follows?token=${token}`,
        'podium': `/widget/horizontal-podium?token=${token}`,
        'podium-supporters': `/widget/horizontal-podium-supporters?token=${token}`,
        'tts': `/widget/tts?token=${token}&isDashboardView=true`,
        'heart-me-goal': `/widgets/goals/heart-me-goal/heart_me_goal.html?token=${token}`,
        'like-goal': `/widget/like-goal?token=${token}`,
        'follow-goal': `/widget/follow-goal?token=${token}`,
        'share-goal': `/widget/share-goal?token=${token}`,
        'screen1': `/overlay/overlay.html?token=${token}&screen=1&isDashboardView=true`,
        'screen2': `/overlay/overlay.html?token=${token}&screen=2&isDashboardView=true`,
        'screen3': `/overlay/overlay.html?token=${token}&screen=3&isDashboardView=true`,
        'screen4': `/overlay/overlay.html?token=${token}&screen=4&isDashboardView=true`,
        'screen5': `/overlay/overlay.html?token=${token}&screen=5&isDashboardView=true`,
        'firework': `/widget/firework?token=${token}&isDashboardView=true`,
        'like-hearts': `/widget/like-hearts?token=${token}&isDashboardView=true`
    };

    return widgetUrls[type] || '';
}

// الحصول على اسم Widget بالعربية
function getWidgetName(type) {
    const names = {
        'comments': 'التعليقات',
        'likes': 'الإعجابات',
        'follows': 'المتابعات',
        'podium': 'أفضل المتفاعلين',
        'podium-supporters': 'أفضل الداعمين',
        'tts': 'قارئ التعليقات',
        'heart-me-goal': 'هدف Heart Me',
        'like-goal': 'هدف اللايكات',
        'follow-goal': 'هدف المتابعة',
        'share-goal': 'هدف المشاركة',
        'screen1': 'Screen 1',
        'screen2': 'Screen 2',
        'screen3': 'Screen 3',
        'screen4': 'Screen 4',
        'firework': 'الألعاب النارية',
        'like-hearts': 'قلوب اللايكات',
        'screen5': 'Screen 5'
    };
    return names[type] || type;
}

// رسم Widget في Canvas
function renderWidget(widget) {
    const canvas = document.getElementById('composerCanvas');

    // تهيئة scale إذا لم يكن موجوداً
    if (!widget.scale) widget.scale = 1;

    // إنشاء عنصر Widget
    const widgetElement = document.createElement('div');
    widgetElement.className = 'canvas-widget';
    widgetElement.id = widget.id;
    // عرض الويدجت بالحجم الفعلي
    widgetElement.style.left = `${widget.x}px`;
    widgetElement.style.top = `${widget.y}px`;
    widgetElement.style.width = `${widget.width}px`;
    widgetElement.style.height = `${widget.height}px`;
    widgetElement.style.zIndex = widget.zIndex;
    // تطبيق Scale من نقطة المنتصف
    widgetElement.style.transform = `scale(${widget.scale})`;
    widgetElement.style.transformOrigin = 'center center';

    if (!widget.visible) {
        widgetElement.classList.add('hidden');
    }

    if (widget.locked) {
        widgetElement.classList.add('locked');
        widgetElement.style.pointerEvents = 'none';
    }

    // إضافة Label
    const label = document.createElement('div');
    label.className = 'widget-label';
    label.textContent = getWidgetName(widget.type);
    widgetElement.appendChild(label);

    // إضافة iframe للمعاينة مع تحميل سلس
    const iframe = document.createElement('iframe');
    iframe.className = 'widget-iframe';
    // 🔇 كتم الصوت في الـ canvas داخل الداشبورد
    const urlWithMute = widget.url + (widget.url.includes('?') ? '&' : '?') + 'muteSound=true';
    iframe.src = urlWithMute;
    iframe.style.pointerEvents = 'none';
    // إخفاء iframe حتى يكتمل تحميله لتجنب رؤية حالة التحميل
    iframe.style.opacity = '0';
    iframe.style.transition = 'opacity 0.3s ease-in-out';

    // الاستماع لحدث اكتمال التحميل
    iframe.addEventListener('load', () => {
        // إضافة تأخير صغير (300ms) لضمان اكتمال rendering الداخلي وتحميل الإعدادات
        setTimeout(() => {
            iframe.style.opacity = '1';
        }, 300);
    });

    // في حالة فشل التحميل، نعرض iframe بعد 2 ثانية على أي حال
    setTimeout(() => {
        if (iframe.style.opacity === '0') {
            iframe.style.opacity = '1';
        }
    }, 2000);

    widgetElement.appendChild(iframe);

    // إضافة مستمعي الأحداث
    widgetElement.addEventListener('mousedown', onWidgetMouseDown);
    widgetElement.addEventListener('click', (e) => {
        e.stopPropagation();
        // اختيار أعلى طبقة في موضع النقرة
        const topWidget = getTopWidgetAtPosition(e.clientX, e.clientY);
        if (topWidget) {
            selectWidgetInCanvas(topWidget.id);
        }
    });

    canvas.appendChild(widgetElement);

    // تحديث قائمة الطبقات
    updateLayersList();

    // تحديث طبقة التحديد إذا كان هذا الويدجت هو المحدد
    if (selectedWidget === widget.id) {
        updateSelectionOverlay();
    }
}

// إعادة رسم جميع الويدجتات
function renderAllWidgets() {
    const canvas = document.getElementById('composerCanvas');
    canvas.innerHTML = '';

    // إعادة إنشاء طبقة التحديد
    createSelectionOverlay();

    composerWidgets.forEach(widget => renderWidget(widget));
    updateLayersList();

    // تحديث موقع طبقة التحديد
    updateSelectionOverlay();
}

// إنشاء طبقة التحديد (Selection Overlay)
function createSelectionOverlay() {
    const canvas = document.getElementById('composerCanvas');
    if (!canvas) return;

    let overlay = document.getElementById('composerSelectionOverlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'composerSelectionOverlay';
        overlay.className = 'selection-overlay';
        // تنسيقات أساسية
        overlay.style.position = 'absolute';
        overlay.style.pointerEvents = 'none'; // السماح بالنقر خلال الصندوق نفسه
        overlay.style.zIndex = '999999'; // دائماً في الأعلى
        overlay.style.display = 'none';
        overlay.style.border = '2px solid #007bff'; // إطار التحديد
        overlay.style.boxSizing = 'border-box'; // لضمان أن الإطار داخل الأبعاد

        // إضافة مقابض التحجيم
        const resizeHandles = document.createElement('div');
        resizeHandles.className = 'widget-resize-handles';
        ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].forEach(pos => {
            const handle = document.createElement('div');
            handle.className = `resize-handle ${pos}`;
            handle.dataset.position = pos;
            handle.style.pointerEvents = 'auto'; // تفعيل النقر على المقابض

            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation();
                if (selectedWidget) {
                    onResizeHandleMouseDown(e, selectedWidget, pos);
                }
            });

            resizeHandles.appendChild(handle);
        });
        overlay.appendChild(resizeHandles);
        canvas.appendChild(overlay);
    }

    // التأكد من أن الطبقة هي آخر عنصر (لتكون فوق الجميع)
    if (canvas.lastElementChild !== overlay) {
        canvas.appendChild(overlay);
    }
}

// تحديث موقع وحجم طبقة التحديد
function updateSelectionOverlay() {
    const overlay = document.getElementById('composerSelectionOverlay');
    if (!overlay) return;

    if (!selectedWidget) {
        overlay.style.display = 'none';
        return;
    }

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget || !widget.visible) {
        overlay.style.display = 'none';
        return;
    }

    overlay.style.display = 'block';
    overlay.style.left = `${widget.x}px`;
    overlay.style.top = `${widget.y}px`;
    overlay.style.width = `${widget.width}px`;
    overlay.style.height = `${widget.height}px`;
    overlay.style.transform = `scale(${widget.scale || 1})`;
    overlay.style.transformOrigin = 'center center';

    // تحديث لون الإطار حسب حالة القفل
    overlay.style.borderColor = widget.locked ? '#ff4444' : '#007bff';

    // إخفاء المقابض إذا كان مقفلاً
    const handles = overlay.querySelector('.widget-resize-handles');
    if (handles) {
        handles.style.display = widget.locked ? 'none' : 'block';

        // عكس التكبير للمقابض لتبقى بحجم ثابت
        const inverseScale = 1 / (widget.scale || 1);
        handles.querySelectorAll('.resize-handle').forEach(handle => {
            handle.style.transform = `scale(${inverseScale})`;
        });
    }
}

// تحديث قائمة الطبقات
function updateLayersList() {
    const layersList = document.getElementById('layersList');
    const layersCount = document.getElementById('layersCount');

    if (!layersList) return;

    // تحديث العدد
    if (layersCount) {
        layersCount.textContent = composerWidgets.length;
    }

    // إذا لم يكن هناك ويدجتات
    if (composerWidgets.length === 0) {
        layersList.innerHTML = `
            <div class="no-layers">
                <span>لا توجد طبقات</span>
                <p>اضغط "➕ إضافة Widget" للبدء</p>
            </div>
        `;
        return;
    }

    // رسم الطبقات (مرتبة حسب Z-Index من الأعلى للأسفل)
    layersList.innerHTML = '';
    const sortedWidgets = [...composerWidgets].sort((a, b) => b.zIndex - a.zIndex);

    sortedWidgets.forEach((widget, index) => {
        const layerItem = document.createElement('div');
        layerItem.className = 'layer-item';
        layerItem.id = `layer-${widget.id}`;
        layerItem.draggable = true;
        layerItem.dataset.widgetId = widget.id;

        if (selectedWidget === widget.id) {
            layerItem.classList.add('active');
        }

        // الأيقونة
        const icon = getWidgetIcon(widget.type);

        layerItem.innerHTML = `
            <div class="layer-drag-handle" title="سحب لإعادة الترتيب">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="3" y1="9" x2="21" y2="9"></line>
                    <line x1="3" y1="15" x2="21" y2="15"></line>
                </svg>
            </div>
            <div class="layer-icon">${icon}</div>
            <div class="layer-info">
                <div class="layer-name">${getWidgetName(widget.type)}</div>
                <div class="layer-details">${Math.round(widget.width)}X${Math.round(widget.height)}</div>
            </div>
            <div class="layer-actions">
                <button class="layer-action-btn visibility-btn" onclick="toggleWidgetVisibilityFromLayer('${widget.id}')" title="${widget.visible ? 'إخفاء' : 'إظهار'}">
                    ${widget.visible ? 
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>' : 
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'}
                </button>
                <button class="layer-action-btn lock-btn" onclick="toggleWidgetLockFromLayer('${widget.id}')" title="${widget.locked ? 'إلغاء القفل' : 'قفل'}">
                    ${widget.locked ? 
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>' : 
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>'}
                </button>
                <button class="layer-action-btn center-btn" onclick="centerWidgetFromLayer('${widget.id}')" title="توسيط">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
                <button class="layer-action-btn expand-btn" onclick="expandWidgetFullscreen('${widget.id}')" title="توسيع لملء الشاشة">
                    <svg viewBox="0 0 24 24"  stroke="currentColor" stroke-width="2">
                        <polyline points="15 3 21 3 21 9"></polyline>
                        <polyline points="9 21 3 21 3 15"></polyline>
                        <line x1="21" y1="3" x2="14" y2="10"></line>
                        <line x1="3" y1="21" x2="10" y2="14"></line>
                    </svg>
                </button>
                <button class="layer-action-btn settings-btn" onclick="openWidgetPropertiesFromLayer('${widget.id}')" title="خصائص">
                    <i class="fas fa-cog" aria-hidden="true"></i>
                </button>
                <button class="layer-action-btn delete-btn" onclick="deleteWidgetFromLayer('${widget.id}')" title="حذف">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                        <line x1="14" y1="11" x2="14" y2="17"></line>
                    </svg>
                </button>
            </div>
        `;

        // عند الضغط على الطبقة
        layerItem.addEventListener('click', (e) => {
            // تجاهل إذا كان الضغط على الأزرار
            if (e.target.closest('.layer-actions')) return;
            selectWidgetFromLayer(widget.id);
        });

        // أحداث السحب والإفلات
        layerItem.addEventListener('dragstart', onLayerDragStart);
        layerItem.addEventListener('dragover', onLayerDragOver);
        layerItem.addEventListener('drop', onLayerDrop);
        layerItem.addEventListener('dragend', onLayerDragEnd);

        layersList.appendChild(layerItem);
    });
}

// الحصول على أيقونة Widget
function getWidgetIcon(type) {
    const icons = {
        'comments': '💬',
        'likes': '❤️',
        'follows': '👥',
        'podium': '🏆',
        'podium-supporters': '🥇',
        'tts': '🔊',
        'heart-me-goal': '💖',
        'like-goal': '❤️',
        'follow-goal': '👥',
        'share-goal': '📤',
        'screen1': '🖥️',
        'screen2': '🖥️',
        'screen3': '🖥️',
        'screen4': '🖥️',
        'screen5': '🖥️',
        'firework': '🎆',
        'like-hearts': '💗'
    };
    return icons[type] || '📦';
}

// متغيرات السحب والإفلات للطبقات
let draggedLayerId = null;

// الحصول على أعلى Widget (أعلى Z-Index) في موضع معين
function getTopWidgetAtPosition(clientX, clientY) {
    const canvas = document.getElementById('composerCanvas');
    if (!canvas) return null;

    const canvasRect = canvas.getBoundingClientRect();
    const currentScale = parseFloat(canvas.style.transform.match(/scale\(([^)]+)\)/) ? .[1] || 1);

    // تحويل إحداثيات الشاشة إلى إحداثيات Canvas
    const canvasX = (clientX - canvasRect.left) / currentScale;
    const canvasY = (clientY - canvasRect.top) / currentScale;

    // البحث عن جميع الطبقات في هذا الموضع
    const widgetsAtPosition = composerWidgets.filter(w => {
        if (!w.visible || w.locked) return false;

        // حساب الأبعاد الظاهرية مع Scale (من المنتصف)
        const scale = w.scale || 1;
        const scaledWidth = w.width * scale;
        const scaledHeight = w.height * scale;

        const centerX = w.x + w.width / 2;
        const centerY = w.y + w.height / 2;

        const visualLeft = centerX - scaledWidth / 2;
        const visualRight = centerX + scaledWidth / 2;
        const visualTop = centerY - scaledHeight / 2;
        const visualBottom = centerY + scaledHeight / 2;

        return canvasX >= visualLeft && canvasX <= visualRight &&
            canvasY >= visualTop && canvasY <= visualBottom;
    });

    // إرجاع الطبقة ذات أعلى Z-Index
    if (widgetsAtPosition.length === 0) return null;
    return widgetsAtPosition.reduce((top, current) =>
        current.zIndex > top.zIndex ? current : top
    );
}

// بداية سحب طبقة
function onLayerDragStart(e) {
    draggedLayerId = e.currentTarget.dataset.widgetId;
    e.currentTarget.style.opacity = '0.5';
    e.dataTransfer.effectAllowed = 'move';
}

// عند تمرير طبقة فوق أخرى
function onLayerDragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';

    // إزالة التأثيرات من جميع الطبقات
    document.querySelectorAll('.layer-item').forEach(item => {
        item.style.background = '';
        item.style.transform = '';
    });

    const targetLayer = e.currentTarget;
    if (targetLayer.dataset.widgetId !== draggedLayerId) {
        targetLayer.style.background = 'linear-gradient(90deg, rgba(102, 126, 234, 0.15), rgba(118, 75, 162, 0.15))';
        targetLayer.style.transform = 'scale(1.02)';
    }
}

// عند إفلات طبقة
function onLayerDrop(e) {
    e.preventDefault();
    e.stopPropagation();

    const targetWidgetId = e.currentTarget.dataset.widgetId;

    if (draggedLayerId && draggedLayerId !== targetWidgetId) {
        // إعادة ترتيب الطبقات
        reorderLayers(draggedLayerId, targetWidgetId);
    }

    // إزالة التأثيرات البصرية
    e.currentTarget.style.background = '';
    e.currentTarget.style.transform = '';
}

// نهاية السحب
function onLayerDragEnd(e) {
    e.currentTarget.style.opacity = '1';

    // إزالة التأثيرات البصرية
    document.querySelectorAll('.layer-item').forEach(item => {
        item.style.background = '';
        item.style.transform = '';
    });

    draggedLayerId = null;
}

// إعادة ترتيب الطبقات وتحديث Z-Index
function reorderLayers(draggedId, targetId) {
    const draggedWidget = composerWidgets.find(w => w.id === draggedId);
    const targetWidget = composerWidgets.find(w => w.id === targetId);

    if (!draggedWidget || !targetWidget) return;

    // ترتيب الطبقات حسب Z-Index (من الأعلى للأسفل) - نفس ترتيب العرض
    const sortedWidgets = [...composerWidgets].sort((a, b) => b.zIndex - a.zIndex);

    // إيجاد المواقع في المصفوفة المرتبة
    const draggedIndex = sortedWidgets.findIndex(w => w.id === draggedId);
    const targetIndex = sortedWidgets.findIndex(w => w.id === targetId);

    if (draggedIndex === -1 || targetIndex === -1) return;

    // إزالة العنصر المسحوب من المصفوفة المرتبة
    sortedWidgets.splice(draggedIndex, 1);

    // إدراجه في الموضع الجديد
    sortedWidgets.splice(targetIndex, 0, draggedWidget);

    // إعادة تعيين Z-Index بناءً على الترتيب الجديد (من الأعلى = أعلى Z-Index)
    sortedWidgets.forEach((widget, index) => {
        widget.zIndex = sortedWidgets.length - index;
    });

    // تحديث العرض
    renderAllWidgets();
    showMessage('تم إعادة ترتيب الطبقات', 'success');
}

// تطبيع Z-Index (جعلها متسلسلة من 1 إلى n)
function normalizeZIndex() {
    const sorted = [...composerWidgets].sort((a, b) => a.zIndex - b.zIndex);
    sorted.forEach((widget, index) => {
        widget.zIndex = index + 1;
        const widgetElement = document.getElementById(widget.id);
        if (widgetElement) {
            widgetElement.style.zIndex = widget.zIndex;
        }
    });
}

// اختيار Widget من قائمة الطبقات
function selectWidgetFromLayer(widgetId) {
    selectWidgetInCanvas(widgetId);
}

// اختيار Widget في Canvas فقط (بدون فتح النافذة)
function selectWidgetInCanvas(widgetId) {
    // إلغاء التحديد من الويدجت السابق
    if (selectedWidget) {
        const prevElement = document.getElementById(selectedWidget);
        if (prevElement) {
            prevElement.classList.remove('selected');
        }
        const prevLayer = document.getElementById(`layer-${selectedWidget}`);
        if (prevLayer) {
            prevLayer.classList.remove('active');
        }
    }

    selectedWidget = widgetId;

    // تحديد الويدجت الجديد
    const widgetElement = document.getElementById(widgetId);
    if (widgetElement) {
        widgetElement.classList.add('selected');
    }

    // تحديد في قائمة الطبقات
    const layerElement = document.getElementById(`layer-${widgetId}`);
    if (layerElement) {
        layerElement.classList.add('active');
        // التمرير إليه
        layerElement.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest'
        });
    }

    updateSelectionOverlay();
}

// فتح نافذة الخصائص من قائمة الطبقات
function openWidgetPropertiesFromLayer(widgetId) {
    selectedWidget = widgetId;
    selectWidgetInCanvas(widgetId);
    openWidgetProperties();
}

// تبديل الإظهار/الإخفاء من قائمة الطبقات
function toggleWidgetVisibilityFromLayer(widgetId) {
    const widget = composerWidgets.find(w => w.id === widgetId);
    if (!widget) return;

    widget.visible = !widget.visible;

    const widgetElement = document.getElementById(widgetId);
    if (widget.visible) {
        widgetElement.classList.remove('hidden');
    } else {
        widgetElement.classList.add('hidden');
    }

    updateLayersList();

    if (selectedWidget === widgetId) {
        updateSelectionOverlay();
    }
}

// قفل/إلغاء قفل من قائمة الطبقات
function toggleWidgetLockFromLayer(widgetId) {
    const widget = composerWidgets.find(w => w.id === widgetId);
    if (!widget) return;

    widget.locked = !widget.locked;

    const widgetElement = document.getElementById(widgetId);
    if (widget.locked) {
        widgetElement.classList.add('locked');
        // تجاهل أحداث الماوس عند القفل
        widgetElement.style.pointerEvents = 'none';
    } else {
        widgetElement.classList.remove('locked');
        widgetElement.style.pointerEvents = 'all';
    }

    updateLayersList();
    showMessage(widget.locked ? '🔒 تم قفل الطبقة' : '🔓 تم إلغاء قفل الطبقة', 'success');

    if (selectedWidget === widgetId) {
        updateSelectionOverlay();
    }
}

// توسيط Widget من قائمة الطبقات
function centerWidgetFromLayer(widgetId) {
    const widget = composerWidgets.find(w => w.id === widgetId);
    if (!widget) return;

    // حساب موضع الوسط
    widget.x = (canvasWidth - widget.width) / 2;
    widget.y = (canvasHeight - widget.height) / 2;

    // تحديث العنصر
    const widgetElement = document.getElementById(widgetId);
    if (widgetElement) {
        widgetElement.style.left = `${widget.x}px`;
        widgetElement.style.top = `${widget.y}px`;
    }

    // تحديد الويدجت وتحديث لوحة الخصائص
    selectWidgetInCanvas(widgetId);
    updateWidgetPropertiesPanel();
    updateLayersList();
    showMessage('تم توسيط Widget', 'success');
}

// توسيع Widget ليملأ الشاشة بالكامل
function expandWidgetFullscreen(widgetId) {
    const widget = composerWidgets.find(w => w.id === widgetId);
    if (!widget) return;

    // جعل الويدجت بنفس حجم الشاشة
    widget.width = canvasWidth;
    widget.height = canvasHeight;
    widget.x = 0;
    widget.y = 0;
    widget.scale = 1; // إعادة تعيين Scale

    // تحديث العنصر
    const widgetElement = document.getElementById(widgetId);
    if (widgetElement) {
        widgetElement.style.width = `${widget.width}px`;
        widgetElement.style.height = `${widget.height}px`;
        widgetElement.style.left = `${widget.x}px`;
        widgetElement.style.top = `${widget.y}px`;
        widgetElement.style.transform = `scale(${widget.scale})`;
    }

    // تحديد الويدجت وتحديث لوحة الخصائص
    selectWidgetInCanvas(widgetId);
    updateWidgetPropertiesPanel();
    updateLayersList();
    showMessage('تم توسيع Widget لملء الشاشة', 'success');
}

// حذف Widget من قائمة الطبقات
async function deleteWidgetFromLayer(widgetId) {
    const widgetIndex = composerWidgets.findIndex(w => w.id === widgetId);
    if (widgetIndex === -1) return;

    const confirmed = await showConfirmDialog(
        'حذف الويدجت',
        'هل أنت متأكد من حذف هذا الويدجت؟'
    );

    if (confirmed) {
        composerWidgets.splice(widgetIndex, 1);

        const widgetElement = document.getElementById(widgetId);
        if (widgetElement) {
            widgetElement.remove();
        }

        if (selectedWidget === widgetId) {
            selectedWidget = null;
        }

        updateLayersList();
        updateSelectionOverlay();
        showMessage('تم حذف Widget', 'success');
    }
}

// عند الضغط على Widget
function onWidgetMouseDown(e) {
    // البحث عن أعلى Widget في موضع النقرة
    const topWidget = getTopWidgetAtPosition(e.clientX, e.clientY);

    if (!topWidget || topWidget.locked) return;

    if (e.target.classList.contains('resize-handle')) return;

    isDragging = true;
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    widgetStartX = topWidget.x;
    widgetStartY = topWidget.y;

    selectWidgetInCanvas(topWidget.id);

    document.addEventListener('mousemove', onWidgetMouseMove);
    document.addEventListener('mouseup', onWidgetMouseUp);

    e.preventDefault();
    e.stopPropagation();
}

// عند تحريك الماوس (سحب Widget)
function onWidgetMouseMove(e) {
    if (!isDragging || !selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    // حساب الحركة مع أخذ scale في الاعتبار
    const canvas = document.getElementById('composerCanvas');
    const currentScale = canvas ? parseFloat(canvas.style.transform.match(/scale\(([^)]+)\)/) ? .[1] || 1) : 1;

    const deltaX = (e.clientX - dragStartX) / currentScale;
    const deltaY = (e.clientY - dragStartY) / currentScale;

    // الموقع الجديد المقترح
    let newX = widgetStartX + deltaX;
    let newY = widgetStartY + deltaY;

    // --- منطق المغناطيس (Snapping) ---
    const SNAP_THRESHOLD = 15; // قوة المغناطيس (بكسل)
    const scale = widget.scale || 1;

    // حساب الأبعاد الظاهرية للويدجت الحالي
    const scaledWidth = widget.width * scale;
    const scaledHeight = widget.height * scale;
    const offsetX = (scaledWidth - widget.width) / 2;
    const offsetY = (scaledHeight - widget.height) / 2;

    const visualLeft = newX - offsetX;
    const visualRight = newX + widget.width + offsetX;
    const visualTop = newY - offsetY;
    const visualBottom = newY + widget.height + offsetY;
    const visualCenterX = newX + widget.width / 2;
    const visualCenterY = newY + widget.height / 2;

    // خطوط الشبكة للمغناطيس (حواف الكانفا + المنتصف)
    const snapLinesX = [{
            value: 0
        },
        {
            value: canvasWidth
        },
        {
            value: canvasWidth / 2
        }
    ];
    const snapLinesY = [{
            value: 0
        },
        {
            value: canvasHeight
        },
        {
            value: canvasHeight / 2
        }
    ];

    // إضافة حواف الويدجتات الأخرى للمغناطيس
    composerWidgets.forEach(otherWidget => {
        if (otherWidget.id === widget.id || !otherWidget.visible) return;

        const otherScale = otherWidget.scale || 1;
        const otherScaledWidth = otherWidget.width * otherScale;
        const otherScaledHeight = otherWidget.height * otherScale;

        // حساب المركز والحواف البصرية للويدجت الآخر
        const otherCenterX = otherWidget.x + otherWidget.width / 2;
        const otherCenterY = otherWidget.y + otherWidget.height / 2;

        const otherLeft = otherCenterX - otherScaledWidth / 2;
        const otherRight = otherCenterX + otherScaledWidth / 2;
        const otherTop = otherCenterY - otherScaledHeight / 2;
        const otherBottom = otherCenterY + otherScaledHeight / 2;

        snapLinesX.push({
            value: otherLeft
        });
        snapLinesX.push({
            value: otherRight
        });
        snapLinesX.push({
            value: otherCenterX
        });

        snapLinesY.push({
            value: otherTop
        });
        snapLinesY.push({
            value: otherBottom
        });
        snapLinesY.push({
            value: otherCenterY
        });
    });

    // التحقق من المغناطيس الأفقي (X)
    let snappedX = false;

    // 1. اليسار مع خطوط الشبكة
    for (const line of snapLinesX) {
        if (Math.abs(visualLeft - line.value) < SNAP_THRESHOLD) {
            newX = line.value + offsetX;
            snappedX = true;
            break;
        }
    }

    // 2. اليمين مع خطوط الشبكة (إذا لم يتم الالتصاق باليسار)
    if (!snappedX) {
        for (const line of snapLinesX) {
            if (Math.abs(visualRight - line.value) < SNAP_THRESHOLD) {
                newX = line.value - widget.width - offsetX;
                snappedX = true;
                break;
            }
        }
    }

    // 3. المنتصف مع خطوط الشبكة (إذا لم يتم الالتصاق بالأطراف)
    if (!snappedX) {
        for (const line of snapLinesX) {
            if (Math.abs(visualCenterX - line.value) < SNAP_THRESHOLD) {
                newX = line.value - widget.width / 2;
                break;
            }
        }
    }

    // التحقق من المغناطيس العمودي (Y)
    let snappedY = false;

    // 1. الأعلى مع خطوط الشبكة
    for (const line of snapLinesY) {
        if (Math.abs(visualTop - line.value) < SNAP_THRESHOLD) {
            newY = line.value + offsetY;
            snappedY = true;
            break;
        }
    }

    // 2. الأسفل مع خطوط الشبكة
    if (!snappedY) {
        for (const line of snapLinesY) {
            if (Math.abs(visualBottom - line.value) < SNAP_THRESHOLD) {
                newY = line.value - widget.height - offsetY;
                snappedY = true;
                break;
            }
        }
    }

    // 3. المنتصف مع خطوط الشبكة
    if (!snappedY) {
        for (const line of snapLinesY) {
            if (Math.abs(visualCenterY - line.value) < SNAP_THRESHOLD) {
                newY = line.value - widget.height / 2;
                break;
            }
        }
    }

    widget.x = newX;
    widget.y = newY;

    // إلغاء التحديث السابق إن وُجد
    if (rafId) cancelAnimationFrame(rafId);

    // استخدام requestAnimationFrame لتحديث سلس
    rafId = requestAnimationFrame(() => {
        const widgetElement = document.getElementById(widget.id);
        if (widgetElement) {
            widgetElement.style.left = `${widget.x}px`;
            widgetElement.style.top = `${widget.y}px`;
        }
        updateSelectionOverlay();
        rafId = null;
    });
}

// عند رفع الماوس (إنهاء السحب)
function onWidgetMouseUp(e) {
    isDragging = false;
    document.removeEventListener('mousemove', onWidgetMouseMove);
    document.removeEventListener('mouseup', onWidgetMouseUp);

    // تقريب القيم لإزالة الكسور
    if (selectedWidget) {
        const widget = composerWidgets.find(w => w.id === selectedWidget);
        if (widget) {
            widget.x = Math.round(widget.x);
            widget.y = Math.round(widget.y);
            const widgetElement = document.getElementById(widget.id);
            if (widgetElement) {
                widgetElement.style.left = `${widget.x}px`;
                widgetElement.style.top = `${widget.y}px`;
            }
            updateSelectionOverlay();
        }
    }

    // تحديث بعد انتهاء السحب
    updateWidgetPropertiesPanel();
    updateLayersList();
}

// عند الضغط على مقبض التحجيم
let resizeStartWidth = 0;
let resizeStartHeight = 0;
let resizeStartScale = 1;
let resizePosition = '';

function onResizeHandleMouseDown(e, widgetId, position) {
    const widget = composerWidgets.find(w => w.id === widgetId);
    if (!widget || widget.locked) return;

    if (!widget.scale) widget.scale = 1;

    isResizing = true;
    resizePosition = position;
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    widgetStartX = widget.x;
    widgetStartY = widget.y;
    resizeStartWidth = widget.width;
    resizeStartHeight = widget.height;
    resizeStartScale = widget.scale;

    selectWidgetInCanvas(widgetId);

    document.addEventListener('mousemove', onResizeMouseMove);
    document.addEventListener('mouseup', onResizeMouseUp);

    e.preventDefault();
    e.stopPropagation();
}

// عند تحريك الماوس (تحجيم Widget)
function onResizeMouseMove(e) {
    if (!isResizing || !selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    // تهيئة scale إذا لم يكن موجوداً
    if (!widget.scale) widget.scale = 1;

    // حساب الحركة مع أخذ scale في الاعتبار
    const canvas = document.getElementById('composerCanvas');
    const currentScale = canvas ? parseFloat(canvas.style.transform.match(/scale\(([^)]+)\)/) ? .[1] || 1) : 1;

    const deltaX = (e.clientX - dragStartX) / currentScale;
    const deltaY = (e.clientY - dragStartY) / currentScale;

    // التحقق من ضغط ALT+SHIFT (وضع القص/Crop)
    const isCropMode = e.altKey && e.shiftKey;

    if (isCropMode) {
        // وضع القص: تغيير الأبعاد الفعلية
        // الأطراف الأفقية (e, w) - تغيير العرض فقط
        if (resizePosition === 'e') {
            widget.width = Math.max(50, resizeStartWidth + deltaX);
        } else if (resizePosition === 'w') {
            const newWidth = Math.max(50, resizeStartWidth - deltaX);
            const newX = widgetStartX + (resizeStartWidth - newWidth) * widget.scale;
            widget.width = newWidth;
            widget.x = newX;
        }

        // الأطراف الرأسية (n, s) - تغيير الارتفاع فقط
        if (resizePosition === 'n') {
            const newHeight = Math.max(50, resizeStartHeight - deltaY);
            const newY = widgetStartY + (resizeStartHeight - newHeight) * widget.scale;
            widget.height = newHeight;
            widget.y = newY;
        } else if (resizePosition === 's') {
            widget.height = Math.max(50, resizeStartHeight + deltaY);
        }

        // الزوايا - تغيير العرض والارتفاع معاً
        if (resizePosition.includes('e') && resizePosition.length > 1) {
            widget.width = Math.max(50, resizeStartWidth + deltaX);
        }
        if (resizePosition.includes('w') && resizePosition.length > 1) {
            const newWidth = Math.max(50, resizeStartWidth - deltaX);
            const newX = widgetStartX + (resizeStartWidth - newWidth) * widget.scale;
            widget.width = newWidth;
            widget.x = newX;
        }
        if (resizePosition.includes('s') && resizePosition.length > 1) {
            widget.height = Math.max(50, resizeStartHeight + deltaY);
        }
        if (resizePosition.includes('n') && resizePosition.length > 1) {
            const newHeight = Math.max(50, resizeStartHeight - deltaY);
            const newY = widgetStartY + (resizeStartHeight - newHeight) * widget.scale;
            widget.height = newHeight;
            widget.y = newY;
        }
    } else {
        // الوضع العادي: تطبيق Scale فقط (الأبعاد ثابتة)
        // حساب العرض/الارتفاع المطلوب بناءً على السحب
        let targetWidth = resizeStartWidth;
        let targetHeight = resizeStartHeight;

        // تحديد البعد المستهدف حسب موضع المقبض
        if (resizePosition.includes('e')) {
            targetWidth = Math.max(50, resizeStartWidth + deltaX);
        } else if (resizePosition.includes('w')) {
            targetWidth = Math.max(50, resizeStartWidth - deltaX);
        }

        if (resizePosition.includes('s')) {
            targetHeight = Math.max(50, resizeStartHeight + deltaY);
        } else if (resizePosition.includes('n')) {
            targetHeight = Math.max(50, resizeStartHeight - deltaY);
        }

        // حساب نسبة التغيير
        let scaleMultiplier;

        // التحقق مما إذا كان التحجيم من الجوانب فقط (ليس زاوية)
        // الجوانب: n, s, e, w (طول النص 1)
        // الزوايا: ne, nw, se, sw (طول النص 2)
        if (resizePosition.length === 1) {
            if (resizePosition === 'e' || resizePosition === 'w') {
                // تغيير أفقي فقط - نعتمد على تغير العرض
                scaleMultiplier = targetWidth / resizeStartWidth;
            } else {
                // تغيير عمودي فقط - نعتمد على تغير الارتفاع
                scaleMultiplier = targetHeight / resizeStartHeight;
            }
        } else {
            // تحجيم من الزوايا - نستخدم الأكبر للحفاظ على النسب
            const scaleX = targetWidth / resizeStartWidth;
            const scaleY = targetHeight / resizeStartHeight;
            scaleMultiplier = Math.max(scaleX, scaleY);
        }

        const newScale = Math.max(0.1, Math.min(10, resizeStartScale * scaleMultiplier));
        widget.scale = newScale;

        // حساب نقطة الارتكاز (Anchor Point) للحفاظ على الزاوية المقابلة ثابتة
        // 0 = يسار/أعلى، 1 = يمين/أسفل، 0.5 = منتصف
        let fx = 0.5;
        let fy = 0.5;

        if (resizePosition.includes('n')) fy = 1; // سحب من الأعلى -> الأسفل ثابت
        else if (resizePosition.includes('s')) fy = 0; // سحب من الأسفل -> الأعلى ثابت

        if (resizePosition.includes('w')) fx = 1; // سحب من اليسار -> اليمين ثابت
        else if (resizePosition.includes('e')) fx = 0; // سحب من اليمين -> اليسار ثابت

        // --- منطق المغناطيس للتكبير/التصغير ---
        const SNAP_THRESHOLD = 15;

        // ثوابت الحساب (ConstantPart)
        const W = widget.width;
        const H = widget.height;
        const constantPartX = widgetStartX + W * resizeStartScale * (fx - 0.5) + W / 2;
        const constantPartY = widgetStartY + H * resizeStartScale * (fy - 0.5) + H / 2;

        // خطوط الشبكة
        const snapLinesX = [{
            value: 0
        }, {
            value: canvasWidth
        }, {
            value: canvasWidth / 2
        }];
        const snapLinesY = [{
            value: 0
        }, {
            value: canvasHeight
        }, {
            value: canvasHeight / 2
        }];

        // إضافة حواف الويدجتات الأخرى
        composerWidgets.forEach(otherWidget => {
            if (otherWidget.id === widget.id || !otherWidget.visible) return;
            const os = otherWidget.scale || 1;
            const ow = otherWidget.width * os;
            const oh = otherWidget.height * os;
            const ocx = otherWidget.x + otherWidget.width / 2;
            const ocy = otherWidget.y + otherWidget.height / 2;

            snapLinesX.push({
                value: ocx - ow / 2
            }); // Left
            snapLinesX.push({
                value: ocx + ow / 2
            }); // Right
            snapLinesX.push({
                value: ocx
            }); // Center

            snapLinesY.push({
                value: ocy - oh / 2
            }); // Top
            snapLinesY.push({
                value: ocy + oh / 2
            }); // Bottom
            snapLinesY.push({
                value: ocy
            }); // Center
        });

        let bestSnapDistance = SNAP_THRESHOLD;
        let snappedScale = null;

        // دالة مساعدة للتحقق من المغناطيس وتحديث أفضل مقياس
        const checkSnap = (currentValue, snapLines, isX, isPositiveDirection) => {
            for (const line of snapLines) {
                const dist = Math.abs(currentValue - line.value);
                if (dist < bestSnapDistance) {
                    bestSnapDistance = dist;
                    // حساب Scale المطلوب للوصول لهذا الخط
                    if (isX) {
                        const factor = isPositiveDirection ? (1 - fx) : -fx;
                        if (Math.abs(factor) > 0.01) {
                            snappedScale = (line.value - constantPartX) / (W * factor);
                        }
                    } else {
                        const factor = isPositiveDirection ? (1 - fy) : -fy;
                        if (Math.abs(factor) > 0.01) {
                            snappedScale = (line.value - constantPartY) / (H * factor);
                        }
                    }
                }
            }
        };

        // حساب الحواف الحالية بناءً على newScale المقترح
        const currentVisualLeft = constantPartX - W * newScale * fx;
        const currentVisualRight = constantPartX + W * newScale * (1 - fx);
        const currentVisualTop = constantPartY - H * newScale * fy;
        const currentVisualBottom = constantPartY + H * newScale * (1 - fy);

        // التحقق من الحواف النشطة
        if (resizePosition.includes('w')) checkSnap(currentVisualLeft, snapLinesX, true, false);
        if (resizePosition.includes('e')) checkSnap(currentVisualRight, snapLinesX, true, true);
        if (resizePosition.includes('n')) checkSnap(currentVisualTop, snapLinesY, false, false);
        if (resizePosition.includes('s')) checkSnap(currentVisualBottom, snapLinesY, false, true);

        // تطبيق المغناطيس إذا وجد
        if (snappedScale !== null && snappedScale > 0.01) {
            widget.scale = snappedScale;
        } else {
            widget.scale = newScale;
        }

        // تحديث موقع الويدجت للحفاظ على نقطة الارتكاز ثابتة بصرياً
        // المعادلة: NewX = StartX + Width * (StartScale - NewScale) * (fx - 0.5)
        widget.x = widgetStartX + resizeStartWidth * (resizeStartScale - widget.scale) * (fx - 0.5);
        widget.y = widgetStartY + resizeStartHeight * (resizeStartScale - widget.scale) * (fy - 0.5);
    }

    // إلغاء التحديث السابق إن وُجد
    if (rafId) cancelAnimationFrame(rafId);

    // استخدام requestAnimationFrame لتحديث سلس
    rafId = requestAnimationFrame(() => {
        const widgetElement = document.getElementById(widget.id);
        if (widgetElement) {
            widgetElement.style.left = `${widget.x}px`;
            widgetElement.style.top = `${widget.y}px`;
            widgetElement.style.width = `${widget.width}px`;
            widgetElement.style.height = `${widget.height}px`;
            widgetElement.style.transform = `scale(${widget.scale})`;
        }
        updateSelectionOverlay();
        rafId = null;
    });
}

// عند رفع الماوس (إنهاء التحجيم)
function onResizeMouseUp(e) {
    isResizing = false;
    document.removeEventListener('mousemove', onResizeMouseMove);
    document.removeEventListener('mouseup', onResizeMouseUp);

    // تقريب القيم لإزالة الكسور
    if (selectedWidget) {
        const widget = composerWidgets.find(w => w.id === selectedWidget);
        if (widget) {
            widget.x = Math.round(widget.x);
            widget.y = Math.round(widget.y);
            widget.width = Math.round(widget.width);
            widget.height = Math.round(widget.height);
            const widgetElement = document.getElementById(widget.id);
            if (widgetElement) {
                widgetElement.style.left = `${widget.x}px`;
                widgetElement.style.top = `${widget.y}px`;
                widgetElement.style.width = `${widget.width}px`;
                widgetElement.style.height = `${widget.height}px`;
            }
            updateSelectionOverlay();
        }
    }

    // تحديث بعد انتهاء التحجيم
    updateWidgetPropertiesPanel();
    updateLayersList();
}

// اختيار Widget (لم يعد يستخدم - تم الاستبدال بـ selectWidgetInCanvas)
function selectWidget(widgetId) {
    selectWidgetInCanvas(widgetId);
}

// فتح نافذة خصائص Widget
function openWidgetProperties() {
    if (!selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    document.getElementById('widgetPropX').value = widget.x;
    document.getElementById('widgetPropY').value = widget.y;
    document.getElementById('widgetPropWidth').value = widget.width;
    document.getElementById('widgetPropHeight').value = widget.height;
    document.getElementById('widgetPropZIndex').value = widget.zIndex;

    // تحديث أزرار القفل والإخفاء
    document.getElementById('lockBtnText').textContent = widget.locked ? '🔓 إلغاء القفل' : '🔒 قفل';
    document.getElementById('visibilityBtnText').textContent = widget.visible ? '👁️‍🗨️ إخفاء' : '👁️ إظهار';

    const modal = document.getElementById('widgetPropertiesModal');
    modal.style.display = 'flex';
}

// حفظ خصائص Widget وإغلاق النافذة
function saveWidgetProperties() {
    if (!selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    // تطبيق جميع الخصائص
    widget.x = Math.round(parseFloat(document.getElementById('widgetPropX').value));
    widget.y = Math.round(parseFloat(document.getElementById('widgetPropY').value));
    widget.width = Math.round(parseFloat(document.getElementById('widgetPropWidth').value));
    widget.height = Math.round(parseFloat(document.getElementById('widgetPropHeight').value));

    // منع Z-Index أقل من 1
    let newZIndex = parseInt(document.getElementById('widgetPropZIndex').value);
    if (newZIndex < 1) {
        newZIndex = 1;
        document.getElementById('widgetPropZIndex').value = 1;
    }
    widget.zIndex = newZIndex;

    // تحديث العنصر
    const widgetElement = document.getElementById(widget.id);
    if (widgetElement) {
        widgetElement.style.left = `${widget.x}px`;
        widgetElement.style.top = `${widget.y}px`;
        widgetElement.style.width = `${widget.width}px`;
        widgetElement.style.height = `${widget.height}px`;
        widgetElement.style.zIndex = widget.zIndex;
    }

    updateSelectionOverlay();
    updateLayersList();
    closeWidgetProperties();
    showMessage('✅ تم حفظ الخصائص', 'success');
}

// إغلاق نافذة خصائص Widget
function closeWidgetProperties() {
    const modal = document.getElementById('widgetPropertiesModal');
    modal.style.display = 'none';
}

// تحديث خاصية Widget من نافذة الخصائص (للمعاينة الفورية)
function updateWidgetProperty(property) {
    if (!selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    const widgetElement = document.getElementById(widget.id);

    switch (property) {
        case 'x':
            widget.x = parseInt(document.getElementById('widgetPropX').value);
            widgetElement.style.left = `${widget.x}px`;
            break;
        case 'y':
            widget.y = parseInt(document.getElementById('widgetPropY').value);
            widgetElement.style.top = `${widget.y}px`;
            break;
        case 'width':
            widget.width = parseInt(document.getElementById('widgetPropWidth').value);
            widgetElement.style.width = `${widget.width}px`;
            break;
        case 'height':
            widget.height = parseInt(document.getElementById('widgetPropHeight').value);
            widgetElement.style.height = `${widget.height}px`;
            break;
        case 'zIndex':
            let newZIndex = parseInt(document.getElementById('widgetPropZIndex').value);
            if (newZIndex < 1) {
                newZIndex = 1;
                document.getElementById('widgetPropZIndex').value = 1;
            }
            widget.zIndex = newZIndex;
            widgetElement.style.zIndex = widget.zIndex;
            break;
    }
}

// تحديث لوحة الخصائص
function updateWidgetPropertiesPanel() {
    if (!selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    // تقريب القيم لأرقام صحيحة (إخفاء الكسور)
    widget.x = Math.round(widget.x);
    widget.y = Math.round(widget.y);
    widget.width = Math.round(widget.width);
    widget.height = Math.round(widget.height);

    document.getElementById('widgetPropX').value = widget.x;
    document.getElementById('widgetPropY').value = widget.y;
    document.getElementById('widgetPropWidth').value = widget.width;
    document.getElementById('widgetPropHeight').value = widget.height;
}

// قفل/إلغاء قفل Widget
function toggleWidgetLock() {
    if (!selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    widget.locked = !widget.locked;

    const widgetElement = document.getElementById(widget.id);
    if (widget.locked) {
        widgetElement.classList.add('locked');
        widgetElement.style.pointerEvents = 'none';
        document.getElementById('lockBtnText').textContent = '🔓 إلغاء القفل';
    } else {
        widgetElement.classList.remove('locked');
        widgetElement.style.pointerEvents = 'all';
        document.getElementById('lockBtnText').textContent = '🔒 قفل';
    }

    updateLayersList();
}

// إظهار/إخفاء Widget
function toggleWidgetVisibility() {
    if (!selectedWidget) return;

    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget) return;

    widget.visible = !widget.visible;

    const widgetElement = document.getElementById(widget.id);
    if (widget.visible) {
        widgetElement.classList.remove('hidden');
        document.getElementById('visibilityBtnText').textContent = '👁️‍🗨️ إخفاء';
    } else {
        widgetElement.classList.add('hidden');
        document.getElementById('visibilityBtnText').textContent = '👁️ إظهار';
    }
}

// حذف Widget المحدد
function deleteSelectedWidget() {
    if (!selectedWidget) return;

    const widgetIndex = composerWidgets.findIndex(w => w.id === selectedWidget);
    if (widgetIndex === -1) return;

    // حذف من المصفوفة
    composerWidgets.splice(widgetIndex, 1);

    // حذف من DOM
    const widgetElement = document.getElementById(selectedWidget);
    if (widgetElement) {
        widgetElement.remove();
    }

    selectedWidget = null;
    closeWidgetProperties();
    showMessage('تم حذف Widget', 'success');
}

// حذف جميع الويدجتات
function clearAllWidgets() {
    if (composerWidgets.length === 0) {
        showMessage('لا توجد ويدجتات لحذفها', 'info');
        return;
    }

    showConfirmDialog(
        'حذف جميع الويدجتات',
        `هل أنت متأكد من حذف جميع الويدجتات؟<br><br>
        <span style="color: #ff5252; font-size: 13px;">
            ⚠️ سيتم حذف جميع الإعدادات فوراً ولا يمكن التراجع عن هذا الإجراء
        </span>`,
        async () => {
            // حذف من الواجهة
            composerWidgets = [];
            const canvas = document.getElementById('composerCanvas');
            canvas.innerHTML = '';
            selectedWidget = null;
            closeWidgetProperties();
            updateLayersList();

            // حذف من قاعدة البيانات فوراً
            if (currentUser) {
                const userId = currentUser.user_id || currentUser.id;
                try {
                    const response = await fetch('/api/overlay-composer/save', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            userId: userId,
                            layoutData: {
                                canvas_width: canvasWidth,
                                canvas_height: canvasHeight,
                                widgets: []
                            }
                        })
                    });

                    if (response.ok) {
                        showMessage('تم حذف جميع الويدجتات وحفظ التغييرات', 'success');
                        // إرسال تحديث Socket.IO لجميع المستمعين بعد الحذف
                        if (typeof socket !== 'undefined' && socket && socket.connected) {
                            socket.emit('composerLayoutUpdated', {
                                token: widgetToken,
                                layout: {
                                    canvas_width: canvasWidth,
                                    canvas_height: canvasHeight,
                                    widgets: []
                                }
                            });
                        }
                    } else {
                        showMessage('تم حذف الويدجتات من الواجهة، لكن حدث خطأ في الحفظ', 'warning');
                        // حتى لو فشل الحفظ، حاول إبلاغ العارض لتحديث الواجهة المحلية
                        if (typeof socket !== 'undefined' && socket && socket.connected) {
                            socket.emit('composerLayoutUpdated', {
                                token: widgetToken,
                                layout: {
                                    canvas_width: canvasWidth,
                                    canvas_height: canvasHeight,
                                    widgets: []
                                }
                            });
                        }
                    }
                } catch (error) {
                    console.error('Error auto-saving after clear:', error);
                    showMessage('تم حذف الويدجتات من الواجهة، لكن حدث خطأ في الحفظ', 'warning');
                    // عند حدوث خطأ في الشبكة، أرسل تحديثاً مؤقتاً عبر Socket إذا أمكن
                    if (typeof socket !== 'undefined' && socket && socket.connected) {
                        socket.emit('composerLayoutUpdated', {
                            token: widgetToken,
                            layout: {
                                canvas_width: canvasWidth,
                                canvas_height: canvasHeight,
                                widgets: []
                            }
                        });
                    }
                }
            } else {
                showMessage('تم حذف جميع الويدجتات', 'success');
                // لا يوجد مستخدم صالح للحفظ — أرسل التحديث مباشرة إلى العارضين عبر Socket
                if (typeof socket !== 'undefined' && socket && socket.connected) {
                    socket.emit('composerLayoutUpdated', {
                        token: widgetToken,
                        layout: {
                            canvas_width: canvasWidth,
                            canvas_height: canvasHeight,
                            widgets: []
                        }
                    });
                }
            }
        }
    );
}

// حفظ التخطيط
async function saveComposerLayout() {
    if (!currentUser) {
        showMessage('يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    const layoutData = {
        canvas_width: canvasWidth,
        canvas_height: canvasHeight,
        widgets: composerWidgets.map(w => ({
            type: w.type,
            x: w.x,
            y: w.y,
            width: w.width,
            height: w.height,
            scale: w.scale || 1,
            zIndex: w.zIndex,
            visible: w.visible,
            locked: w.locked
        }))
    };

    // استخدام user_id (UUID) بدلاً من id
    const userId = currentUser.user_id || currentUser.id;

    try {
        const response = await fetch('/api/overlay-composer/save', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: userId,
                layoutData: layoutData
            })
        });

        const result = await response.json();

        if (result.success) {
            showMessage('✅ تم حفظ التخطيط بنجاح', 'success');

            // إرسال تحديث Socket.IO لجميع المستمعين
            if (typeof socket !== 'undefined' && socket && socket.connected) {
                socket.emit('composerLayoutUpdated', {
                    token: widgetToken,
                    layout: layoutData
                });
            }
        } else {
            showMessage('❌ فشل حفظ التخطيط: ' + result.error, 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ التخطيط:', error);
        showMessage('❌ خطأ في الاتصال بالسيرفر', 'error');
    }
}

// تحميل التخطيط المحفوظ
async function loadComposerLayout() {
    // الانتظار حتى يتم تحميل currentUser (مع timeout لتجنب الانتظار اللانهائي)
    let retries = 0;
    const maxRetries = 20; // 20 × 100ms = 2 ثانية
    while (!currentUser && retries < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, 100));
        retries++;
    }

    if (!currentUser) {

        return;
    }



    // استخدام user_id (UUID) بدلاً من id
    const userId = currentUser.user_id || currentUser.id;

    try {
        const response = await fetch(`/api/overlay-composer/load?userId=${userId}`);
        const result = await response.json();

        if (result.success && result.layout) {
            // تطبيق أبعاد Canvas
            canvasWidth = result.layout.canvas_width || 1920;
            canvasHeight = result.layout.canvas_height || 1080;
            setCanvasDimensions(canvasWidth, canvasHeight);

            // تحديث القائمة المنسدلة
            const preset = document.getElementById('canvasSizePreset');
            const presetValue = `${canvasWidth}x${canvasHeight}`;
            if (preset.querySelector(`option[value="${presetValue}"]`)) {
                preset.value = presetValue;
            } else {
                preset.value = 'custom';
                document.getElementById('canvasWidth').value = canvasWidth;
                document.getElementById('canvasHeight').value = canvasHeight;
                document.getElementById('canvasCustomDimensions').style.display = 'flex';
            }

            // تحميل الويدجتات
            composerWidgets = [];
            widgetIdCounter = 0;

            if (result.layout.widgets && result.layout.widgets.length > 0) {
                // استخدام for...of بدلاً من forEach للسماح باستخدام await
                for (const widgetData of result.layout.widgets) {
                    const widget = {
                        id: `widget-${++widgetIdCounter}`,
                        type: widgetData.type,
                        x: widgetData.x,
                        y: widgetData.y,
                        width: widgetData.width,
                        height: widgetData.height,
                        scale: widgetData.scale || 1,
                        zIndex: widgetData.zIndex,
                        visible: widgetData.visible,
                        locked: widgetData.locked,
                        url: await getWidgetUrl(widgetData.type)
                    };
                    composerWidgets.push(widget);
                }

                renderAllWidgets();
            }

            // تطبيق zoom بعد التحميل
            setTimeout(() => {
                applyCanvasZoom();
            }, 100);
        }
    } catch (error) {
        console.error('خطأ في تحميل التخطيط:', error);
    }
}

// إعداد مستمعي أحداث Canvas
function setupCanvasEventListeners() {
    const canvas = document.getElementById('composerCanvas');

    // إلغاء التحديد عند الضغط على Canvas
    canvas.addEventListener('click', (e) => {
        if (e.target === canvas) {
            if (selectedWidget) {
                const prevElement = document.getElementById(selectedWidget);
                if (prevElement) {
                    prevElement.classList.remove('selected');
                }
                selectedWidget = null;
                updateSelectionOverlay();
                closeWidgetProperties();
            }
        }
    });

    // إنشاء طبقة التحديد
    createSelectionOverlay();

    // مستمعي مفاتيح الكيبورد لتحريك الويدجت المحدد
    document.addEventListener('keydown', onComposerKeyDown);
    document.addEventListener('keyup', onComposerKeyUp);
    // عند فقدان التركيز (مثل تبديل النوافذ) نوقف الحركة وننظف الحالة
    window.addEventListener('blur', () => {
        keysPressed = {};
        stopKeyboardMoveLoop();
    });
}

// ---------- Keyboard movement handlers ----------
function onComposerKeyDown(e) {
    // تجاهل إذا كان التركيز على حقل نصي
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || e.target.isContentEditable) return;

    if (!selectedWidget) return;

    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        const widget = composerWidgets.find(w => w.id === selectedWidget);
        if (!widget || widget.locked) return;

        keysPressed[e.key] = true;
        e.preventDefault();
        startKeyboardMoveLoop();
    }
}

function onComposerKeyUp(e) {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
        delete keysPressed[e.key];
        // إذا لم تعد هناك أي مفاتيح مضغوطة - أوقف الحلقة
        if (!Object.keys(keysPressed).length) {
            stopKeyboardMoveLoop();
        }
        e.preventDefault();
    }
}

function startKeyboardMoveLoop() {
    if (keyboardMoveRafId) return;
    lastKeyboardMoveTime = 0;
    keyboardMoveRafId = requestAnimationFrame(keyboardMoveTick);
}

function stopKeyboardMoveLoop() {
    if (keyboardMoveRafId) {
        cancelAnimationFrame(keyboardMoveRafId);
        keyboardMoveRafId = null;
    }
    lastKeyboardMoveTime = 0;
}

function keyboardMoveTick(timestamp) {
    // إذا لم يكن هناك أي مفاتيح مضغوطة فإيقاف الحلقة
    if (!Object.keys(keysPressed).length) {
        stopKeyboardMoveLoop();
        return;
    }

    if (!lastKeyboardMoveTime || (timestamp - lastKeyboardMoveTime) >= KEYBOARD_MOVE_INTERVAL) {
        let dx = 0;
        let dy = 0;
        if (keysPressed['ArrowLeft']) dx -= KEYBOARD_MOVE_STEP;
        if (keysPressed['ArrowRight']) dx += KEYBOARD_MOVE_STEP;
        if (keysPressed['ArrowUp']) dy -= KEYBOARD_MOVE_STEP;
        if (keysPressed['ArrowDown']) dy += KEYBOARD_MOVE_STEP;

        if (dx !== 0 || dy !== 0) {
            moveSelectedWidgetBy(dx, dy);
        }

        lastKeyboardMoveTime = timestamp;
    }

    keyboardMoveRafId = requestAnimationFrame(keyboardMoveTick);
}

function moveSelectedWidgetBy(dx, dy) {
    if (!selectedWidget) return;
    const widget = composerWidgets.find(w => w.id === selectedWidget);
    if (!widget || widget.locked) return;

    widget.x = Math.round(widget.x + dx);
    widget.y = Math.round(widget.y + dy);

    // السماح بالتحريك خارج حدود الكانفا (لا تقيد الإحداثيات)

    const widgetElement = document.getElementById(widget.id);
    if (widgetElement) {
        widgetElement.style.left = `${widget.x}px`;
        widgetElement.style.top = `${widget.y}px`;
    }

    updateSelectionOverlay();
    updateWidgetPropertiesPanel();
    updateLayersList();
}

// عرض رسالة للمستخدم
function showMessage(message, type = 'info') {
    const toast = document.getElementById('messageToast');
    if (!toast) return;

    toast.textContent = message;
    toast.className = 'toast show';

    if (type === 'success') {
        toast.style.background = '#10b981';
    } else if (type === 'error') {
        toast.style.background = '#ef4444';
    } else {
        toast.style.background = '#3b82f6';
    }

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// عرض نافذة تأكيد جميلة ومخصصة
function showConfirmDialog(title, message, onConfirm, onCancel = null) {
    // إذا تم استدعاؤها بدون callbacks، نرجع Promise
    if (typeof onConfirm !== 'function') {
        return new Promise((resolve) => {
            showConfirmDialogInternal(title, message, () => resolve(true), () => resolve(false));
        });
    }

    // استدعاء الدالة الأصلية مع callbacks
    showConfirmDialogInternal(title, message, onConfirm, onCancel);
}

// الدالة الداخلية للنافذة
function showConfirmDialogInternal(title, message, onConfirm, onCancel = null) {
    // إنشاء نافذة التأكيد
    const overlay = document.createElement('div');
    overlay.id = 'oc-confirm-overlay';
    overlay.style.cssText = `
        position: fixed !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: rgba(0, 0, 0, 0.7) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        z-index: 100000 !important;
        animation: fadeIn 0.2s ease-out !important;
    `;

    const dialog = document.createElement('div');
    dialog.id = 'oc-confirm-dialog';
    dialog.style.cssText = `
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        border-radius: 20px !important;
        padding: 30px !important;
        max-width: 450px !important;
        width: 90% !important;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5) !important;
        animation: slideUp 0.3s ease-out !important;
        position: relative !important;
        z-index: 100001 !important;
    `;

    dialog.innerHTML = `
        <div style="text-align: center; color: white;">
            <div style="font-size: 48px; margin-bottom: 15px;">🗑️</div>
            <h3 style="margin: 0 0 15px 0; font-size: 24px; font-weight: 700;">${title}</h3>
            <p style="margin: 0 0 25px 0; font-size: 16px; line-height: 1.6; opacity: 0.95;">${message}</p>
            <div style="display: flex; gap: 12px; justify-content: center;">
                <button class="oc-confirm-btn" style="
                    background: white;
                    color: #667eea;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 10px;
                    font-size: 16px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s;
                    box-shadow: 0 4px 15px rgba(255, 255, 255, 0.3);
                ">
                    نعم، تأكيد
                </button>
                <button class="oc-cancel-btn" style="
                    background: rgba(255, 255, 255, 0.2);
                    color: white;
                    border: 2px solid white;
                    padding: 12px 30px;
                    border-radius: 10px;
                    font-size: 16px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.3s;
                ">
                    إلغاء
                </button>
            </div>
        </div>
    `;

    // إضافة animations CSS
    if (!document.getElementById('ocConfirmStyles')) {
        const style = document.createElement('style');
        style.id = 'ocConfirmStyles';
        style.textContent = `
            #oc-confirm-overlay { display:flex; align-items:center; justify-content:center; }
            @keyframes oc_fadeIn { from { opacity: 0; } to { opacity: 1; } }
            @keyframes oc_slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
            #oc-confirm-dialog { animation: oc_slideUp 0.3s ease-out !important; }
            .oc-confirm-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(255,255,255,0.4) !important; }
            .oc-cancel-btn:hover { background: rgba(255,255,255,0.3) !important; transform: translateY(-2px); }
        `;
        document.head.appendChild(style);
    }

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    // معالجة الأحداث
    const confirmBtn = dialog.querySelector('.oc-confirm-btn');
    const cancelBtn = dialog.querySelector('.oc-cancel-btn');

    const closeDialog = () => {
        overlay.style.animation = 'fadeIn 0.2s ease-out reverse';
        setTimeout(() => overlay.remove(), 200);
    };

    confirmBtn.addEventListener('click', () => {
        closeDialog();
        if (onConfirm) onConfirm();
    });

    cancelBtn.addEventListener('click', () => {
        closeDialog();
        if (onCancel) onCancel();
    });

    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            closeDialog();
            if (onCancel) onCancel();
        }
    });
}

// تحديث رابط Composer عند تغيير التوكن
if (typeof socket !== 'undefined') {
    socket.on('connect', () => {
        // تحديث الرابط عند الاتصال
        setTimeout(updateComposerViewUrl, 1000);
    });
}