// إعداد Supabase
const IS_DESKTOP = window.DESKTOP_ENV ? .isDesktop === true;

let SUPABASE_URL = '';
let SUPABASE_KEY = '';
let supabaseClient = null;

// 🌍 قاموس أسماء الدول (مطابق لـ country-service.js)
const COUNTRY_NAMES = {
    'JO': '🇯🇴 الأردن',
    'AE': '🇦🇪 الإمارات',
    'BH': '🇧🇭 البحرين',
    'DZ': '🇩🇿 الجزائر',
    'SD': '🇸🇩 السودان',
    'SY': '🇸🇾 سوريا',
    'SO': '🇸🇴 الصومال',
    'IQ': '🇮🇶 العراق',
    'OM': '🇴🇲 عمان',
    'PS': '🇵🇸 فلسطين',
    'QA': '🇶🇦 قطر',
    'KM': '🇰🇲 جزر القمر',
    'KW': '🇰🇼 الكويت',
    'LB': '🇱🇧 لبنان',
    'LY': '🇱🇾 ليبيا',
    'EG': '🇪🇬 مصر',
    'MA': '🇲🇦 المغرب',
    'MR': '🇲🇷 موريتانيا',
    'SA': '🇸🇦 السعودية',
    'TN': '🇹🇳 تونس',
    'YE': '🇾🇪 اليمن',
    'DJ': '🇩🇯 جيبوتي',
    'AF': '🇦🇫 أفغانستان',
    'AL': '🇦🇱 ألبانيا',
    'DE': '🇩🇪 ألمانيا',
    'AD': '🇦🇩 أندورا',
    'AO': '🇦🇴 أنغولا',
    'AG': '🇦🇬 أنتيغوا وباربودا',
    'AR': '🇦🇷 الأرجنتين',
    'AM': '🇦🇲 أرمينيا',
    'AU': '🇦🇺 أستراليا',
    'AT': '🇦🇹 النمسا',
    'AZ': '🇦🇿 أذربيجان',
    'BS': '🇧🇸 جزر البهاما',
    'BD': '🇧🇩 بنغلاديش',
    'BB': '🇧🇧 باربادوس',
    'BY': '🇧🇾 بيلاروسيا',
    'BE': '🇧🇪 بلجيكا',
    'BZ': '🇧🇿 بليز',
    'BJ': '🇧🇯 بنين',
    'BT': '🇧🇹 بوتان',
    'BO': '🇧🇴 بوليفيا',
    'BA': '🇧🇦 البوسنة والهرسك',
    'BW': '🇧🇼 بوتسوانا',
    'BR': '🇧🇷 البرازيل',
    'BN': '🇧🇳 بروناي',
    'BG': '🇧🇬 بلغاريا',
    'BF': '🇧🇫 بوركينا فاسو',
    'BI': '🇧🇮 بوروندي',
    'CV': '🇨🇻 الرأس الأخضر',
    'KH': '🇰🇭 كمبوديا',
    'CM': '🇨🇲 الكاميرون',
    'CA': '🇨🇦 كندا',
    'CF': '🇨🇫 جمهورية أفريقيا الوسطى',
    'TD': '🇹🇩 تشاد',
    'CL': '🇨🇱 تشيلي',
    'CN': '🇨🇳 الصين',
    'CO': '🇨🇴 كولومبيا',
    'CR': '🇨🇷 كوستاريكا',
    'HR': '🇭🇷 كرواتيا',
    'CU': '🇨🇺 كوبا',
    'CY': '🇨🇾 قبرص',
    'CZ': '🇨🇿 التشيك',
    'CD': '🇨🇩 الكونغو الديمقراطية',
    'DK': '🇩🇰 الدنمارك',
    'DM': '🇩🇲 دومينيكا',
    'DO': '🇩🇴 جمهورية الدومينيكان',
    'EC': '🇪🇨 الإكوادور',
    'SV': '🇸🇻 السلفادور',
    'GQ': '🇬🇶 غينيا الاستوائية',
    'ER': '🇪🇷 إريتريا',
    'EE': '🇪🇪 إستونيا',
    'SZ': '🇸🇿 إسواتيني',
    'ET': '🇪🇹 إثيوبيا',
    'FJ': '🇫🇯 فيجي',
    'FI': '🇫🇮 فنلندا',
    'FR': '🇫🇷 فرنسا',
    'GA': '🇬🇦 الغابون',
    'GM': '🇬🇲 غامبيا',
    'GE': '🇬🇪 جورجيا',
    'GH': '🇬🇭 غانا',
    'GR': '🇬🇷 اليونان',
    'GD': '🇬🇩 غرينادا',
    'GT': '🇬🇹 غواتيمالا',
    'GN': '🇬🇳 غينيا',
    'GW': '🇬🇼 غينيا بيساو',
    'GY': '🇬🇾 غيانا',
    'HT': '🇭🇹 هايتي',
    'HN': '🇭🇳 هندوراس',
    'HU': '🇭🇺 المجر',
    'IS': '🇮🇸 آيسلندا',
    'IN': '🇮🇳 الهند',
    'ID': '🇮🇩 إندونيسيا',
    'IR': '🇮🇷 إيران',
    'IE': '🇮🇪 أيرلندا',
    'IL': '🇮🇱 إسرائيل',
    'IT': '🇮🇹 إيطاليا',
    'CI': '🇨🇮 ساحل العاج',
    'JM': '🇯🇲 جامايكا',
    'JP': '🇯🇵 اليابان',
    'KZ': '🇰🇿 كازاخستان',
    'KE': '🇰🇪 كينيا',
    'KI': '🇰🇮 كيريباتي',
    'KP': '🇰🇵 كوريا الشمالية',
    'KR': '🇰🇷 كوريا الجنوبية',
    'XK': '🇽🇰 كوسوفو',
    'KG': '🇰🇬 قيرغيزستان',
    'LA': '🇱🇦 لاوس',
    'LV': '🇱🇻 لاتفيا',
    'LS': '🇱🇸 ليسوتو',
    'LR': '🇱🇷 ليبيريا',
    'LI': '🇱🇮 ليختنشتاين',
    'LT': '🇱🇹 ليتوانيا',
    'LU': '🇱🇺 لوكسمبورغ',
    'MG': '🇲🇬 مدغشقر',
    'MW': '🇲🇼 مالاوي',
    'MY': '🇲🇾 ماليزيا',
    'MV': '🇲🇻 المالديف',
    'ML': '🇲🇱 مالي',
    'MT': '🇲🇹 مالطا',
    'MH': '🇲🇭 جزر مارشال',
    'MU': '🇲🇺 موريشيوس',
    'MX': '🇲🇽 المكسيك',
    'FM': '🇫🇲 ميكرونيزيا',
    'MD': '🇲🇩 مولدوفا',
    'MC': '🇲🇨 موناكو',
    'MN': '🇲🇳 منغوليا',
    'ME': '🇲🇪 الجبل الأسود',
    'MZ': '🇲🇿 موزمبيق',
    'MM': '🇲🇲 ميانمار',
    'NA': '🇳🇦 ناميبيا',
    'NR': '🇳🇷 ناورو',
    'NP': '🇳🇵 نيبال',
    'NL': '🇳🇱 هولندا',
    'NZ': '🇳🇿 نيوزيلندا',
    'NI': '🇳🇮 نيكاراغوا',
    'NE': '🇳🇪 النيجر',
    'NG': '🇳🇬 نيجيريا',
    'MK': '🇲🇰 مقدونيا الشمالية',
    'NO': '🇳🇴 النرويج',
    'PK': '🇵🇰 باكستان',
    'PW': '🇵🇼 بالاو',
    'PA': '🇵🇦 بنما',
    'PG': '🇵🇬 بابوا غينيا الجديدة',
    'PY': '🇵🇾 باراغواي',
    'PE': '🇵🇪 بيرو',
    'PH': '🇵🇭 الفلبين',
    'PL': '🇵🇱 بولندا',
    'PT': '🇵🇹 البرتغال',
    'RO': '🇷🇴 رومانيا',
    'RU': '🇷🇺 روسيا',
    'RW': '🇷🇼 رواندا',
    'KN': '🇰🇳 سانت كيتس ونيفيس',
    'LC': '🇱🇨 سانت لوسيا',
    'VC': '🇻🇨 سانت فينسنت والغرينادين',
    'WS': '🇼🇸 ساموا',
    'SM': '🇸🇲 سان مارينو',
    'ST': '🇸🇹 ساو تومي وبرينسيبي',
    'SN': '🇸🇳 السنغال',
    'RS': '🇷🇸 صربيا',
    'SC': '🇸🇨 سيشل',
    'SL': '🇸🇱 سيراليون',
    'SG': '🇸🇬 سنغافورة',
    'SK': '🇸🇰 سلوفاكيا',
    'SI': '🇸🇮 سلوفينيا',
    'SB': '🇸🇧 جزر سليمان',
    'ZA': '🇿🇦 جنوب أفريقيا',
    'SS': '🇸🇸 جنوب السودان',
    'ES': '🇪🇸 إسبانيا',
    'LK': '🇱🇰 سريلانكا',
    'SR': '🇸🇷 سورينام',
    'SE': '🇸🇪 السويد',
    'CH': '🇨🇭 سويسرا',
    'TJ': '🇹🇯 طاجيكستان',
    'TZ': '🇹🇿 تنزانيا',
    'TH': '🇹🇭 تايلاند',
    'TL': '🇹🇱 تيمور الشرقية',
    'TG': '🇹🇬 توغو',
    'TO': '🇹🇴 تونغا',
    'TT': '🇹🇹 ترينيداد وتوباغو',
    'TR': '🇹🇷 تركيا',
    'TM': '🇹🇲 تركمانستان',
    'TV': '🇹🇻 توفالو',
    'UG': '🇺🇬 أوغندا',
    'UA': '🇺🇦 أوكرانيا',
    'GB': '🇬🇧 المملكة المتحدة',
    'US': '🇺🇸 الولايات المتحدة',
    'UY': '🇺🇾 أوروغواي',
    'UZ': '🇺🇿 أوزبكستان',
    'VU': '🇻🇺 فانواتو',
    'VA': '🇻🇦 الفاتيكان',
    'VE': '🇻🇪 فنزويلا',
    'VN': '🇻🇳 فيتنام',
    'ZM': '🇿🇲 زامبيا',
    'ZW': '🇿🇼 زيمبابوي',
    'XX': '🌍 غير محدد',
    'OTHER': '🌍 أخرى'
};


// إعدادات محسنة لـ Supabase
const supabaseOptions = {
    auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
        storageKey: 'sb-user-auth-token', // 🔑 مفتاح مخصص للمستخدمين العاديين
        flowType: 'pkce'
    },
    global: {
        headers: {
            'X-Client-Info': 'tiktok-dashboard'
        }
    }
};

// جلب إعدادات Supabase و Stripe من السيرفر
async function initializeSupabase() {
    try {
        const response = await fetch('/api/config');
        const config = await response.json();

        if (config.supabaseUrl && config.supabaseKey) {
            SUPABASE_URL = config.supabaseUrl;
            SUPABASE_KEY = config.supabaseKey;
            supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, supabaseOptions);
            window.supabase = supabase; // جعل supabase متاح عالمياً



            return true;
        } else {
            console.error('فشل في الحصول على إعدادات Supabase');
            return false;
        }
    } catch (error) {
        console.error('خطأ في تهيئة Supabase:', error);
        return false;
    }
}

// إعداد Socket.IO مع خيارات محسّنة لمنع انقطاع الاتصال
const socket = io({
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    reconnectionAttempts: Infinity,
    timeout: 20000,
    transports: ['websocket', 'polling'],
    upgrade: true,
    forceNew: false,
    autoConnect: true,
    withCredentials: true // مهم للـ sticky sessions مع Fly.io
});
socket.on('session:replaced', handleSessionReplaced);

// استماع لآخر تحقق من الدولة من السيرفر
socket.on('country_checked', (data) => {
    try {
        const box = document.getElementById('lastCountryBox');
        const evSpan = document.getElementById('lcEvent');
        const userSpan = document.getElementById('lcUser');
        const countrySpan = document.getElementById('lcCountry');
        if (!box || !evSpan || !userSpan || !countrySpan) return;

        const eventLabel = (data.eventType || data.triggerLabel || 'حدث').toUpperCase();
        const displayName = data.displayName || data.uniqueId || 'مستخدم';
        const countryCode = data.country || '';
        const countryName = data.countryName || '';
        const flag = data.flag || '';

        evSpan.textContent = eventLabel;
        userSpan.textContent = displayName;
        countrySpan.textContent = countryName ? `${flag} ${countryName}` : (countryCode ? `${flag} ${countryCode}` : 'غير محدد');

        box.style.display = 'flex';
        // حفظ آخر فحص في localStorage ليبقى بعد إعادة تحميل الصفحة
        try {
            localStorage.setItem('last_country_check', JSON.stringify({
                eventType: eventLabel,
                displayName,
                countryCode,
                countryName,
                flag,
                timestamp: data.timestamp || Date.now()
            }));
        } catch (e) {}
    } catch (e) {
        console.error('Error handling country_checked:', e);
    }
});

// زر إغلاق الصندوق
document.addEventListener('click', (ev) => {
    const t = ev.target;
    if (t && t.id === 'closeLastCountry') {
        const box = document.getElementById('lastCountryBox');
        if (box) box.style.display = 'none';
    }
});

// عند تحميل الصفحة، حاول قراءة آخر فحص من localStorage وعرضه
function loadLastCountryFromStorage() {
    try {
        const raw = localStorage.getItem('last_country_check');
        if (!raw) return;
        const data = JSON.parse(raw);
        const box = document.getElementById('lastCountryBox');
        const evSpan = document.getElementById('lcEvent');
        const userSpan = document.getElementById('lcUser');
        const countrySpan = document.getElementById('lcCountry');
        if (!box || !evSpan || !userSpan || !countrySpan) return;

        evSpan.textContent = data.eventType || 'حدث';
        userSpan.textContent = data.displayName || 'مستخدم';
        if (data.countryName) countrySpan.textContent = `${data.flag || ''} ${data.countryName}`;
        else if (data.countryCode) countrySpan.textContent = `${data.flag || ''} ${data.countryCode}`;
        else countrySpan.textContent = 'غير محدد';

        box.style.display = 'flex';
    } catch (e) {}
}

// نفّذ عند بداية الصفحة
document.addEventListener('DOMContentLoaded', () => {
    loadLastCountryFromStorage();
});


// متغيرات العناصر
let userEmailSpan, uniqueCodeSpan, connectionStatus, connectBtn;
let usernameInput, currentUsernameDiv, connectedUsernameSpan;
let viewersCount, commentsCount, giftsCount, commentsList;
let commentsWidgetUrl, likesWidgetUrl, followsWidgetUrl, horizontalPodiumUrl, horizontalPodiumSupportersUrl, fireworkWidgetUrl;

let currentUser = null;
let widgetToken = null; // التوكن الخاص بالويدجت
let isConnected = false;
let currentStats = {
    viewers: 0,
    likes: 0,
    comments: 0,
    follows: 0,
    gifts: 0
};
let savedUsername = null;
let autoConnectAttempted = false; // لمنع الاتصال التلقائي المتكرر

// 🆕 Event emitter for user data ready
const userDataReadyCallbacks = [];

function onUserDataReady(callback) {
    if (currentUser && widgetToken) {
        callback(); // Execute immediately if data is already ready
    } else {
        userDataReadyCallbacks.push(callback);
    }
}

function triggerUserDataReady() {
    userDataReadyCallbacks.forEach(cb => {
        try {
            cb();
        } catch (err) {
            console.error('Error in userDataReady callback:', err);
        }
    });
    userDataReadyCallbacks.length = 0; // Clear callbacks
}

// 🆕 نظام إعادة الاتصال التلقائي المحسّن
let autoReconnectEnabled = true; // تفعيل إعادة الاتصال التلقائي
let reconnectAttempts = 0; // عدد محاولات إعادة الاتصال
let reconnectTimer = null; // مؤقت إعادة الاتصال
const MAX_RECONNECT_ATTEMPTS = 15; // أقصى عدد محاولات (زيادة من 10 إلى 15)
const RECONNECT_DELAYS = [2000, 3000, 5000, 10000, 15000, 20000, 30000]; // فترات الانتظار بين المحاولات (بالميلي ثانية)
let lastDisconnectTime = 0; // آخر وقت انقطع فيه الاتصال
let wasConnectedBeforeDisconnect = false; // هل كان متصلاً قبل الانقطاع

// 🆕 متغيرات لمراقبة تغيير اليوزر أثناء الاتصال
let isConnecting = false; // حالة الاتصال الجارية
let lastInputValue = ''; // آخر قيمة تم إرسالها للاتصال
let inputChangeTimeout = null; // مؤقت لتجميع التغييرات

// 🆕 دالة حفظ اسم المستخدم في localStorage
function saveUsernameToLocalStorage(username) {
    if (username) {
        try {
            localStorage.setItem('last_tiktok_username', username);
        } catch (e) {
            console.error('❌ فشل حفظ اسم المستخدم في localStorage:', e);
        }
    }
}

// 🆕 دالة جلب اسم المستخدم من localStorage
function getUsernameFromLocalStorage() {
    try {
        const username = localStorage.getItem('last_tiktok_username');
        if (username) {
            return username;
        }
    } catch (e) {
        console.error('❌ فشل جلب اسم المستخدم من localStorage:', e);
    }
    return null;
}

// 🔥 حفظ حالة الاتصال في localStorage
function saveConnectionState(isConnected, username = null) {
    try {
        localStorage.setItem('tiktok_was_connected', isConnected ? 'true' : 'false');
        if (username) {
            localStorage.setItem('last_tiktok_username', username);
        }
        if (isConnected) {
            localStorage.setItem('connection_timestamp', Date.now().toString());
        } else {
            localStorage.removeItem('connection_timestamp');
        }
    } catch (e) {
        console.error('❌ فشل حفظ حالة الاتصال:', e);
    }
}

// 🔥 التحقق من حالة الاتصال السابقة
function wasConnectedRecently() {
    try {
        const wasConnected = localStorage.getItem('tiktok_was_connected') === 'true';
        const timestamp = localStorage.getItem('connection_timestamp');

        if (!wasConnected || !timestamp) return false;

        // فقط إذا كان الاتصال خلال آخر 5 دقائق
        const timeDiff = Date.now() - parseInt(timestamp);
        return timeDiff < 5 * 60 * 1000; // 5 دقائق
    } catch (e) {
        console.error('❌ فشل التحقق من حالة الاتصال:', e);
        return false;
    }
}

// 🆕 دالة مزامنة اسم المستخدم مع السيرفر
async function syncUsernameWithServer(username) {
    if (!currentUser || !username) return;

    try {
        const response = await fetch('/api/save-username', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id,
                username: username
            })
        });

        if (response.ok) {}
    } catch (error) {
        console.error('❌ فشلت مزامنة اسم المستخدم مع السيرفر:', error);
    }
}

// � دالة بدء إعادة الاتصال التلقائي (مُعطّلة - Socket.IO يُدير هذا)
// تم الاحتفاظ بها للتوافق مع الكود القديم فقط
function startAutoReconnect() {
    // Socket.IO يُدير reconnection تلقائياً مع exponential backoff
}

// 🎯 دالة إيقاف إعادة الاتصال التلقائي (مُعطّلة - Socket.IO يُدير هذا)
function stopAutoReconnect() {
    if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
    }
    reconnectAttempts = 0;
}

/**
 * 🔄 إعادة الاتصال التلقائي بالبث المباشر (ليس Socket.IO)
 * تُستدعى عند انقطاع الاتصال بالبث بشكل غير متوقع
 */
async function attemptStreamReconnect() {
    // التحقق من الشروط
    if (!autoReconnectEnabled || SESSION_KICKED || !wasConnectedBeforeDisconnect) {
        return;
    }

    // الحصول على اسم المستخدم المحفوظ
    const username = savedUsername || getUsernameFromLocalStorage();
    if (!username) {
        return;
    }

    // التحقق من عدم تجاوز الحد الأقصى للمحاولات
    if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
        showToast(`❌ فشلت إعادة الاتصال بعد ${MAX_RECONNECT_ATTEMPTS} محاولة`, 'error');
        wasConnectedBeforeDisconnect = false;
        return;
    }

    reconnectAttempts++;

    // حساب وقت الانتظار
    const delayIndex = Math.min(reconnectAttempts - 1, RECONNECT_DELAYS.length - 1);
    const delay = RECONNECT_DELAYS[delayIndex];

    showToast(`🔄 محاولة إعادة الاتصال (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}) بعد ${delay/1000}ث...`, 'info');

    // الانتظار ثم إعادة الاتصال
    reconnectTimer = setTimeout(async () => {
        try {
            await startConnection(username, false);

            // إذا نجح الاتصال، إعادة تعيين العداد
            if (isConnected) {
                reconnectAttempts = 0;
                wasConnectedBeforeDisconnect = false;
                showToast(`✅ تم إعادة الاتصال بنجاح بـ ${username}`, 'success');
            } else {
                // إذا فشل، المحاولة مرة أخرى
                attemptStreamReconnect();
            }
        } catch (error) {
            console.error('❌ فشلت محاولة إعادة الاتصال:', error);
            // المحاولة مرة أخرى
            attemptStreamReconnect();
        }
    }, delay);
}

// ==========================================
// 🔒 GLOBAL SESSION CONTROL FUNCTIONS
// ==========================================

// دالة إظهار شاشة الجلسة المكررة
function showSessionDuplicateOverlay() {
    const overlay = document.getElementById('sessionDuplicateOverlay');
    if (overlay) {
        overlay.style.display = 'flex'; // استخدام flex لتوسيط المحتوى
    }
}

// دالة إخفاء شاشة الجلسة المكررة
function hideSessionDuplicateOverlay() {
    const overlay = document.getElementById('sessionDuplicateOverlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

// تهيئة زر استعادة الجلسة (يتم استدعاؤه عند تحميل الصفحة)
function initTakeOverButton() {
    const takeOverBtn = document.getElementById('takeOverSessionBtn');
    if (takeOverBtn) {
        // إزالة أي مستمعين سابقين لتجنب التكرار (عن طريق استبدال العنصر بنفسه)
        const newBtn = takeOverBtn.cloneNode(true);
        takeOverBtn.parentNode.replaceChild(newBtn, takeOverBtn);

        newBtn.addEventListener('click', () => {

            // 🔓 STEP 1: إلغاء علامة الموت
            SESSION_KICKED = false;

            // 🔓 STEP 2: إعادة تفعيل الواجهة بالكامل
            try {
                // إعادة تفعيل body
                document.body.style.pointerEvents = '';
                document.body.style.userSelect = '';
                document.body.style.opacity = '';

                // إعادة تفعيل جميع العناصر
                document.querySelectorAll('button, input, select, textarea, a').forEach(el => {
                    try {
                        el.disabled = false;
                        el.style.pointerEvents = '';
                        el.style.opacity = '';
                    } catch (e) {}
                });
            } catch (e) {}

            // 🔓 STEP 3: إخفاء شاشة التكرار
            try {
                hideSessionDuplicateOverlay();
            } catch (e) {}

            // 🔓 STEP 4: إعادة تفعيل reconnection
            try {
                if (socket.io && typeof socket.io.reconnection === 'function') {
                    socket.io.reconnection(true);
                } else {
                    socket.io.opts.reconnection = true;
                }
            } catch (e) {}

            // 🔓 STEP 5: قطع الاتصال الحالي (إن وجد)
            if (socket.connected) {
                socket.disconnect();
            }

            // 🔓 STEP 6: إعادة الاتصال كجلسة جديدة
            setTimeout(() => {
                socket.connect();

                // ملاحظة: سيقوم معالج socket.on('connect') بإرسال حدث 'join' تلقائياً
                // لأننا قمنا بإعادة تعيين SESSION_KICKED = false

                showToast('✅ جاري استعادة الجلسة...', 'info');

                // 🔓 STEP 7: إعادة تشغيل Keep-Alive
                try {
                    startKeepAlive();
                } catch (e) {}

                showToast('✅ تم استعادة الجلسة بنجاح', 'success');

            }, 200);
        });
    }
}

// استدعاء تهيئة الزر عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', initTakeOverButton);

// متغيرات نظام Keep-Alive
let keepAliveInterval = null;
let lastActivity = Date.now();
// reconnectAttempts تم تعريفه في الأعلى (السطر 82)
let isPageVisible = !document.hidden;
let SESSION_KICKED = false; // ✅ إذا صارت الجلسة قديمة/مستبدلة، ممنوع ترجع تتصل
let isFirstConnect = true; // 🆕 للتمييز بين first connect و reconnect

// 🔒 Global Interaction Blocker
document.addEventListener('click', (e) => {
    if (SESSION_KICKED) {
        // السماح فقط بالنقر على زر "Take over"
        if (e.target.closest('#takeOverSessionBtn')) return;

        e.preventDefault();
        e.stopPropagation();
        // console.warn('🚫 Interaction blocked: Session is dead');
    }
}, true); // Capture phase to run before other listeners

// نظام التنقل بين الصفحات
function initializeNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');

    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const isExternal = this.classList.contains('nav-external');
            const targetPage = this.getAttribute('data-page');

            // إذا كان رابط خارجي (مثل شروط/خصوصية)، اترُك المتصفح يتصرَّف بشكل طبيعي
            if (isExternal) {
                return;
            }

            e.preventDefault();

            // إزالة النشط من جميع العناصر
            navItems.forEach(nav => nav.classList.remove('active'));
            pages.forEach(page => page.classList.remove('active'));

            // تفعيل العنصر والصفحة المطلوبة
            this.classList.add('active');
            const targetPageElement = document.getElementById(targetPage + '-page');
            if (targetPageElement) {
                targetPageElement.classList.add('active');

                // تحميل إعدادات TTS عند فتح صفحة TTS
                if (targetPage === 'tts') {
                    loadTTSSettings();
                }

                // تحميل إعدادات Social Rotator عند فتح صفحة social-rotator
                if (targetPage === 'social-rotator') {
                    setTimeout(() => {
                        initializeSocialRotatorPage();
                    }, 100);
                }

                // تحديث عرض Canvas عند فتح صفحة overlay-composer
                if (targetPage === 'overlay-composer') {
                    setTimeout(() => {
                        if (typeof updateCanvasDisplay === 'function') {
                            updateCanvasDisplay();
                        }
                        if (typeof loadComposerLayout === 'function') {
                            loadComposerLayout();
                        }
                    }, 500);
                }
            }

            // حفظ الصفحة الحالية في localStorage
            localStorage.setItem('dashboardActivePage', targetPage);
        });
    });

    // استعادة الصفحة المحفوظة عند تحميل الداشبورد
    const savedPage = localStorage.getItem('dashboardActivePage');
    if (savedPage) {
        // البحث عن العنصر المقابل للصفحة المحفوظة
        const savedNavItem = document.querySelector(`.nav-item[data-page="${savedPage}"]`);
        if (savedNavItem) {
            // إزالة النشط من جميع العناصر
            navItems.forEach(nav => nav.classList.remove('active'));
            pages.forEach(page => page.classList.remove('active'));

            // تفعيل الصفحة المحفوظة
            savedNavItem.classList.add('active');
            const savedPageElement = document.getElementById(savedPage + '-page');
            if (savedPageElement) {
                savedPageElement.classList.add('active');

                // تحميل إعدادات TTS عند استعادة صفحة TTS
                if (savedPage === 'tts') {
                    loadTTSSettings();
                }

                // تحميل إعدادات Social Rotator عند استعادة صفحة social-rotator
                if (savedPage === 'social-rotator') {
                    setTimeout(() => {
                        initializeSocialRotatorPage();
                    }, 100);
                }

                // تحميل تخطيط Overlay Composer عند استعادة صفحة overlay-composer
                if (savedPage === 'overlay-composer') {
                    setTimeout(() => {
                        if (typeof updateCanvasDisplay === 'function') {
                            updateCanvasDisplay();
                        }
                        if (typeof loadComposerLayout === 'function') {
                            loadComposerLayout();
                        }
                    }, 500);
                }
            }
        }
    }
}


// 🔐 دالة تسجيل الدخول بواسطة Google
async function handleGoogleLogin() {
    try {

        const messageDiv = document.getElementById('message');
        if (messageDiv) {
            messageDiv.textContent = IS_DESKTOP ?
                'سيتم فتح Google في المتصفح...' :
                'جاري إعادة التوجيه إلى Google...';
            messageDiv.className = 'message info';
            messageDiv.style.display = 'block';
        }

        // 🖥️ حالة Desktop: فتح OAuth في المتصفح الخارجي
        if (IS_DESKTOP) {

            // استخدام صفحة الـ success بدل الـ protocol مباشرة لتحسين تجربة المستخدم
            const redirectUrl = window.location.origin + '/oauth-success.html';

            const {
                data,
                error
            } = await supabase.auth.signInWithOAuth({
                provider: 'google',
                options: {
                    redirectTo: redirectUrl,
                    skipBrowserRedirect: true, // منع فتح المتصفح تلقائياً
                    queryParams: {
                        access_type: 'offline',
                        prompt: 'consent'
                    }
                }
            });

            if (error) {
                console.error('❌ خطأ في إنشاء رابط OAuth:', error);
                if (messageDiv) {
                    messageDiv.textContent = 'خطأ: ' + error.message;
                    messageDiv.className = 'message error';
                }
                return;
            }

            // فتح الرابط في المتصفح الخارجي
            if (data ? .url) {
                window.DESKTOP_ENV.openExternal(data.url);

                if (messageDiv) {
                    messageDiv.textContent = 'تم فتح Google في المتصفح. أكمل تسجيل الدخول هناك...';
                    messageDiv.className = 'message info';
                }
            } else {
                console.error('❌ No OAuth URL returned');
                if (messageDiv) {
                    messageDiv.textContent = 'خطأ: لم يتم الحصول على رابط التسجيل';
                    messageDiv.className = 'message error';
                }
            }
        }
        // 🌐 حالة Browser: OAuth عادي
        else {

            const {
                data,
                error
            } = await supabase.auth.signInWithOAuth({
                provider: 'google',
                options: {
                    redirectTo: window.location.origin + '/dashboard/dashboard.html',
                    queryParams: {
                        access_type: 'offline',
                        prompt: 'consent'
                    }
                }
            });

            if (error) {
                console.error('❌ خطأ في تسجيل الدخول بواسطة Google:', error);
                if (messageDiv) {
                    messageDiv.textContent = 'خطأ: ' + error.message;
                    messageDiv.className = 'message error';
                }
                return;
            }
            // Supabase سيتولى إعادة التوجيه تلقائياً
        }

    } catch (error) {
        console.error('❌ خطأ غير متوقع في Google Login:', error);
        const messageDiv = document.getElementById('message');
        if (messageDiv) {
            messageDiv.textContent = 'حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.';
            messageDiv.className = 'message error';
            messageDiv.style.display = 'block';
        }
    }
}

// إدارة تسجيل الدخول في صفحة Setup
function initializeLoginForm() {

    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');
    const emailInput = document.getElementById('email');
    const codeGroup = document.getElementById('codeGroup');
    const verificationCodeInput = document.getElementById('verificationCode');
    const messageDiv = document.getElementById('message');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const logoutBtnSetup = document.getElementById('logoutBtnSetup');
    const resendCodeBtn = document.getElementById('resendCodeBtn');
    const googleLoginBtn = document.getElementById('googleLoginBtn');

    let isWaitingForCode = false;
    let resendTimer = null;
    let resendCountdown = 0;

    // وظيفة إرسال رمز التحقق
    async function sendVerificationCode(email, isResend = false) {
        try {
            if (isResend) {
                resendCodeBtn.disabled = true;
                resendCodeBtn.classList.add('resending');
            } else {
                loginBtn.disabled = true;
                loadingSpinner.style.display = 'block';
            }
            messageDiv.style.display = 'none';

            const {
                error
            } = await supabase.auth.signInWithOtp({
                email: email,
                options: {
                    shouldCreateUser: true
                }
            });

            if (error) throw error;

            showMessage(isResend ? 'تم إعادة إرسال رمز التحقق بنجاح!' : 'تم إرسال رمز التحقق إلى بريدك الإلكتروني', 'success');

            if (!isResend) {
                loginBtn.textContent = 'تسجيل الدخول';
                codeGroup.style.display = 'block';
                isWaitingForCode = true;
                verificationCodeInput.focus();
            }

            // بدء عداد إعادة الإرسال
            startResendTimer();

        } catch (error) {
            console.error('خطأ في إرسال رمز التحقق:', error);
            showMessage('خطأ: ' + error.message, 'error');
        } finally {
            if (isResend) {
                resendCodeBtn.classList.remove('resending');
            } else {
                loginBtn.disabled = false;
                loadingSpinner.style.display = 'none';
            }
        }
    }

    // وظيفة بدء عداد إعادة الإرسال (60 ثانية)
    function startResendTimer() {
        resendCountdown = 60;
        resendCodeBtn.disabled = true;

        const resendText = resendCodeBtn.querySelector('.resend-text');

        // تحديث النص كل ثانية
        resendTimer = setInterval(() => {
            resendCountdown--;
            resendText.textContent = `إعادة الإرسال (${resendCountdown}ث)`;

            if (resendCountdown <= 0) {
                clearInterval(resendTimer);
                resendCodeBtn.disabled = false;
                resendText.textContent = 'إعادة إرسال الرمز';
            }
        }, 1000);
    }

    // معالج زر Google Login
    if (googleLoginBtn) {
        googleLoginBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            e.stopPropagation();
            await handleGoogleLogin();
        });
    }

    // معالج زر إعادة الإرسال
    if (resendCodeBtn) {
        resendCodeBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            e.stopPropagation();

            if (resendCodeBtn.disabled) return;

            const email = emailInput.value.trim();
            if (!email) {
                showMessage('يرجى إدخال البريد الإلكتروني أولاً', 'error');
                return;
            }

            await sendVerificationCode(email, true);
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            e.stopPropagation();

            const email = emailInput.value.trim();

            if (!isWaitingForCode) {
                // إرسال رمز التحقق
                if (!email) {
                    showMessage('يرجى إدخال البريد الإلكتروني', 'error');
                    return;
                }

                await sendVerificationCode(email, false);

            } else {
                // التحقق من الرمز
                const code = verificationCodeInput.value.trim();

                if (!code || code.length !== 6) {
                    showMessage('يرجى إدخال رمز التحقق المكون من 6 أرقام', 'error');
                    return;
                }

                try {
                    loginBtn.disabled = true;
                    loadingSpinner.style.display = 'block';
                    messageDiv.style.display = 'none';

                    const {
                        data,
                        error
                    } = await supabase.auth.verifyOtp({
                        email: email,
                        token: code,
                        type: 'email'
                    });

                    if (error) throw error;

                    showMessage('تم تسجيل الدخول بنجاح!', 'success');

                    // إيقاف عداد إعادة الإرسال عند النجاح
                    if (resendTimer) {
                        clearInterval(resendTimer);
                    }

                    // حفظ معلومات المستخدم في قاعدة البيانات (تم نقله من auth.js)
                    await saveUserProfile(data.user);

                    // تحديث واجهة المستخدم
                    setTimeout(() => {
                        updateSetupUIForLoggedInUser(data.user);
                        // تحديث روابط الـ Widgets
                        updateWidgetUrls();
                    }, 1000);

                } catch (error) {
                    console.error('خطأ في التحقق من الرمز:', error);
                    showMessage('رمز التحقق غير صحيح', 'error');
                } finally {
                    loginBtn.disabled = false;
                    loadingSpinner.style.display = 'none';
                }
            }
        });
    }

    // إضافة مستمع منفصل للزر
    if (loginBtn) {
        loginBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            e.stopPropagation();

            // تشغيل نفس الكود الموجود في النموذج
            const email = emailInput.value.trim();

            if (!isWaitingForCode) {
                // إرسال رمز التحقق
                if (!email) {
                    showMessage('يرجى إدخال البريد الإلكتروني', 'error');
                    return;
                }

                await sendVerificationCode(email, false);
            } else {
                // التحقق من الرمز
                const code = verificationCodeInput.value.trim();

                if (!code) {
                    showMessage('يرجى إدخال رمز التحقق', 'error');
                    return;
                }

                loginBtn.disabled = true;
                loadingSpinner.style.display = 'inline-block';

                try {
                    const {
                        data,
                        error
                    } = await supabase.auth.verifyOtp({
                        email: email,
                        token: code,
                        type: 'email'
                    });

                    if (error) {
                        showMessage('رمز التحقق غير صحيح', 'error');
                    } else {
                        currentUser = data.user;
                        showMessage('تم تسجيل الدخول بنجاح!', 'success');

                        // إيقاف عداد إعادة الإرسال عند النجاح
                        if (resendTimer) {
                            clearInterval(resendTimer);
                        }

                        updateSetupUIForLoggedInUser(currentUser);
                    }
                } catch (error) {
                    showMessage('حدث خطأ في التحقق من الرمز', 'error');
                    console.error('خطأ:', error);
                } finally {
                    loginBtn.disabled = false;
                    loadingSpinner.style.display = 'none';
                }
            }
        });
    }

    if (logoutBtnSetup) {
        logoutBtnSetup.addEventListener('click', async function() {
            try {
                // إيقاف عداد إعادة الإرسال عند تسجيل الخروج
                if (resendTimer) {
                    clearInterval(resendTimer);
                }

                // تنظيف الحالة المحفوظة (مثل زر الهيدر)
                clearSavedState();

                // حذف الجلسة من localStorage يدوياً
                localStorage.removeItem('sb-user-auth-token');
                localStorage.removeItem('supabase.auth.token');
                sessionStorage.clear();

                // تسجيل الخروج من Supabase مع scope محلي لتجنب 403
                try {
                    await supabase.auth.signOut({
                        scope: 'local'
                    });
                } catch (signOutError) {
                    // تجاهل أي خطأ في signOut لأننا حذفنا الجلسة يدوياً
                }

                // إعادة التوجيه للصفحة الرئيسية لضمان تنظيف كامل
                window.location.href = '/';

            } catch (error) {
                console.error('خطأ في تسجيل الخروج:', error);
                // حتى لو حدث خطأ، نظف الحالة وأعد التوجيه
                localStorage.removeItem('sb-user-auth-token');
                localStorage.removeItem('supabase.auth.token');
                window.location.href = '/';
            }
        });
    }

    function showMessage(text, type) {
        if (messageDiv) {
            messageDiv.textContent = text;
            messageDiv.className = `message ${type}`;
            messageDiv.style.display = 'block';
        }
    }
}

// تحديث واجهة المستخدم عند تسجيل الدخول
function updateSetupUIForLoggedInUser(user) {

    if (SESSION_KICKED) {
        return;
    }

    const loginSection = document.getElementById('login-section');
    const loggedInSection = document.getElementById('logged-in-section');
    const displayUserEmail = document.getElementById('displayUserEmail');

    if (loginSection) {
        loginSection.style.display = 'none';
    }
    if (loggedInSection) {
        loggedInSection.style.display = 'block';
    }
    if (displayUserEmail) {
        displayUserEmail.textContent = user.email;
    }

    currentUser = user;

    // 🔥 CRITICAL: إرسال join event فوراً بعد تعيين currentUser
    if (socket && socket.connected) {
        emitJoinEvent();
    } else {}

    // إذا كان التطبيق يعمل داخل بيئة الديسكتوب (Electron)، أرسل معرف المستخدم
    if (window.DESKTOP_ENV ? .isDesktop && currentUser ? .id) {
        try {
            window.DESKTOP_ENV.sendUserId(currentUser.id);

            // 🔒 الاستماع لحدث session:replaced من Electron
            window.DESKTOP_ENV.onSessionReplaced((data) => {
                showSessionDuplicateOverlay();
            });

            // 📡 الاستماع لمزامنة حالة البث
            window.DESKTOP_ENV.onLiveStateSync((data) => {
                if (data.connected && data.username) {
                    // تحديث UI لإظهار الاتصال
                    isConnected = true;
                    savedUsername = data.username;
                    saveConnectionState(data.username, true);
                    connectBtn.textContent = 'قطع الاتصال';
                    connectBtn.style.background = 'linear-gradient(45deg, #dc3545, #c82333)';
                    connectBtn.disabled = false;
                    updateConnectionStatus();
                    showToast(`📡 متصل بـ: ${data.username} (من جلسة أخرى)`);
                } else {
                    // تحديث UI لإظهار قطع الاتصال
                    isConnected = false;
                    savedUsername = null;
                    saveConnectionState(null, false);
                    connectBtn.textContent = 'الاتصال بالتيك توك';
                    connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
                    connectBtn.disabled = false;
                    updateConnectionStatus();
                    showToast('📡 تم قطع الاتصال (من جلسة أخرى)');
                }
            });
        } catch (err) {
            console.error('Failed to send userId to DESKTOP_ENV:', err);
        }
    }


    // تحديث معلومات المستخدم في الهيدر
    if (userEmailSpan) {
        userEmailSpan.textContent = user.email;
    }

    // تحميل الروابط والبيانات الأخرى
    loadSavedState();
    updateWidgetUrls();

    // تحميل بيانات المستخدم من قاعدة البيانات (يتضمن إعدادات الـ Overlay)
    loadUserData();


    // جلب حالة الاشتراك فور تسجيل الدخول حتى تظهر للمستخدم بدون الحاجة لإعادة تحميل الصفحة
    loadSubscriptionStatus();
}

// تحديث واجهة المستخدم عند تسجيل الخروج
function updateSetupUIForLoggedOutUser() {

    // 🔓 إعادة تعيين حالة الجلسة الميتة
    SESSION_KICKED = false;
    hideSessionDuplicateOverlay();

    // 🔌 إعادة تفعيل الاتصال للسماح للمستخدم القادم بالدخول
    if (socket && socket.io) {
        try {
            if (typeof socket.io.reconnection === 'function') {
                socket.io.reconnection(true);
            } else if (socket.io.opts) {
                socket.io.opts.reconnection = true;
            }
        } catch (e) {}
    }

    // لا تقطع الاتصال فوراً لتجنب مشاكل login flow
    // if (socket.connected) socket.disconnect();

    const loginSection = document.getElementById('login-section');
    const loggedInSection = document.getElementById('logged-in-section');
    const loadingSpinner = document.getElementById('loadingSpinner'); // ✅ إضافة

    if (loadingSpinner) loadingSpinner.style.display = 'none'; // ✅ إخفاء Spinner
    if (loginSection) loginSection.style.display = 'block'; // ✅ إظهار Login
    if (loggedInSection) loggedInSection.style.display = 'none'; // ✅ إخفاء Dashboard

    // إعادة تعيين المتغيرات
    currentUser = null;
}

// فحص حالة المصادقة في صفحة Setup
async function checkAuthInSetup() {
    try {
        const {
            data: {
                session
            },
            error
        } = await supabase.auth.getSession();

        if (error) {
            console.error('❌ خطأ في جلب الجلسة:', error);
            updateSetupUIForLoggedOutUser();
            return;
        }

        if (session && session.user) {

            // 🔑 تحديث currentUser global variable
            currentUser = session.user;

            updateSetupUIForLoggedInUser(session.user);
            // تحديث روابط الـ Widgets بعد تحديد المستخدم
            updateWidgetUrls();

            // ✅ لا حاجة لإعادة join هنا - سيتم في then() callback
        } else {
            updateSetupUIForLoggedOutUser();
        }
    } catch (error) {
        console.error('❌ خطأ في فحص المصادقة:', error);
        updateSetupUIForLoggedOutUser();
    }
}

// تحديث عناصر التحكم في الهيدر
function updateHeaderElements() {
    // ربط عناصر الاتصال في الهيدر مع العناصر الأصلية
    const headerUsernameInput = document.getElementById('usernameInput');
    const headerConnectBtn = document.getElementById('connectBtn');
    const headerConnectionStatus = document.getElementById('connectionStatus');

    // تحديث المرجع للعناصر الجديدة
    if (headerUsernameInput && !usernameInput) {
        usernameInput = headerUsernameInput;
    }
    if (headerConnectBtn && !connectBtn) {
        connectBtn = headerConnectBtn;
    }
    if (headerConnectionStatus && !connectionStatus) {
        connectionStatus = headerConnectionStatus;
    }
}

// وظيفة مساعدة للتحقق من صحة UUID
function isValidUUID(uuid) {
    if (!uuid) return false;
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(uuid);
}

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', async function() {

    // 1️⃣ تهيئة Supabase أولاً
    const supabaseInitialized = await initializeSupabase();
    if (!supabaseInitialized) {
        showToast('فشل في تهيئة الاتصال بقاعدة البيانات');
        return;
    }

    // 2️⃣ إعداد مستمع حالة المصادقة بعد تهيئة Supabase
    setupAuthStateListener();

    // 3️⃣ ⚡ CRITICAL: فحص الجلسة وتحديث currentUser قبل أي شيء آخر
    // ✅ عدم استخدام await لتجنب blocking
    checkAuthInSetup().then(() => {

        // � Cache Warming: تحميل جميع الإعدادات مسبقاً في الخلفية
        if (currentUser && currentUser.widget_token) {
            fetch(`/api/cache/warmup?token=${currentUser.widget_token}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {} else {}
                })
                .catch(err => console.error('❌ خطأ في cache warming:', err));
        }

        // �🔄 إعادة محاولة Socket join إذا كان متصل
        if (socket && socket.connected && currentUser) {
            emitJoinEvent();
        }
    }).catch(err => {
        console.error('❌ خطأ في فحص المصادقة:', err);
    });

    // 4️⃣ بقية التهيئة - تستمر بدون انتظار
    initializeNavigation();
    initializeElements();
    updateHeaderElements();
    setupEventListeners();

    // 🆕 تحميل اسم المستخدم من localStorage فوراً عند فتح الصفحة
    const localUsername = getUsernameFromLocalStorage();
    if (localUsername && usernameInput) {
        usernameInput.value = localUsername;
        savedUsername = localUsername;
    }

    // � فحص إعادة الاتصال التلقائي بعد تحميل الصفحة
    setTimeout(() => {
        if (wasConnectedRecently() && !autoConnectAttempted && currentUser) {
            const username = getUsernameFromLocalStorage();
            if (username && !isConnected && !SESSION_KICKED) {
                console.log('🔄 اكتشاف اتصال سابق - محاولة إعادة الاتصال التلقائي...', username);
                autoConnectAttempted = true;
                wasConnectedBeforeDisconnect = true;
                autoReconnectEnabled = true;
                showToast(`🔄 إعادة الاتصال تلقائياً بـ ${username}...`, 'info');
                setTimeout(() => {
                    startConnection(username, true);
                }, 2000);
            }
        }
    }, 3000); // انتظار 3 ثواني بعد تحميل الصفحة

    // �💾 تهيئة نظام إدارة الإعدادات عند معرفة المستخدم
    if (currentUser && currentUser.id) {
        settingsCache.setUserId(currentUser.id);

    }

    // 🔐 معالج OAuth callback في حالة Desktop
    if (IS_DESKTOP && window.DESKTOP_ENV ? .onOAuthSuccess) {
        window.DESKTOP_ENV.onOAuthSuccess(async (callbackUrl) => {

            const messageDiv = document.getElementById('message');
            if (messageDiv) {
                messageDiv.textContent = 'جاري إكمال تسجيل الدخول...';
                messageDiv.className = 'message info';
                messageDiv.style.display = 'block';
            }

            try {
                // استخراج الجلسة من الرابط
                // تحويل tikoverlay:// إلى http:// مؤقتاً لمعالجة الـ URL parameters
                const url = new URL(callbackUrl.replace('tikoverlay://', 'http://'));

                // محاولة استخراج الـ tokens من الـ hash
                const hashParams = new URLSearchParams(url.hash.substring(1));

                // محاولة استخراج الـ tokens من الـ query parameters أيضاً
                const queryParams = new URLSearchParams(url.search);

                let access_token = hashParams.get('access_token') || queryParams.get('access_token');
                let refresh_token = hashParams.get('refresh_token') || queryParams.get('refresh_token');

                // إذا لم توجد tokens، ربما يوجد code (PKCE flow)
                const code = queryParams.get('code') || hashParams.get('code');

                if (code && !access_token) {
                    // استخدام Supabase لتبديل الـ code بـ session
                    const {
                        data,
                        error
                    } = await supabase.auth.exchangeCodeForSession(code);
                    if (error) {
                        console.error('❌ Error exchanging code:', error);
                        if (messageDiv) {
                            messageDiv.textContent = 'خطأ في تسجيل الدخول: ' + error.message;
                            messageDiv.className = 'message error';
                        }
                        return;
                    }

                    if (data ? .session) {
                        currentUser = data.session.user;
                        if (messageDiv) {
                            messageDiv.textContent = 'تم تسجيل الدخول بنجاح!';
                            messageDiv.className = 'message success';
                            setTimeout(() => messageDiv.style.display = 'none', 3000);
                        }
                        await initializeAfterLogin();
                    }
                    return;
                }

                if (!access_token || !refresh_token) {
                    console.error('❌ Missing tokens in OAuth callback');
                    console.error('❌ Full callback URL:', callbackUrl);
                    if (messageDiv) {
                        messageDiv.textContent = 'خطأ: معلومات تسجيل الدخول غير كاملة';
                        messageDiv.className = 'message error';
                    }
                    return;
                }

                // تعيين الجلسة مباشرة
                const {
                    data,
                    error
                } = await supabase.auth.setSession({
                    access_token,
                    refresh_token
                });

                if (error) {
                    console.error('❌ Error setting session:', error);
                    if (messageDiv) {
                        messageDiv.textContent = 'خطأ في تسجيل الدخول: ' + error.message;
                        messageDiv.className = 'message error';
                    }
                    return;
                }

                if (data ? .session) {
                    currentUser = data.session.user;

                    if (messageDiv) {
                        messageDiv.textContent = '✅ تم تسجيل الدخول بنجاح!';
                        messageDiv.className = 'message success';
                    }

                    // تحديث الواجهة
                    updateHeaderElements();

                    // إرسال userId إلى Electron
                    if (window.DESKTOP_ENV ? .sendUserId && currentUser ? .id) {
                        window.DESKTOP_ENV.sendUserId(currentUser.id);
                    }

                    // الانضمام إلى Socket room
                    if (socket && socket.connected && currentUser) {
                        emitJoinEvent();
                    }

                    // تهيئة نظام الإعدادات
                    if (currentUser ? .id) {
                        settingsCache.setUserId(currentUser.id);
                    }
                } else {
                    if (messageDiv) {
                        messageDiv.textContent = 'لم يتم العثور على جلسة. حاول مرة أخرى.';
                        messageDiv.className = 'message warning';
                    }
                }
            } catch (err) {
                console.error('❌ Exception handling OAuth callback:', err);
                if (messageDiv) {
                    messageDiv.textContent = 'خطأ في معالجة تسجيل الدخول';
                    messageDiv.className = 'message error';
                }
            }
        });
    }

    // 🆕 طلب حالة تسجيل الدخول من تطبيق سطح المكتب عند التحميل
    if (IS_DESKTOP) {
        // ننتظر قليلاً لضمان اتصال السوكيت و تسجيل Desktop
        setTimeout(() => {
            if (socket.connected) {
                socket.emit('tiktok:check:login');
            } else {
                socket.once('connect', () => {
                    socket.emit('tiktok:check:login');
                });
            }
        }, 2000); // زيادة الانتظار من 1 ثانية إلى 2 ثانية
    }

    // إضافة مستمع زر تسجيل الدخول إلى تيك توك لصفحة بوت الشات
    try {
        const tiktokLoginBtn = document.getElementById('tiktokLoginBtn');
        const tiktokLoginStatus = document.getElementById('tiktokLoginStatus');
        const botLoginCard = document.querySelector('.bot-login-card');

        if (tiktokLoginBtn && botLoginCard) {
            if (!IS_DESKTOP) {
                // 🚫 إذا كان متصفح: إخفاء الزر وإظهار رسالة تحذير
                tiktokLoginBtn.style.display = 'none';

                // التحقق مما إذا كانت الرسالة موجودة مسبقاً لتجنب التكرار
                if (!botLoginCard.querySelector('.browser-warning-msg')) {
                    const warningMsg = document.createElement('div');
                    warningMsg.className = 'browser-warning-msg';
                    warningMsg.style.cssText = 'background: rgba(255, 165, 0, 0.1); border: 1px solid rgba(255, 165, 0, 0.3); color: #ffa500; padding: 15px; border-radius: 8px; margin-top: 10px; text-align: center;';
                    warningMsg.innerHTML = `
                        <div style="font-size: 24px; margin-bottom: 10px;">⚠️</div>
                        <div style="font-weight: bold; margin-bottom: 5px;">ميزة بوت الشات غير متوفرة في المتصفح</div>
                        <div style="font-size: 0.9em; opacity: 0.9;">لاستخدام هذه الميزة، يجب عليك تحميل واستخدام تطبيق سطح المكتب.</div>
                        <div style="margin-top:12px;">
                            <a href="/app" class="download-app-btn" style="display:inline-block; padding:8px 12px; background:linear-gradient(135deg,#1bd9ff,#0098be); color:#0d1117; border-radius:8px; font-weight:600; text-decoration:none;">تحميل التطبيق</a>
                        </div>
                    `;
                    botLoginCard.appendChild(warningMsg);
                }

                // إخفاء أي حالة سابقة
                if (tiktokLoginStatus) tiktokLoginStatus.style.display = 'none';

            } else {
                // ✅ إذا كان تطبيق سطح المكتب: إظهار الزر والتعامل معه

                tiktokLoginBtn.addEventListener('click', () => {
                    if (!currentUser) {
                        showToast('يجب تسجيل الدخول أولاً');
                        return;
                    }

                    // إذا كان الزر في وضع "تسجيل الخروج"
                    if (tiktokLoginBtn.classList.contains('logout-mode')) {
                        socket.emit('tiktok:logout:request');

                        // إعادة الزر لحالته الأصلية
                        tiktokLoginBtn.innerHTML = `
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                            <span>تسجيل الدخول</span>
                        `;
                        tiktokLoginBtn.classList.remove('logout-mode');
                        tiktokLoginBtn.style.background = '';

                        if (tiktokLoginStatus) {
                            tiktokLoginStatus.style.display = 'none';
                        }
                        return;
                    }

                    // إرسال الطلب للسيرفر
                    socket.emit('tiktok:login:request');

                    // تحديث واجهة المستخدم
                    if (tiktokLoginStatus) {
                        tiktokLoginStatus.style.display = 'block';
                        tiktokLoginStatus.textContent = '⏳ جاري فتح نافذة تسجيل الدخول...';
                    }
                });

                // الاستماع لحدث نجاح الاتصال (يأتي من السيرفر عندما يكتشف اتصال البوت)
                socket.on('tiktok:connection:state', (data) => {
                    // إعداد رسالة التحذير (فوق الزر)
                    let warningMsg = botLoginCard.querySelector('.login-warning-msg');
                    if (!warningMsg) {
                        warningMsg = document.createElement('div');
                        warningMsg.className = 'login-warning-msg';
                        warningMsg.style.cssText = 'background: rgba(255, 165, 0, 0.1); border: 1px solid rgba(255, 165, 0, 0.3); color: #ffa500; padding: 10px; border-radius: 6px; margin-bottom: 15px; text-align: center; font-size: 0.9em; display: none;';
                        botLoginCard.insertBefore(warningMsg, tiktokLoginBtn);
                    }

                    if (data.connected) {
                        // إخفاء التحذير عند الاتصال
                        warningMsg.style.display = 'none';

                        tiktokLoginBtn.innerHTML = `
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                <polyline points="16 17 21 12 16 7"></polyline>
                                <line x1="21" y1="12" x2="9" y2="12"></line>
                            </svg>
                            <span>تسجيل الخروج</span>
                        `;
                        tiktokLoginBtn.classList.add('logout-mode');
                        tiktokLoginBtn.style.background = '#e53e3e';

                        if (tiktokLoginStatus) {
                            tiktokLoginStatus.style.display = 'block';
                            tiktokLoginStatus.className = 'login-status-success';
                            tiktokLoginStatus.innerHTML = `
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg>
                                <span>متصل بتيك توك (${data.username || 'Unknown'})</span>
                            `;
                        }
                    } else {
                        // إظهار التحذير عند عدم الاتصال
                        warningMsg.innerHTML = '⚠️ لاستخدام البوت شات عليك تسجيل الدخول في تيك توك';
                        warningMsg.style.display = 'block';

                        // إعادة تعيين الحالة
                        tiktokLoginBtn.innerHTML = `
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                            <span>تسجيل الدخول</span>
                        `;
                        tiktokLoginBtn.classList.remove('logout-mode');
                        tiktokLoginBtn.style.background = '';
                        if (tiktokLoginStatus) tiktokLoginStatus.style.display = 'none';
                    }
                });
            }
        }
    } catch (err) {
        console.error('Error attaching tiktok login handler', err);
    }
    loadSavedState();
    initializeLoginForm();
    // ✅ checkAuthInSetup() تم نقلها للأعلى - لا حاجة لاستدعائها مرة أخرى

    // تحديث حالة الاتصال بعد تحميل الصفحة
    setTimeout(() => {
        if (currentUser) {
            checkConnectionStatus();
        }
    }, 500);

    // تحميل قائمة الهدايا من TikTok
    loadTikTokGifts();

    // تهيئة النافذة المنبثقة للإجراءات
    initializePopup();

    const playSoundCheckbox = document.getElementById('actPlaySound');
    if (playSoundCheckbox) {
        playSoundCheckbox.addEventListener('change', (e) => {
            document.getElementById('soundUploadWrapper').style.display = e.target.checked ? 'block' : 'none';
        });
    }

    const playVideoCheckbox = document.getElementById('actPlayVideo');
    if (playVideoCheckbox) {
        playVideoCheckbox.addEventListener('change', (e) => {
            document.getElementById('videoUploadWrapper').style.display = e.target.checked ? 'block' : 'none';
        });
    }

    // 🆕 إضافة مستمع للرسالة
    const showThankYouCheckbox = document.getElementById('actShowThankYou');
    if (showThankYouCheckbox) {
        showThankYouCheckbox.addEventListener('change', (e) => {
            document.getElementById('thankYouMessageOptions').style.display = e.target.checked ? 'block' : 'none';
        });
    }

    // 🌍 Country Filter Checkbox Handler
    const countryFilterCheckbox = document.getElementById('actCountryFilter');
    if (countryFilterCheckbox) {
        countryFilterCheckbox.addEventListener('change', (e) => {
            document.getElementById('countryFilterOptions').style.display = e.target.checked ? 'block' : 'none';
        });
    }

    // 🌍 Country Selector Handler
    const countrySelect = document.getElementById('actCountrySelect');
    const selectedCountriesDisplay = document.getElementById('selectedCountriesDisplay');

    if (countrySelect && selectedCountriesDisplay) {
        countrySelect.addEventListener('change', function() {
            const selectedOptions = Array.from(this.selectedOptions);
            const selectedCountries = selectedOptions.map(opt => ({
                code: opt.value,
                name: opt.textContent.trim()
            }));

            // تحديث العرض
            if (selectedCountries.length === 0) {
                selectedCountriesDisplay.innerHTML = '<span class="placeholder-text">لم يتم اختيار دول (الإجراء يعمل لجميع الدول)</span>';
            } else {
                selectedCountriesDisplay.innerHTML = selectedCountries.map(country => `
                    <span class="country-badge">
                        <span class="country-flag">${country.name.split(' ')[0]}</span>
                        <span class="country-name">${country.name.split(' ').slice(1).join(' ')}</span>
                        <button type="button" class="remove-country" data-country="${country.code}" title="إزالة">×</button>
                    </span>
                `).join('');

                // Add click handlers to remove buttons
                selectedCountriesDisplay.querySelectorAll('.remove-country').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const countryCode = this.dataset.country;
                        // Deselect the option
                        const option = Array.from(countrySelect.options).find(opt => opt.value === countryCode);
                        if (option) {
                            option.selected = false;
                        }
                        // Trigger change event
                        countrySelect.dispatchEvent(new Event('change'));
                    });
                });
            }
        });
    }

    // 🔍 Country Search Box Handler
    const countrySearchBox = document.getElementById('countrySearchBox');
    if (countrySearchBox && countrySelect) {
        countrySearchBox.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();

            // Loop through all options in all optgroups
            const optgroups = countrySelect.querySelectorAll('optgroup');
            optgroups.forEach(optgroup => {
                const options = optgroup.querySelectorAll('option');
                let visibleCount = 0;

                options.forEach(option => {
                    const countryName = option.textContent.toLowerCase();
                    const countryCode = option.value.toLowerCase();

                    // Check if search term matches country name or code
                    if (searchTerm === '' || countryName.includes(searchTerm) || countryCode.includes(searchTerm)) {
                        option.style.display = '';
                        visibleCount++;
                    } else {
                        option.style.display = 'none';
                    }
                });

                // Hide optgroup if no visible options
                if (visibleCount === 0) {
                    optgroup.style.display = 'none';
                } else {
                    optgroup.style.display = '';
                }
            });
        });

        // Auto-focus search when filter is opened
        const countryFilterCheckbox = document.getElementById('actCountryFilter');
        if (countryFilterCheckbox) {
            countryFilterCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    setTimeout(() => countrySearchBox.focus(), 100);
                }
            });
        }
    }

    // إضافة فحص حجم الملفات عند الاختيار
    const soundFileInput = document.getElementById('actSoundFile');
    if (soundFileInput) {
        soundFileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                if (file.size > 50 * 1024 * 1024) {
                    showToast(`⚠️ ملف الصوت كبير: ${(file.size / 1024 / 1024).toFixed(2)}MB (الحد الأقصى 50MB)`);
                    e.target.style.borderColor = '#dc3545';
                } else {
                    showToast(`✅ ملف الصوت مناسب: ${(file.size / 1024 / 1024).toFixed(2)}MB`);
                    e.target.style.borderColor = '#28a745';

                    // حذف أي صوت محدد من المكتبة
                    selectedLibrarySound = null;
                    // عرض الملف المحدد
                    showSelectedSound(file.name, 'ملف محلي');
                }
            }
        });
    }

    const videoFileInput = document.getElementById('actVideoFile');
    if (videoFileInput) {
        videoFileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file && file.size > 50 * 1024 * 1024) {
                showToast(`❌ ملف الفيديو كبير جداً: ${(file.size / 1024 / 1024).toFixed(2)}MB (الحد الأقصى 50MB)`, 'error');
                e.target.style.borderColor = '#dc3545';
                // مسح الملف من input
                e.target.value = '';
            } else if (file) {
                showToast(`✅ ملف الفيديو مناسب: ${(file.size / 1024 / 1024).toFixed(2)}MB`);
                e.target.style.borderColor = '#28a745';
                // عرض الفيديو المحدد
                showSelectedVideo(file.name);
            }
        });
    }
    // إضافة مستمع لإغلاق الصفحة (إغلاق فعلي)
    window.addEventListener('beforeunload', (e) => {
        if (socket && socket.connected && currentUser) {
            // إرسال إشارة واضحة للسيرفر بأن هذا إغلاق فعلي
            socket.emit('intentionalDisconnect', {
                userId: currentUser.id,
                reason: 'page_closed'
            });
            // قطع الاتصال فوراً
            socket.disconnect();
        }
    });

    // مستمع إضافي لـ unload للتأكد
    window.addEventListener('unload', () => {
        if (socket && socket.connected && currentUser) {
            socket.emit('intentionalDisconnect', {
                userId: currentUser.id,
                reason: 'page_unload'
            });
            socket.disconnect();
        }
    });

    // نظام متقدم لمنع انقطاع الاتصال عند إخفاء التبويب
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // بدء نظام Keep-Alive
    startKeepAlive();

    // مراقبة حالة الاتصال وإعادة الاتصال التلقائي
    setupConnectionMonitoring();
});

// نظام Keep-Alive للحفاظ على الاتصال نشطاً
// 🎯 المبدأ: keepalive يعمل في الخلفية مهما كانت حالة visibility
// ✅ Idempotent: آمن للاستدعاء المتكرر
function startKeepAlive() {
    // إيقاف أي keep-alive سابق (idempotency)
    if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
    }

    // إرسال نبضة قلب كل 25 ثانية (أقل من timeout)
    // ✅ يعمل حتى عندما document.hidden = true
    keepAliveInterval = setInterval(() => {
        if (socket && socket.connected && !SESSION_KICKED) {
            socket.emit('keepalive', {
                userId: currentUser ? .id,
                timestamp: Date.now(),
                hidden: document.hidden,
                instanceId: INSTANCE_ID
            });
            lastActivity = Date.now();
        }
    }, 25000); // 25 ثانية
}

// معالجة تغيير رؤية الصفحة
// 🎯 المبدأ: visibility لا يؤثر على الاتصال - Socket.IO يُدير reconnection تلقائياً
function handleVisibilityChange() {
    isPageVisible = !document.hidden;

    if (isPageVisible) {} else {}

    // ✅ تحديث lastActivity فقط - بدون أي reconnect logic
    lastActivity = Date.now();
}

// 🆕 توليد معرف فريد لهذه النافذة/التبويب عند التحميل
const INSTANCE_ID = Date.now().toString(36) + Math.random().toString(36).substr(2);

// 🔒 نظام حماية تعدد التبويبات (Client-Side Mutex)
function registerInstanceOwnership() {
    if (!currentUser ? .id) return;

    const key = `dashboard_owner_${currentUser.id}`;
    localStorage.setItem(key, INSTANCE_ID);
}

// 🔄 دالة مساعدة لإرسال join event (Global)
// 🎯 المبدأ: join تُرسل مرة واحدة عند first connect، ثم reconnect فقط عند انقطاع حقيقي
function emitJoinEvent() {
    if (currentUser && currentUser.id) {

        // تسجيل الملكية محلياً
        registerInstanceOwnership();

        socket.emit('join', {
            userId: currentUser.id,
            clientType: IS_DESKTOP ? 'Desktop' : 'Browser',
            instanceId: INSTANCE_ID,
            isFirstConnect: isFirstConnect // 🆕 إعلام السيرفر بنوع الاتصال
        });

        // ✅ بعد أول join، كل الاتصالات التالية هي reconnect
        if (isFirstConnect) {
            isFirstConnect = false;
        }
    } else {}
}

// مراقبة localStorage لاكتشاف التبويبات الأخرى
window.addEventListener('storage', (e) => {
    if (!currentUser ? .id) return;
    const key = `dashboard_owner_${currentUser.id}`;

    if (e.key === key && e.newValue !== INSTANCE_ID && !SESSION_KICKED) {
        handleSessionReplaced({
            message: 'تم فتح جلسة جديدة في تبويب آخر',
            timestamp: Date.now()
        });
    }
});

// دالة موحدة للتعامل مع استبدال الجلسة
function handleSessionReplaced(data) {
    if (SESSION_KICKED) return;
    SESSION_KICKED = true;

    // 🛑 إغلاق أي مودالات مفتوحة
    try {
        const modal = document.getElementById('subscriptionModal');
        if (modal) modal.style.display = 'none';
    } catch (e) {}

    // 🧊 إظهار شاشة الجلسة المكررة
    showSessionDuplicateOverlay();

    // 🔌 فصل السوكت
    try {
        if (socket.io) socket.io.reconnection(false);
        socket.disconnect();
    } catch (e) {}
}

// نظام مراقبة الاتصال
function setupConnectionMonitoring() {
    // مراقبة أحداث Socket.IO
    socket.on('connect', () => {
        // 🚫 GUARD: منع أي منطق إذا كانت الجلسة ميتة
        if (SESSION_KICKED) {
            socket.disconnect();
            return;
        }

        const connectType = isFirstConnect ? 'FIRST CONNECT' : 'RECONNECT';

        reconnectAttempts = 0;
        lastActivity = Date.now();

        // 🔄 بدء keepalive (idempotent - آمن للاستدعاء المتكرر)
        startKeepAlive();

        // 📤 إرسال join فقط إذا المستخدم معروف
        if (currentUser && currentUser.id) {
            emitJoinEvent();
        } else {}
    });



    socket.on('disconnect', (reason) => {

        // 🚫 GUARD: منع أي منطق للجلسات الميتة
        if (SESSION_KICKED) {
            return;
        }

        // 🎯 Socket.IO يُعيد الاتصال تلقائياً في معظم الحالات
        // نحتاج فقط للتعامل مع server-initiated disconnect
        if (reason === 'io server disconnect') {
            if (!SESSION_KICKED) {
                showToast('تم قطع الاتصال من السيرفر', 'error');
            }
        } else {}
    });

    socket.on('connect_error', (error) => {
        console.error('❌ خطأ في الاتصال:', error.message);
        reconnectAttempts++;
    });

    socket.on('reconnect', (attemptNumber) => {
        console.log('✅ Socket.IO أعاد الاتصال بالسيرفر - المحاولة:', attemptNumber);
        reconnectAttempts = 0;

        // 🔥 التحقق من الاتصال السابق من localStorage أو المتغير
        const shouldReconnect = wasConnectedBeforeDisconnect || wasConnectedRecently();

        // 🔄 إعادة الاتصال بالبث إذا كان متصلاً من قبل
        if (shouldReconnect && autoReconnectEnabled && !SESSION_KICKED) {
            const username = savedUsername || getUsernameFromLocalStorage();
            if (username) {
                console.log('🔄 محاولة إعادة الاتصال بـ TikTok تلقائياً:', username);
                showToast(`🔄 إعادة الاتصال بـ ${username}...`, 'info');
                setTimeout(() => {
                    attemptStreamReconnect();
                }, 2000);
            }
        }
    });

    socket.on('reconnect_attempt', (attemptNumber) => {});

    // 🔥 استقبال طلب إعادة الاتصال من السيرفر (بعد restart/deploy)
    socket.on('server_restart_reconnect_request', () => {
        console.log('🔄 السيرفر طلب فحص إعادة الاتصال...');

        // التحقق من الحالة في localStorage
        if (wasConnectedRecently() && !isConnected && !SESSION_KICKED) {
            const username = getUsernameFromLocalStorage();
            if (username) {
                console.log('✅ اكتشاف اتصال سابق - إعادة الاتصال:', username);
                wasConnectedBeforeDisconnect = true;
                autoReconnectEnabled = true;
                showToast(`🔄 إعادة الاتصال تلقائياً بـ ${username}...`, 'info');

                // محاولة إعادة الاتصال بعد ثانية
                setTimeout(() => {
                    if (!isConnected && !isConnecting) {
                        startConnection(username, true);
                    }
                }, 1000);
            }
        }
    });

    // فحص دوري للاتصال كل 30 ثانية
    setInterval(() => {
        const timeSinceLastActivity = Date.now() - lastActivity;

        // إذا مر أكثر من دقيقة بدون نشاط
        if (timeSinceLastActivity > 60000) {
            checkAndReconnect();
        }
    }, 30000);
}

// فحص الاتصال - بدون reconnect logic (Socket.IO يُدير هذا تلقائياً)
// 🎯 المبدأ: نرسل keepalive فقط، Socket.IO يُعيد الاتصال تلقائياً عند الحاجة
function checkAndReconnect() {
    // 🚫 GUARD: منع أي عمليات للجلسات الميتة
    if (SESSION_KICKED) {
        return;
    }

    // ✅ فقط إرسال keepalive إذا كان متصل - Socket.IO يُدير reconnection
    if (socket && socket.connected) {
        socket.emit('keepalive', {
            userId: currentUser ? .id,
            timestamp: Date.now(),
            hidden: document.hidden
        });
        lastActivity = Date.now();
    }
    // ⚠️ لا نستدعي socket.connect() - Socket.IO يُعيد الاتصال تلقائياً
}


// 🎯 المبدأ: Socket.IO يُدير reconnection تلقائياً - لا حاجة لـ manual scheduling
// هذه الدالة تم الاحتفاظ بها للتوافق مع الكود القديم فقط
function scheduleReconnect() {
    if (SESSION_KICKED) {
        return;
    }

    // ✅ Socket.IO يُدير reconnection تلقائياً مع exponential backoff
    // لا حاجة لـ manual reconnect logic
}

// دوال جلب الهدايا من TikTok
let giftsCache = null;
let giftsLoading = false;

async function loadTikTokGifts() {
    if (giftsLoading) return;

    giftsLoading = true;
    const giftSelector = document.getElementById('actGiftSelect');
    const refreshBtn = document.getElementById('refreshGiftsBtn');
    const selectedGift = document.getElementById('selectedGift');

    try {
        // إضافة تأثير التحميل
        giftSelector.classList.add('loading');
        giftSelector.disabled = true;
        refreshBtn.disabled = true;

        giftSelector.innerHTML = '<option value="">جاري تحميل الهدايا...</option>';
        selectedGift.innerHTML = '<span>جاري تحميل الهدايا...</span>';

        const response = await fetch('/api/gifts');
        const data = await response.json();

        if (data.success && data.gifts) {
            giftsCache = data.gifts;
            populateGiftsSelector(data.gifts);
            populateBotGiftsSelector(data.gifts); // ✅ تحديث قائمة هدايا البوت أيضاً
            showToast(`تم تحميل ${data.gifts.length} هدية من TikTok 🎁`);
        } else {
            throw new Error(data.message || 'فشل في جلب الهدايا');
        }

    } catch (error) {
        console.error('❌ خطأ في جلب الهدايا:', error);
        giftSelector.innerHTML = '<option value="">خطأ في تحميل الهدايا - انقر 🔄 للمحاولة مرة أخرى</option>';
        selectedGift.innerHTML = '<span>خطأ في تحميل الهدايا - انقر 🔄 للمحاولة مرة أخرى</span>';
        showToast('فشل في تحميل الهدايا - جرب مرة أخرى');
    } finally {
        giftSelector.classList.remove('loading');
        giftSelector.disabled = false;
        refreshBtn.disabled = false;
        giftsLoading = false;
    }
}

function populateGiftsSelector(gifts) {
    const giftSelector = document.getElementById('actGiftSelect');
    const customSelector = document.getElementById('customGiftSelector');
    const selectedGift = document.getElementById('selectedGift');
    const giftsDropdown = document.getElementById('giftsDropdown');

    // إفراغ القائمة العادية
    giftSelector.innerHTML = '';

    // إضافة خيار فارغ للقائمة العادية
    const emptyOption = document.createElement('option');
    emptyOption.value = '';
    emptyOption.textContent = 'اختر هدية معينة (أو اتركها فارغة لجميع الهدايا)';
    giftSelector.appendChild(emptyOption);

    // تحديث القائمة المخصصة
    selectedGift.innerHTML = `<span>اختر هدية معينة (${gifts.length} هدية متاحة)</span>`;
    giftsDropdown.innerHTML = '';

    // إضافة خيار فارغ للقائمة المخصصة
    const emptyCustomOption = document.createElement('div');
    emptyCustomOption.className = 'gift-option';
    emptyCustomOption.dataset.value = '';
    emptyCustomOption.innerHTML = `
        <div class="gift-info">
            <span class="gift-name">جميع الهدايا (حسب القيمة الدنيا)</span>
        </div>
    `;
    giftsDropdown.appendChild(emptyCustomOption);

    // إضافة الهدايا
    gifts.forEach(gift => {
        // للقائمة العادية
        const option = document.createElement('option');
        option.value = gift.name;
        option.dataset.giftId = gift.id;
        option.dataset.diamonds = gift.diamonds;
        option.dataset.image = gift.image || '';
        option.textContent = `${gift.name} | ${gift.diamonds} 💎`;
        giftSelector.appendChild(option);

        // للقائمة المخصصة
        const customOption = document.createElement('div');
        customOption.className = 'gift-option';
        customOption.dataset.value = gift.name;
        customOption.dataset.giftId = gift.id;
        customOption.dataset.diamonds = gift.diamonds;
        customOption.dataset.image = gift.image || '';

        // تحديد فئة الألماس للون
        let diamondClass = 'diamonds-0';
        if (gift.diamonds === 0) diamondClass = 'diamonds-0';
        else if (gift.diamonds <= 5) diamondClass = 'diamonds-low';
        else if (gift.diamonds <= 50) diamondClass = 'diamonds-medium';
        else if (gift.diamonds <= 500) diamondClass = 'diamonds-high';
        else diamondClass = 'diamonds-ultra';

        customOption.innerHTML = `
            ${gift.image ? `<img src="${gift.image}" alt="${gift.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div style="width: 28px; height: 28px; background: linear-gradient(45deg, #ff6b35, #f7931e); border-radius: 4px; display: none; align-items: center; justify-content: center; font-size: 14px; color: white; border: 1px solid #e1e5e9;">🎁</div>` : '<div style="width: 28px; height: 28px; background: linear-gradient(45deg, #667eea, #764ba2); border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 14px; color: white; border: 1px solid #e1e5e9;">🎁</div>'}
            <div class="gift-info">
                <span class="gift-name">${gift.name}</span>
                <span class="gift-diamonds ${diamondClass}">${gift.diamonds} 💎</span>
            </div>
        `;

        giftsDropdown.appendChild(customOption);
    });

    // إضافة مستمعي الأحداث للقائمة المخصصة
    setupCustomSelectorEvents();
}

function setupCustomSelectorEvents() {
    const customSelector = document.getElementById('customGiftSelector');
    const selectedGift = document.getElementById('selectedGift');
    const giftsDropdown = document.getElementById('giftsDropdown');
    const giftSelector = document.getElementById('actGiftSelect');

    // فتح/إغلاق القائمة
    selectedGift.onclick = function(e) {
        e.stopPropagation();
        customSelector.classList.toggle('open');
        giftsDropdown.classList.toggle('show');
    };

    // إغلاق القائمة عند النقر خارجها
    document.addEventListener('click', function(e) {
        if (!customSelector.contains(e.target)) {
            customSelector.classList.remove('open');
            giftsDropdown.classList.remove('show');
        }
    });

    // اختيار هدية
    giftsDropdown.addEventListener('click', function(e) {
        const option = e.target.closest('.gift-option');
        if (!option) return;

        const value = option.dataset.value;
        const giftName = value;
        const image = option.dataset.image;
        const diamonds = option.dataset.diamonds;

        // تحديث القائمة العادية المخفية
        giftSelector.value = value;

        // تحديث العرض المخصص
        if (value === '') {
            selectedGift.innerHTML = '<span>جميع الهدايا (حسب القيمة الدنيا)</span>';
        } else {
            selectedGift.innerHTML = `
                ${image ? `<img src="${image}" alt="${giftName}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div style="width: 24px; height: 24px; background: linear-gradient(45deg, #ff6b35, #f7931e); border-radius: 4px; display: none; align-items: center; justify-content: center; font-size: 12px; color: white; border: 1px solid #e1e5e9;">🎁</div>` : '<div style="width: 24px; height: 24px; background: linear-gradient(45deg, #667eea, #764ba2); border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 12px; color: white; border: 1px solid #e1e5e9;">🎁</div>'}
                <span>${giftName} | ${diamonds} 💎</span>
            `;
        }

        // إغلاق القائمة
        customSelector.classList.remove('open');
        giftsDropdown.classList.remove('show');

        // تشغيل معاينة الهدية
        showGiftPreview();
    });
}

function showGiftPreview() {
    const giftSelector = document.getElementById('actGiftSelect');
    const giftPreview = document.getElementById('giftPreview');
    const minValueInput = document.getElementById('actMinValue');
    const selectedValue = giftSelector.value;

    if (!selectedValue || selectedValue === '') {
        giftPreview.style.display = 'none';

        // تفعيل حقل القيمة الدنيا عند عدم اختيار هدية معينة
        minValueInput.disabled = false;
        minValueInput.style.opacity = '1';
        minValueInput.title = 'القيمة الدنيا للألماسات';

        return;
    }

    // البحث عن الهدية في giftsCache
    const gift = giftsCache ? .find(g => g.name === selectedValue);
    if (!gift) return;

    // تحديث محتوى المعاينة
    document.getElementById('giftPreviewName').textContent = gift.name;
    document.getElementById('giftPreviewDiamonds').textContent = `القيمة: ${gift.diamonds} 💎`;

    const imageElement = document.getElementById('giftPreviewImage');
    if (gift.image) {
        imageElement.src = gift.image;
        imageElement.style.display = 'block';
    } else {
        imageElement.style.display = 'none';
    }

    giftPreview.style.display = 'block';

    // تعطيل حقل القيمة الدنيا عند اختيار هدية معينة
    minValueInput.disabled = true;
    minValueInput.style.opacity = '0.5';
    minValueInput.title = 'القيمة الدنيا معطلة لأنك اخترت هدية معينة';
}

// تهيئة Bot Gift Selector (نسخة مستقلة لنافذة البوت)
function initializeBotGiftSelector() {
    const botCustomSelector = document.getElementById('botCustomGiftSelector');
    const botSelectedGift = document.getElementById('botSelectedGift');
    const botGiftsDropdown = document.getElementById('botGiftsDropdown');
    const botGiftSelector = document.getElementById('botActGiftSelect');
    const botRefreshBtn = document.getElementById('botRefreshGiftsBtn');

    if (!botCustomSelector) return;

    // زر التحديث
    if (botRefreshBtn) {
        botRefreshBtn.addEventListener('click', async () => {
            await loadGifts(true); // إعادة تحميل الهدايا
            populateBotGiftsSelector(giftsCache);
        });
    }

    // فتح/إغلاق القائمة
    if (botSelectedGift) {
        botSelectedGift.onclick = function(e) {
            e.stopPropagation();
            botCustomSelector.classList.toggle('open');
            botGiftsDropdown.classList.toggle('show');
        };
    }

    // إغلاق القائمة عند النقر خارجها
    document.addEventListener('click', function(e) {
        if (botCustomSelector && !botCustomSelector.contains(e.target)) {
            botCustomSelector.classList.remove('open');
            botGiftsDropdown.classList.remove('show');
        }
    });

    // اختيار هدية
    if (botGiftsDropdown) {
        botGiftsDropdown.addEventListener('click', function(e) {
            const option = e.target.closest('.gift-option');
            if (!option) return;

            const value = option.dataset.value;
            const giftName = value;
            const image = option.dataset.image;
            const diamonds = option.dataset.diamonds;

            // تحديث القائمة العادية المخفية
            if (botGiftSelector) botGiftSelector.value = value;

            // تحديث العرض المخصص
            if (value === '') {
                botSelectedGift.innerHTML = '<span>جميع الهدايا</span>';
            } else {
                botSelectedGift.innerHTML = `
                    ${image ? `<img src="${image}" alt="${giftName}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div style="width: 24px; height: 24px; background: linear-gradient(45deg, #ff6b35, #f7931e); border-radius: 4px; display: none; align-items: center; justify-content: center; font-size: 12px; color: white; border: 1px solid #e1e5e9;">🎁</div>` : '<div style="width: 24px; height: 24px; background: linear-gradient(45deg, #667eea, #764ba2); border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 12px; color: white; border: 1px solid #e1e5e9;">🎁</div>'}
                    <span>${giftName} | ${diamonds} 💎</span>
                `;
            }

            // إغلاق القائمة
            botCustomSelector.classList.remove('open');
            botGiftsDropdown.classList.remove('show');

            // تشغيل معاينة الهدية
            showBotGiftPreview();
        });
    }

    // تحميل الهدايا في Bot Selector
    if (giftsCache && giftsCache.length > 0) {
        populateBotGiftsSelector(giftsCache);
    }
}

// ملء Bot Gift Selector بالهدايا
function populateBotGiftsSelector(gifts) {
    const botGiftSelector = document.getElementById('botActGiftSelect');
    const botSelectedGift = document.getElementById('botSelectedGift');
    const botGiftsDropdown = document.getElementById('botGiftsDropdown');

    if (!botGiftSelector || !botGiftsDropdown) return;

    // إفراغ القائمة
    botGiftSelector.innerHTML = '';
    botGiftsDropdown.innerHTML = '';

    // إضافة خيار فارغ للقائمة العادية
    const emptyOption = document.createElement('option');
    emptyOption.value = '';
    emptyOption.textContent = 'اختر هدية';
    botGiftSelector.appendChild(emptyOption);

    // إضافة خيار فارغ للقائمة المخصصة
    const emptyCustomOption = document.createElement('div');
    emptyCustomOption.className = 'gift-option';
    emptyCustomOption.dataset.value = '';
    emptyCustomOption.innerHTML = `
        <div class="gift-info">
            <span class="gift-name">اختر هدية</span>
        </div>
    `;
    botGiftsDropdown.appendChild(emptyCustomOption);

    // تحديث النص الافتراضي
    botSelectedGift.innerHTML = `<span>اختر هدية (${gifts.length} متاحة)</span>`;

    // إضافة الهدايا
    gifts.forEach(gift => {
        // للقائمة العادية
        const option = document.createElement('option');
        option.value = gift.name;
        option.dataset.giftId = gift.id;
        option.dataset.diamonds = gift.diamonds;
        option.dataset.image = gift.image || '';
        option.textContent = `${gift.name} | ${gift.diamonds} 💎`;
        botGiftSelector.appendChild(option);

        // للقائمة المخصصة
        const customOption = document.createElement('div');
        customOption.className = 'gift-option';
        customOption.dataset.value = gift.name;
        customOption.dataset.giftId = gift.id;
        customOption.dataset.diamonds = gift.diamonds;
        customOption.dataset.image = gift.image || '';

        // تحديد فئة الألماس للون
        let diamondClass = 'diamonds-0';
        if (gift.diamonds === 0) diamondClass = 'diamonds-0';
        else if (gift.diamonds <= 5) diamondClass = 'diamonds-low';
        else if (gift.diamonds <= 50) diamondClass = 'diamonds-medium';
        else if (gift.diamonds <= 500) diamondClass = 'diamonds-high';
        else diamondClass = 'diamonds-ultra';

        customOption.innerHTML = `
            ${gift.image ? `<img src="${gift.image}" alt="${gift.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div style="width: 28px; height: 28px; background: linear-gradient(45deg, #ff6b35, #f7931e); border-radius: 4px; display: none; align-items: center; justify-content: center; font-size: 14px; color: white; border: 1px solid #e1e5e9;">🎁</div>` : '<div style="width: 28px; height: 28px; background: linear-gradient(45deg, #667eea, #764ba2); border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: 14px; color: white; border: 1px solid #e1e5e9;">🎁</div>'}
            <div class="gift-info">
                <span class="gift-name">${gift.name}</span>
                <span class="gift-diamonds ${diamondClass}">${gift.diamonds} 💎</span>
            </div>
        `;

        botGiftsDropdown.appendChild(customOption);
    });
}

// معاينة الهدية المحددة في Bot
function showBotGiftPreview() {
    const botGiftSelector = document.getElementById('botActGiftSelect');
    const botGiftPreview = document.getElementById('botGiftPreview');
    const selectedValue = botGiftSelector ? .value;

    if (!botGiftPreview) return;

    if (!selectedValue || selectedValue === '') {
        botGiftPreview.style.display = 'none';
        return;
    }

    // البحث عن الهدية في giftsCache
    const gift = giftsCache ? .find(g => g.name === selectedValue);
    if (!gift) return;

    // تحديث محتوى المعاينة
    const botGiftPreviewName = document.getElementById('botGiftPreviewName');
    const botGiftPreviewDiamonds = document.getElementById('botGiftPreviewDiamonds');
    const botGiftPreviewImage = document.getElementById('botGiftPreviewImage');

    if (botGiftPreviewName) botGiftPreviewName.textContent = gift.name;
    if (botGiftPreviewDiamonds) botGiftPreviewDiamonds.textContent = `القيمة: ${gift.diamonds} 💎`;

    if (botGiftPreviewImage && gift.image) {
        botGiftPreviewImage.src = gift.image;
        botGiftPreviewImage.style.display = 'block';
    } else if (botGiftPreviewImage) {
        botGiftPreviewImage.style.display = 'none';
    }

    botGiftPreview.style.display = 'block';
}

function initializeElements() {
    userEmailSpan = document.getElementById('userEmail');
    uniqueCodeSpan = document.getElementById('uniqueCode') || null;
    connectionStatus = document.getElementById('connectionStatus');
    connectBtn = document.getElementById('connectBtn');

    // عناصر إدخال اسم المستخدم - التحقق من العناصر في الهيدر أو الصفحة
    usernameInput = document.getElementById('usernameInput');
    currentUsernameDiv = document.getElementById('currentUsername');
    connectedUsernameSpan = document.getElementById('connectedUsername');

    // إذا لم نجد العناصر في الصفحة، نبحث عنها في الهيدر
    if (!usernameInput) {
        usernameInput = document.querySelector('.username-input-header');
    }
    if (!connectBtn) {
        connectBtn = document.querySelector('.connect-btn-header');
    }

    viewersCount = document.getElementById('viewersCount');
    commentsCount = document.getElementById('commentsCount');
    // removed followsCount element (follow statistics UI removed)
    giftsCount = document.getElementById('giftsCount');
    commentsList = document.getElementById('commentsList') || null;

    // عناصر روابط الـ widgets
    commentsWidgetUrl = document.getElementById('commentsWidgetUrl');
    likesWidgetUrl = document.getElementById('likesWidgetUrl');
    followsWidgetUrl = document.getElementById('followsWidgetUrl');
    horizontalPodiumUrl = document.getElementById('horizontalPodiumUrl');
    horizontalPodiumSupportersUrl = document.getElementById('horizontalPodiumSupportersUrl');
    fireworkWidgetUrl = document.getElementById('fireworkWidgetUrl');
}

function setupEventListeners() {
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        // attach safe handler: prefer existing handleLogout, otherwise use a fallback
        if (typeof handleLogout === 'function') {
            logoutBtn.addEventListener('click', handleLogout);
        } else {
            logoutBtn.addEventListener('click', async () => {
                // fallback: try to sign out and update UI without throwing
                try {
                    if (supabase && supabase.auth && typeof supabase.auth.signOut === 'function') {
                        await supabase.auth.signOut();
                    }
                } catch (err) {
                    console.error('Fallback logout error', err);
                }
                try {
                    updateSetupUIForLoggedOutUser();
                } catch (e) {}
                try {
                    window.location.href = '/';
                } catch (e) {}
            });
        }
    }

    if (connectBtn) {
        connectBtn.addEventListener('click', handleConnect);
    }

    // إضافة مستمع لزر تحديث الهدايا
    const refreshGiftsBtn = document.getElementById('refreshGiftsBtn');
    if (refreshGiftsBtn) {
        refreshGiftsBtn.addEventListener('click', () => {
            giftsCache = null; // مسح الـ cache لإجبار إعادة التحميل
            loadTikTokGifts();
        });
    }

    // إضافة مستمع للضغط على Enter في حقل اسم المستخدم
    usernameInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !isConnected) {
            handleConnect();
        }
    });

    // 🆕 إضافة مستمع لتغيير حقل اليوزر أثناء محاولة الاتصال
    usernameInput.addEventListener('input', handleUsernameChange);

    // 🆕 حفظ اسم المستخدم في localStorage عند الكتابة
    usernameInput.addEventListener('blur', () => {
        const username = usernameInput.value.trim();
        if (username && username.length >= 2) {
            saveUsernameToLocalStorage(username);
            savedUsername = username;
        }
    });


    socket.on('disconnect', () => {});

    socket.on('connectionStatus', (data) => {

        const wasConnected = isConnected;
        isConnected = data.connected;

        if (data.connected && data.username) {
            savedUsername = data.username;
            saveConnectionState(data.username, true);
            saveUsernameToLocalStorage(data.username); // حفظ في localStorage

            connectBtn.textContent = 'قطع الاتصال';
            connectBtn.style.background = 'linear-gradient(45deg, #dc3545, #c82333)';
            connectBtn.disabled = false;
            showToast(`✅ متصل بـ: ${data.username}`, 'success');

            // ✅ تتبع حالة الاتصال
            wasConnectedBeforeDisconnect = true;
            reconnectAttempts = 0; // إعادة تعيين عداد المحاولات عند النجاح
        } else {
            // 🔄 تم قطع الاتصال
            const currentSavedUsername = savedUsername || getUsernameFromLocalStorage();

            if (wasConnected && currentSavedUsername && !SESSION_KICKED) {
                // حالة انقطاع غير متوقع
                lastDisconnectTime = Date.now();

                showToast(`⚠️ انقطع الاتصال - سيتم إعادة الاتصال تلقائياً...`, 'warning');

                // 🔄 بدء إعادة الاتصال التلقائي بعد 3 ثواني
                setTimeout(() => {
                    attemptStreamReconnect();
                }, 3000);
            }

            savedUsername = currentSavedUsername; // الحفاظ على اليوزر نيم المحفوظ
            saveConnectionState(null, false);
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            connectBtn.disabled = false;
        }

        updateConnectionStatus();

        if (data.stats) {
            currentStats = data.stats;
            updateStatsDisplay();
        }
    });

    // 📡 مزامنة حالة البث من الجلسة الأخرى (للمتصفح)
    socket.on('liveStateSync', (data) => {

        // إذا كانت البيانات تشير إلى قطع الاتصال (وهو المتوقع الآن عند تبديل الجلسة)
        if (!data.connected) {
            isConnected = false;
            savedUsername = null;
            saveConnectionState(null, false);
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            connectBtn.disabled = false;
            updateConnectionStatus();

            // 🆕 محاولة إعادة الاتصال التلقائي إذا كان هناك اسم مستخدم محفوظ
            const lastUser = localStorage.getItem('tiktok_username');
            if (lastUser && !SESSION_KICKED) {
                usernameInput.value = lastUser;
                handleConnect();
            }
        } else if (data.connected && data.username) {
            // هذا الجزء قد لا يتم استدعاؤه الآن لأننا أوقفنا المزامنة الإيجابية
            // لكن نبقيه للاحتياط
            isConnected = true;
            savedUsername = data.username;
            saveConnectionState(data.username, true);
            connectBtn.textContent = 'قطع الاتصال';
            connectBtn.style.background = 'linear-gradient(45deg, #dc3545, #c82333)';
            connectBtn.disabled = false;
            showToast(`📡 متصل بـ: ${data.username}`);
            updateConnectionStatus();
        }
    });

    // 🔒 معالجة حدث استبدال الجلسة (FINAL)
    socket.on('session:replaced', (data) => {

        // 🔥 أهم سطر: إعلان الجلسة ميتة
        SESSION_KICKED = true;

        // 🛑 إغلاق أي مودال مفتوح (خصوصًا الاشتراك)
        try {
            const subModal = document.getElementById('subscriptionModal');
            if (subModal) subModal.style.display = 'none';
        } catch (e) {}

        // 🐙 إظهار شاشة التكرار (دائمًا)
        showSessionDuplicateOverlay();

        // 🚫 تعطيل كل التفاعل مع الصفحة
        try {
            document.body.style.pointerEvents = 'none';
            const overlay = document.getElementById('sessionDuplicateOverlay');
            if (overlay) overlay.style.pointerEvents = 'auto';
        } catch (e) {}

        // 🧹 تعطيل كل العناصر التفاعلية
        try {
            document.querySelectorAll('button, input, select, textarea, a').forEach(el => {
                try {
                    // نفترض أن زر الاستعادة يجب أن يبقى قابلاً للنقر
                    if (el.id === 'takeOverSessionBtn') {
                        try {
                            el.disabled = false;
                        } catch (e) {}
                        try {
                            el.style.pointerEvents = 'auto';
                        } catch (e) {}
                        try {
                            el.tabIndex = 0;
                        } catch (e) {}
                        return; // لا تعطل هذا الزر
                    }
                } catch (e) {}

                try {
                    el.disabled = true;
                } catch (e) {}
                try {
                    el.style.pointerEvents = 'none';
                } catch (e) {}
            });
        } catch (e) {}

        // ⛔ إيقاف أي مؤقتات
        try {
            if (keepAliveInterval) {
                clearInterval(keepAliveInterval);
                keepAliveInterval = null;
            }
        } catch (e) {}
        try {
            if (overlayStatusTimer) {
                clearInterval(overlayStatusTimer);
                overlayStatusTimer = null;
            }
        } catch (e) {}
        try {
            if (inputChangeTimeout) {
                clearTimeout(inputChangeTimeout);
                inputChangeTimeout = null;
            }
        } catch (e) {}

        // 🔌 فصل السوكت ومنع أي reconnect
        try {
            socket.disconnect();
        } catch (e) {}

        // إعطاء تركيز لزر "Take over" بعد إظهار الـ overlay
        try {
            const takeBtn = document.getElementById('takeOverSessionBtn');
            if (takeBtn) {
                takeBtn.focus({
                    preventScroll: true
                });
            }
        } catch (e) {}
    });

    // ✅ تم نقل دوال التحكم بالجلسة (showSessionDuplicateOverlay, etc.) إلى النطاق العام
    // لضمان عملها مع جميع معالجات الأحداث.

    socket.on('stats', (stats) => {
        currentStats = stats;
        updateStatsDisplay();
    });

    socket.on('comment', (comment) => {
        if (typeof addComment === 'function') {
            addComment(comment.user, comment.text);
        }
    });

    socket.on('like', (data) => {
        if (typeof showToast === 'function') {
            showToast(`👍 ${data.user} أعجب بالبث (${data.count})`);
        }
    });

    socket.on('gift', (gift) => {});

    socket.on('newMember', (data) => {
        if (typeof showToast === 'function') {
            showToast(`👋 ${data.user} انضم للبث`);
        }
    });

    socket.on('follow', (data) => {
        if (typeof showToast === 'function') {
            showToast(`❤️ ${data.user} تابعك الآن!`);
        }

        // إضافة تأثير بصري أو صوتي إضافي للمتابعة
        // تم إزالة تشغيل الصوت حسب طلب المستخدم - نعرض فقط الأنيميشن البصري
        if (typeof showFollowAnimation === 'function') {
            showFollowAnimation();
        }
    });

    socket.on('share', (data) => {
        if (typeof showToast === 'function') {
            showToast(`📤 ${data.user} شارك البث`);
        }
    });

    socket.on('error', (data) => {
        if (typeof showToast === 'function') {
            showToast(`خطأ: ${data.message}`);
        }
        console.error('خطأ من السيرفر:', data);
    });

    // معالجة أخطاء تسجيل الدخول إلى TikTok
    socket.on('tiktok:login:error', (data) => {
        console.error('❌ TikTok login error:', data);

        const tiktokLoginStatus = document.getElementById('tiktokLoginStatus');
        if (tiktokLoginStatus) {
            tiktokLoginStatus.style.display = 'block';
            tiktokLoginStatus.className = 'login-status-error';
            tiktokLoginStatus.innerHTML = `
                <div style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="15" y1="9" x2="9" y2="15"></line>
                            <line x1="9" y1="9" x2="15" y2="15"></line>
                        </svg>
                        <span>${data.message || 'فشل تسجيل الدخول'}</span>
                    </div>
                    <button onclick="location.reload()" style="margin-top: 10px; padding: 8px 16px; background: rgba(229, 62, 62, 0.2); border: 1px solid rgba(229, 62, 62, 0.4); color: #e53e3e; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600;">
                        🔄 إعادة تحميل الصفحة
                    </button>
                </div>
            `;

            // إخفاء الرسالة بعد 10 ثواني
            setTimeout(() => {
                if (tiktokLoginStatus && tiktokLoginStatus.className === 'login-status-error') {
                    tiktokLoginStatus.style.display = 'none';
                }
            }, 10000);
        }

        if (typeof showToast === 'function') {
            showToast(`❌ ${data.message}`);
        }
    });

    socket.on('subscription_required', (data) => {
        // ⛔ لو الجلسة مكررة لا نعرض أي شيء
        if (SESSION_KICKED) {
            return;
        }
        showSubscriptionModal();
    });

}

// دالة تحديث URLs الخاصة بالـ Widgets
function updateWidgetUrls() {
    // 🚫 GUARD: منع أي تحديثات UI للجلسات الميتة
    if (SESSION_KICKED) {
        return;
    }

    if (!currentUser) return;

    const baseUrl = window.location.origin;

    // 🔴 CRITICAL: Must have real widgetToken from database
    if (!widgetToken) {
        return; // Don't update URLs with fake token
    }

    // تحديث روابط الـ Widgets
    const widgets = [{
            id: 'commentsWidgetUrl',
            path: 'widget/comments'
        },
        {
            id: 'likesWidgetUrl',
            path: 'widget/likes'
        },
        {
            id: 'followsWidgetUrl',
            path: 'widget/follows'
        },
        {
            id: 'horizontalPodiumUrl',
            path: 'widget/horizontal-podium'
        }, // رابط موحد ديناميكي
        {
            id: 'horizontalPodiumSupportersUrl',
            path: 'widget/horizontal-podium-supporters'
        }
        // firework widget يتم تحديثه من loadUserData بالتوكن الصحيح
    ];

    widgets.forEach(widget => {
        const element = document.getElementById(widget.id);
        if (element) {
            element.textContent = `${baseUrl}/${widget.path}?token=${widgetToken}`;
        }
    });

    // إذا كانت هناك عناصر iframe للمعاينة، عين الـ src من النص الموجود في العنصر المقابل
    try {
        const setPreviewSrc = (spanId, iframeId) => {
            const span = document.getElementById(spanId);
            const iframe = document.getElementById(iframeId);
            if (span && iframe) {
                const url = span.textContent && span.textContent.trim();
                if (url) iframe.src = url;
            }
        };

        setPreviewSrc('commentsWidgetUrl', 'commentsWidgetPreview');
        setPreviewSrc('likesWidgetUrl', 'likesWidgetPreview');
        setPreviewSrc('followsWidgetUrl', 'followsWidgetPreview');
        setPreviewSrc('horizontalPodiumUrl', 'horizontalPodiumPreview');
        setPreviewSrc('horizontalPodiumSupportersUrl', 'horizontalPodiumSupportersPreview');
        // firework preview يتم تعيينه في loadUserData
    } catch (e) {}
}

// توليد token للمستخدم
function generateUserToken() {
    if (!currentUser) return '';

    // استخدام معرف المستخدم لتوليد token فريد
    const userId = currentUser.id;
    const userEmail = currentUser.email;

    // توليد token بسيط (يمكن تحسينه لاحقاً)
    return btoa(userId + ':' + userEmail).replace(/[+/=]/g, '').substring(0, 16);
}


async function loadUserData() {
    // 🚫 GUARD: منع تحميل البيانات للجلسات الميتة
    if (SESSION_KICKED) {
        return;
    }

    try {

        // التحقق من صحة UUID
        if (!isValidUUID(currentUser ? .id)) {
            console.error('❌ معرف المستخدم غير صالح:', currentUser ? .id);
            showToast('خطأ: معرف المستخدم غير صالح. يرجى تسجيل الخروج وإعادة تسجيل الدخول.', 'error');
            // محاولة تسجيل الخروج وتنظيف البيانات
            await supabase.auth.signOut();
            updateSetupUIForLoggedOutUser();
            return;
        }

        userEmailSpan.textContent = currentUser.email;

        // جلب بيانات المستخدم من قاعدة البيانات
        const {
            data: userData,
            error
        } = await supabase
            .from('users')
            .select('*')
            .eq('user_id', currentUser.id) // currentUser.id هو UUID من Supabase Auth
            .single();

        // إضافة user_id إلى currentUser للاستخدام لاحقاً
        if (userData) {
            currentUser.user_id = userData.user_id;
        }

        if (error) {
            // 🔐 معالجة خطأ JWT expired
            if (error.message ? .includes('JWT') || error.message ? .includes('expired')) {
                showToast('انتهت صلاحية الجلسة. يرجى تسجيل الدخول مرة أخرى.', 'error');
                await supabase.auth.signOut();
                updateSetupUIForLoggedOutUser();
                return;
            }

            if (error.code === 'PGRST116') {
                // لا يوجد مستخدم - إنشاء ملف جديد
                await createNewUserProfile();
                return;
            } else {
                throw error;
            }
        }

        if (userData) {

            // 🔧 إذا لم يكن هناك widget_token، قم بإنشائه وتحديث قاعدة البيانات
            if (!userData.widget_token) {
                const newToken = generateWidgetToken();

                // تحديث قاعدة البيانات
                const {
                    error: updateError
                } = await supabase
                    .from('users')
                    .update({
                        widget_token: newToken
                    })
                    .eq('user_id', currentUser.id);

                if (!updateError) {
                    userData.widget_token = newToken;
                } else {
                    console.error('❌ فشل في إنشاء widget_token:', updateError);
                }
            }

            if (uniqueCodeSpan) uniqueCodeSpan.textContent = userData.unique_code;

            // بناء الروابط ديناميكياً من widget_token
            const origin = window.location.origin;
            const token = userData.widget_token || '';
            widgetToken = token; // تخزين التوكن في المتغير العام

            commentsWidgetUrl.textContent = `${origin}/widget/comments?token=${token}`;
            likesWidgetUrl.textContent = `${origin}/widget/likes?token=${token}`;
            const likeHeartsWidgetUrl = document.getElementById('likeHeartsWidgetUrl');
            if (likeHeartsWidgetUrl) {
                likeHeartsWidgetUrl.textContent = `${origin}/widget/like-hearts?token=${token}`;
            }
            followsWidgetUrl.textContent = `${origin}/widget/follows?token=${token}`;
            horizontalPodiumUrl.textContent = `${origin}/widget/horizontal-podium?token=${token}`;
            if (fireworkWidgetUrl) {
                fireworkWidgetUrl.textContent = `${origin}/widget/firework?token=${token}`;
                // تحديث معاينة الألعاب النارية بالتوكن الصحيح مع معامل isDashboardView لكتم الصوت
                const fireworkPreview = document.getElementById('fireworkWidgetPreview');
                if (fireworkPreview) {
                    fireworkPreview.src = `${origin}/widget/firework?token=${token}&isDashboardView=true`;
                }
            }
            horizontalPodiumSupportersUrl.textContent = `${origin}/widget/horizontal-podium-supporters?token=${token}`;

            // إضافة رابط هدف Heart Me
            const heartMeGoalUrl = document.getElementById('heartMeGoalUrl');
            if (heartMeGoalUrl) {
                heartMeGoalUrl.textContent = `${origin}/widget/heart-me-goal?token=${token}`;
            }

            // إضافة رابط هدف اللايكات (Like Goal)
            const likeGoalUrl = document.getElementById('likeGoalUrl');
            if (likeGoalUrl) {
                likeGoalUrl.textContent = `${origin}/widget/like-goal?token=${token}`;
            }

            // إضافة رابط هدف المتابعة
            const followGoalUrl = document.getElementById('followGoalUrl');
            if (followGoalUrl) {
                followGoalUrl.textContent = `${origin}/widget/follow-goal?token=${token}`;
            }

            // إضافة رابط هدف المشاركة
            const shareGoalUrl = document.getElementById('shareGoalUrl');
            if (shareGoalUrl) {
                shareGoalUrl.textContent = `${origin}/widget/share-goal?token=${token}`;
            }

            // إضافة رابط TTS
            const ttsUrl = document.getElementById('ttsUrl');
            if (ttsUrl) {
                ttsUrl.textContent = `${origin}/widget/tts?token=${token}`;
            }

            // إضافة رابط Overlay Composer
            const composerViewUrl = document.getElementById('composerViewUrl');
            if (composerViewUrl) {
                composerViewUrl.textContent = `${origin}/overlay-composer-view?token=${token}`;
            }

            // Set preview iframes dynamically
            try {
                const followsPreview = document.getElementById('followsWidgetPreview');
                if (followsPreview) {
                    followsPreview.src = `${origin}/widget/follows?token=${token}&muteSound=true`;
                }

                const podiumPreview = document.getElementById('horizontalPodiumPreview');
                if (podiumPreview) {
                    podiumPreview.src = `${origin}/widget/horizontal-podium?token=${token}`;
                }

                const podiumSupportersPreview = document.getElementById('horizontalPodiumSupportersPreview');
                if (podiumSupportersPreview) {
                    podiumSupportersPreview.src = `${origin}/widget/horizontal-podium-supporters?token=${token}`;
                }

                const likesPreview = document.getElementById('likesWidgetPreview');
                if (likesPreview) {
                    likesPreview.src = `${origin}/widget/likes?token=${token}&muteSound=true`;
                }

                const likeHeartsPreview = document.getElementById('likeHeartsWidgetPreview');
                if (likeHeartsPreview) {
                    likeHeartsPreview.src = `${origin}/widget/like-hearts?token=${token}`;
                }

                const commentsPreview = document.getElementById('commentsWidgetPreview');
                if (commentsPreview) {
                    commentsPreview.src = `${origin}/widget/comments?token=${token}`;
                }

                // إضافة preview لهدف Heart Me
                const heartMeGoalPreview = document.getElementById('heartMeGoalPreview');
                if (heartMeGoalPreview) {
                    heartMeGoalPreview.src = `${origin}/widget/heart-me-goal?token=${token}`;
                }

                // إضافة preview لهدف اللايكات (Like Goal)
                const likeGoalPreview = document.getElementById('likeGoalPreview');
                if (likeGoalPreview) {
                    likeGoalPreview.src = `${origin}/widget/like-goal?token=${token}`;
                }

                // إضافة preview لهدف المتابعة
                const followGoalPreview = document.getElementById('followGoalPreview');
                if (followGoalPreview) {
                    followGoalPreview.src = `${origin}/widget/follow-goal?token=${token}`;
                }

                // إضافة preview لهدف المشاركة
                const shareGoalPreview = document.getElementById('shareGoalPreview');
                if (shareGoalPreview) {
                    shareGoalPreview.src = `${origin}/Share-goal.html?token=${token}`;
                }
            } catch (e) {}

            // تفعيل النافذة المنبثقة للإجراءات
            initializePopup();

            // تفعيل أزرار الأكشنز (بحماية من عدم وجود العناصر)
            const createActionBtn = document.getElementById('createActionBtn');

            if (createActionBtn) {
                // استخدام userData.user_id أو currentUser.id كبديل
                const userIdForAction = userData.user_id || currentUser ? .id;
                createActionBtn.onclick = () => {
                    createAction(userIdForAction);
                };
            }

            const finalUserId = userData.user_id || currentUser ? .id;
            loadActions(finalUserId);

            // ✅ تحميل إجراءات البوت فوراً بعد التأكد من المستخدم
            loadBotActions();

            // تحميل قائمة الهدايا من TikTok
            loadTikTokGifts();

            // تحميل إعدادات Overlay بعد تأكد من تحميل العناصر
            renderOverlaySettings(userData.widget_token, userData.user_id);

            // تحميل إعدادات TTS بعد تعيين widgetToken
            loadTTSSettings();

            // 🎯 Trigger user data ready event
            triggerUserDataReady();

        }

    } catch (error) {
        console.error('خطأ في تحميل بيانات المستخدم:', error);

        let errorMessage = 'حدث خطأ في تحميل البيانات';

        if (error.message && error.message.includes('network')) {
            errorMessage = 'مشكلة في الاتصال بقاعدة البيانات';
        } else if (error.message && error.message.includes('permission')) {
            errorMessage = 'لا تملك صلاحية الوصول إلى هذه البيانات';
        }

        showToast(errorMessage);
    }
}

// دالة إنشاء ملف مستخدم جديد
async function createNewUserProfile() {
    try {
        const uniqueCode = generateUniqueCode();
        const widgetToken = generateWidgetToken();

        const {
            data: newUser,
            error: insertError
        } = await supabase
            .from('users')
            .insert([{
                user_id: currentUser.id,
                email: currentUser.email,
                unique_code: uniqueCode,
                widget_token: widgetToken
            }])
            .select()
            .single();

        if (insertError) {
            throw insertError;
        }

        // إضافة user_id إلى currentUser
        if (newUser) {
            currentUser.user_id = newUser.user_id;
        }

        // إعادة تحميل بيانات المستخدم الجديدة
        await loadUserData();

    } catch (error) {
        console.error('خطأ في إنشاء ملف المستخدم:', error);
        showToast('حدث خطأ في إعداد حسابك');
    }
}

// دوال مساعدة
function generateUniqueCode() {
    return Math.random().toString(36).substr(2, 10).toUpperCase();
}

function generateWidgetToken() {
    return Math.random().toString(36).substr(2, 20) + Date.now().toString(36);
}

async function handleLogout() {
    try {
        // تنظيف الحالة المحفوظة عند تسجيل الخروج
        clearSavedState();

        // حذف الجلسة من localStorage يدوياً
        localStorage.removeItem('sb-user-auth-token');
        localStorage.removeItem('supabase.auth.token');
        sessionStorage.clear();

        // تسجيل الخروج من Supabase مع scope محلي لتجنب 403
        try {
            await supabase.auth.signOut({
                scope: 'local'
            });
        } catch (signOutError) {
            // تجاهل أي خطأ في signOut لأننا حذفنا الجلسة يدوياً
        }

        window.location.href = '/';

    } catch (error) {
        console.error('خطأ في تسجيل الخروج:', error);
        // حتى لو حدث خطأ، نظف الحالة وأعد التوجيه
        localStorage.removeItem('sb-user-auth-token');
        localStorage.removeItem('supabase.auth.token');
        window.location.href = '/';
    }
}

// 🆕 معالج تغيير حقل اليوزر - يراقب التغييرات ويطلق اتصال جديد فورًا
function handleUsernameChange(e) {
    const newUsername = e.target.value.trim();

    // تنظيف المؤقت السابق
    if (inputChangeTimeout) {
        clearTimeout(inputChangeTimeout);
    }

    // إذا كنا في حالة اتصال (جاري الاتصال أو متصل)
    if (isConnecting || isConnected) {
        // التحقق من أن اليوزر تغير فعلاً
        if (newUsername && newUsername !== lastInputValue) {

            // استخدام debounce بسيط (500ms) لتجنب الطلبات المتكررة أثناء الكتابة
            inputChangeTimeout = setTimeout(() => {
                reconnectWithNewUsername(newUsername);
            }, 500);
        }
    }
}

// 🆕 إعادة الاتصال بيوزر جديد (يلغي الاتصال القديم ويبدأ بالجديد فورًا)
async function reconnectWithNewUsername(newUsername) {
    // التحقق من صحة اليوزر
    if (!newUsername || newUsername.length < 2) {
        return;
    }

    if (newUsername.includes('@')) {
        showToast('⚠️ اسم المستخدم بدون @');
        return;
    }

    // تحديث الحالة
    isConnecting = true;
    lastInputValue = newUsername;

    // تحديث واجهة المستخدم
    if (connectBtn) {
        connectBtn.disabled = true;
        connectBtn.textContent = 'جاري الاتصال...';
    }

    try {
        // إرسال طلب الاتصال الجديد (السيرفر سيلغي القديم تلقائيًا)
        const response = await fetch('/api/connect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: newUsername,
                userId: currentUser.id
            })
        });

        const result = await response.json();

        if (result.success) {
            savedUsername = newUsername;
            saveConnectionState(newUsername, true);
            showToast(`✅ متصل بـ: ${newUsername}`);

            // تحديث الواجهة
            isConnected = true;
            isConnecting = false;
            if (connectBtn) {
                connectBtn.textContent = 'قطع الاتصال';
                connectBtn.style.background = 'linear-gradient(45deg, #dc3545, #c82333)';
                connectBtn.disabled = false;
            }
            updateConnectionStatus();

            // التحقق من الحالة بعد ثانيتين
            setTimeout(() => {
                checkConnectionStatus();
            }, 2000);

        } else if (result.cancelled) {
            // تم إلغاء الاتصال لصالح اتصال جديد
            isConnecting = false;
        } else {
            showToast(`❌ فشل الاتصال: ${result.message}`);
            isConnecting = false;
            isConnected = false;
            if (connectBtn) {
                connectBtn.textContent = 'الاتصال بالتيك توك';
                connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
                connectBtn.disabled = false;
            }
        }

    } catch (error) {
        console.error('❌ خطأ في إعادة الاتصال:', error);
        showToast(`❌ خطأ: ${error.message}`);
        isConnecting = false;
        isConnected = false;
        if (connectBtn) {
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            connectBtn.disabled = false;
        }
    }
}

async function handleConnect() {
    // 🚫 GUARD: منع أي محاولة اتصال للجلسات الميتة
    if (SESSION_KICKED) {
        showToast('⛔ هذه الجلسة مغلقة - يرجى تحديث الصفحة', 'error');
        return;
    }

    if (!isConnected) {
        // الحصول على اسم المستخدم من الحقل
        const username = usernameInput.value.trim();

        if (!username) {
            showToast('يرجى إدخال اسم المستخدم');
            usernameInput.focus();
            return;
        }

        // التحقق من صحة اسم المستخدم (لا يحتوي على @)
        if (username.includes('@')) {
            showToast('يرجى إدخال اسم المستخدم بدون علامة @');
            usernameInput.focus();
            return;
        }

        // التحقق من طول اسم المستخدم
        if (username.length < 2) {
            showToast('اسم المستخدم قصير جداً');
            usernameInput.focus();
            return;
        }

        await startConnection(username);
    } else {
        await stopConnection();
    }
}

async function startConnection(username, isAutoReconnect = false) {
    // 🚫 GUARD: منع بدء اتصال جديد للجلسات الميتة
    if (SESSION_KICKED) {
        showToast('⛔ هذه الجلسة مغلقة - يرجى تحديث الصفحة', 'error');
        return;
    }

    try {
        // 🆕 تحديث حالة الاتصال
        isConnecting = true;
        lastInputValue = username;

        // 🆕 حفظ اسم المستخدم فوراً في localStorage
        saveUsernameToLocalStorage(username);
        savedUsername = username;

        connectBtn.disabled = true;
        connectBtn.textContent = isAutoReconnect ? 'إعادة الاتصال...' : 'جاري الاتصال...';

        const response = await fetch('/api/connect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                userId: currentUser.id
            })
        });

        const result = await response.json();

        // 🔒 معالجة حالة الاشتراك المطلوب (403 Forbidden)
        if (response.status === 403 || response.status === 402) {
            // إظهار نافذة الاشتراك بدلاً من رسالة الخطأ
            showSubscriptionModal();
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            connectBtn.disabled = false;
            isConnecting = false;
            return;
        }

        // 🔒 معالجة حالة الاتصال الجاري (409 Conflict)
        if (response.status === 409) {
            showToast(`⏳ ${result.message || 'جاري الاتصال، يرجى الانتظار...'}`);
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            connectBtn.disabled = false;
            isConnecting = false;
            return;
        }

        if (result.success) {
            // ✅ حفظ اسم المستخدم وحالة الاتصال
            savedUsername = username;
            saveConnectionState(username, true);
            saveUsernameToLocalStorage(username); // حفظ في localStorage
            syncUsernameWithServer(username); // مزامنة مع السيرفر

            // ✅ تتبع حالة الاتصال الناجح
            wasConnectedBeforeDisconnect = true;
            reconnectAttempts = 0; // إعادة تعيين عداد المحاولات

            // 🔥 حفظ حالة الاتصال في localStorage
            saveConnectionState(true, username);

            showToast(isAutoReconnect ? '✅ تم إعادة الاتصال بنجاح!' : '✅ تم الاتصال بنجاح!', 'success');

            // تحديث الواجهة فوراً بدلاً من انتظار Socket.IO
            isConnected = true;
            isConnecting = false;
            connectBtn.textContent = 'قطع الاتصال';
            connectBtn.style.background = 'linear-gradient(45deg, #dc3545, #c82333)';
            updateConnectionStatus();

            // التحقق من الحالة مرة أخرى بعد ثانيتين للتأكد
            setTimeout(() => {
                checkConnectionStatus();
            }, 2000);

        } else if (result.cancelled) {
            // تم إلغاء الاتصال لصالح اتصال جديد
            isConnecting = false;
            return;
        } else {
            showToast(`❌ خطأ في الاتصال مع ${username}: ${result.message}`, 'error');
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            isConnecting = false;

            // 🔥 مسح حالة الاتصال
            saveConnectionState(false);
        }

    } catch (error) {
        console.error('خطأ في الاتصال:', error);
        showToast(`❌ خطأ في إنشاء الاتصال مع ${username}: ${error.message || 'خطأ غير محدد'}`, 'error');
        connectBtn.textContent = 'الاتصال بالتيك توك';
        connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
        isConnecting = false;
    } finally {
        connectBtn.disabled = false;
    }
}

async function stopConnection() {
    try {
        connectBtn.disabled = true;
        connectBtn.textContent = 'جاري قطع الاتصال...';

        const response = await fetch('/api/disconnect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id
            })
        });

        const result = await response.json();

        // 🔐 معالجة طلب الاشتراك
        if (response.status === 403 || response.status === 402) {
            if (handleApiError(result, result)) {
                connectBtn.disabled = false;
                connectBtn.textContent = 'قطع الاتصال';
                return;
            }
        }

        if (result.success) {
            // 🛑 إيقاف إعادة الاتصال التلقائي (قطع يدوي)
            stopAutoReconnect();
            autoReconnectEnabled = false; // تعطيل مؤقت
            wasConnectedBeforeDisconnect = false; // إلغاء تتبع الاتصال السابق

            // 🔥 مسح حالة الاتصال من localStorage
            saveConnectionState(false);

            // مسح حالة الاتصال المحفوظة (لكن نحتفظ باليوزر نيم)
            const currentSavedUsername = savedUsername || getUsernameFromLocalStorage();
            savedUsername = currentSavedUsername; // الحفاظ على اليوزر نيم
            lastInputValue = '';

            showToast('✅ تم قطع الاتصال', 'success');

            // تحديث الواجهة فوراً
            isConnected = false;
            isConnecting = false;
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            updateConnectionStatus();
            resetStats();

            // إعادة تفعيل إعادة الاتصال بعد 5 ثواني (في حال أراد الاتصال مرة أخرى)
            setTimeout(() => {
                autoReconnectEnabled = true;
            }, 5000);


        } else {
            showToast(`خطأ: ${result.message}`);
        }

    } catch (error) {
        console.error('خطأ في قطع الاتصال:', error);
        showToast('حدث خطأ في قطع الاتصال');
    } finally {
        connectBtn.disabled = false;
    }
}

function updateConnectionStatus() {
    if (connectionStatus) {
        if (isConnected) {
            connectionStatus.className = 'status-indicator online';
            const statusText = connectionStatus.querySelector('.status-text');
            if (statusText) statusText.textContent = 'متصل';

            // إظهار اسم المستخدم المتصل - يعمل مع التصميم الجديد والقديم
            if (savedUsername) {
                if (connectedUsernameSpan) {
                    connectedUsernameSpan.textContent = savedUsername;
                }
                if (currentUsernameDiv) {
                    currentUsernameDiv.style.display = 'block';
                }
                // الإبقاء على حقل إدخال اليوزر مرئياً دائماً مع عرض اليوزر المحفوظ
                if (usernameInput) {
                    usernameInput.style.display = 'block';
                    usernameInput.value = savedUsername; // عرض اسم المستخدم المتصل
                }
            }
        } else {
            connectionStatus.className = 'status-indicator offline';
            const statusText = connectionStatus.querySelector('.status-text');
            if (statusText) statusText.textContent = 'غير متصل';

            // إظهار حقل الإدخال مع اليوزر المحفوظ
            if (currentUsernameDiv) {
                currentUsernameDiv.style.display = 'none';
            }
            if (usernameInput) {
                usernameInput.style.display = 'block';
                // عرض اليوزر المحفوظ حتى لو غير متصل
                if (savedUsername && !usernameInput.value) {
                    usernameInput.value = savedUsername;
                }
            }
        }
    }
}

async function checkConnectionStatus() {
    // 🚫 GUARD: منع أي API calls للجلسات الميتة
    if (SESSION_KICKED) {
        return;
    }

    try {
        const response = await fetch(`/api/status/${currentUser.id}`);
        const status = await response.json();

        isConnected = status.connected;

        // 🆕 تحميل اسم المستخدم من localStorage أولاً، ثم من السيرفر
        const localUsername = getUsernameFromLocalStorage();
        const serverUsername = status.savedUsername;

        // استخدام localStorage كأولوية (أحدث وأضمن)
        const usernameToUse = localUsername || serverUsername;

        // ملء حقل اسم المستخدم بالقيمة المحفوظة دائماً
        if (usernameToUse && usernameInput) {
            usernameInput.value = usernameToUse;
            savedUsername = usernameToUse;
        }

        // محاولة الاتصال التلقائي مرة واحدة فقط عند فتح الصفحة
        if (!isConnected && usernameToUse && !autoConnectAttempted) {
            autoConnectAttempted = true;
            showToast(`🔌 محاولة الاتصال التلقائي بـ: ${usernameToUse}`, 'info');

            // تحديث واجهة المستخدم فوراً لإظهار حالة "جاري الاتصال"
            if (connectBtn) {
                connectBtn.textContent = 'جاري الاتصال...';
                connectBtn.disabled = true;
            }

            await startConnection(usernameToUse, false);
            return; // الخروج هنا لأن startConnection سيتعامل مع تحديث الواجهة
        }

        if (status.connected && status.username) {
            savedUsername = status.username;
            saveConnectionState(status.username, true);
            saveUsernameToLocalStorage(status.username); // تزامن مع localStorage
            connectBtn.textContent = 'قطع الاتصال';
            connectBtn.style.background = 'linear-gradient(45deg, #dc3545, #c82333)';
            connectBtn.disabled = false;
        } else {
            // إذا لم يكن متصلاً على السيرفر ولكن يوجد حالة محفوظة، امسحها
            if (savedUsername && !status.savedUsername) {
                clearSavedState();
            }
            connectBtn.textContent = 'الاتصال بالتيك توك';
            connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            connectBtn.disabled = false;
        }

        updateConnectionStatus();

        if (status.stats) {
            currentStats = status.stats;
            updateStatsDisplay();
        }

    } catch (error) {
        console.error('خطأ في التحقق من حالة الاتصال:', error);
        // في حالة الخطأ، تأكد من أن الزر ليس معطلاً
        if (connectBtn) {
            connectBtn.disabled = false;
            if (!isConnected) {
                connectBtn.textContent = 'الاتصال بالتيك توك';
                connectBtn.style.background = 'linear-gradient(45deg, #28a745, #20c997)';
            }
        }
    }
}

function updateStatsDisplay() {
    if (viewersCount) viewersCount.textContent = currentStats.viewers || 0;
    if (commentsCount) commentsCount.textContent = currentStats.comments || 0;
    if (giftsCount) giftsCount.textContent = currentStats.gifts || 0;
}

function resetStats() {
    currentStats = {
        viewers: 0,
        likes: 0,
        comments: 0,
        gifts: 0
    };
    updateStatsDisplay();

    // مسح التعليقات (محمي إذا كان العنصر موجود)
    if (commentsList) {
        commentsList.innerHTML = '<p class="no-comments">لا توجد تعليقات بعد</p>';
    }

    // تحديث واجهة المستخدم للحالة غير المتصلة
    updateConnectionStatus();
}

function addComment(author, text) {
    // إذا لم يكن عنصر التعليقات موجوداً (تمت إزالته من الواجهة)، نتوقف هنا
    if (!commentsList) return;

    // إزالة رسالة "لا توجد تعليقات" إذا كانت موجودة
    const noComments = commentsList.querySelector('.no-comments');
    if (noComments) {
        noComments.remove();
    }

    const commentDiv = document.createElement('div');
    commentDiv.className = 'comment-item';

    const now = new Date();
    const timeString = now.toLocaleTimeString('ar-SA', {
        hour: '2-digit',
        minute: '2-digit'
    });

    commentDiv.innerHTML = `
        <div class="comment-author">${author}</div>
        <div class="comment-text">${text}</div>
        <div class="comment-time">${timeString}</div>
    `;

    // إضافة التعليق في أعلى القائمة
    commentsList.insertBefore(commentDiv, commentsList.firstChild);

    // الحفاظ على آخر 20 تعليق فقط
    const comments = commentsList.querySelectorAll('.comment-item');
    if (comments.length > 20) {
        comments[comments.length - 1].remove();
    }
}

function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    if (!element) {
        showToast('العنصر المطلوب للنسخ غير موجود');
        return;
    }
    const text = element.textContent || '';

    navigator.clipboard.writeText(text).then(() => {
        showToast('تم نسخ النص بنجاح!');
    }).catch((error) => {
        console.error('خطأ في النسخ:', error);
        showToast('فشل في نسخ النص');
    });
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('messageToast');

    if (!toast) {
        console.error('❌ Toast element not found!');
        return;
    }

    toast.textContent = message;
    toast.classList.remove('show', 'error', 'success', 'warning', 'info');
    toast.classList.add('show', type);

    setTimeout(() => {
        toast.classList.remove('show', type);
    }, 3000);
}

// وظيفة تصفير اللايكات
async function resetAllLikes() {
    if (!currentUser) {
        showToast('يجب تسجيل الدخول أولاً');
        return;
    }

    try {
        // إرسال طلب لتصفير اللايكات على السيرفر
        const response = await fetch('/api/reset-likes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id
            })
        });

        const result = await response.json();

        // 🔐 معالجة طلب الاشتراك
        if (response.status === 403 || response.status === 402) {
            if (handleApiError(result, result)) {
                return;
            }
        }

        if (response.ok) {
            showToast('تم تصفير جميع اللايكات بنجاح ✓');
        } else {
            showToast('فشل في تصفير اللايكات: ' + (result.error || 'خطأ غير معروف'));
        }
    } catch (error) {
        console.error('خطأ في تصفير اللايكات:', error);
        showToast('حدث خطأ أثناء تصفير اللايكات');
    }
}

// تصفير الداعمين فقط
async function resetAllSupporters() {
    if (!currentUser) {
        showToast('يجب تسجيل الدخول أولاً');
        return;
    }

    try {
        // إرسال طلب لتصفير الداعمين على السيرفر
        const response = await fetch('/api/reset-supporters', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id
            })
        });

        const result = await response.json();

        // 🔐 معالجة طلب الاشتراك
        if (response.status === 403 || response.status === 402) {
            if (handleApiError(result, result)) {
                return;
            }
        }

        if (response.ok) {
            showToast('تم تصفير جميع الداعمين بنجاح ✓');
        } else {
            showToast('فشل في تصفير الداعمين: ' + (result.error || 'خطأ غير معروف'));
        }
    } catch (error) {
        console.error('خطأ في تصفير الداعمين:', error);
        showToast('حدث خطأ أثناء تصفير الداعمين');
    }
}

// مراقبة تغييرات حالة المصادقة (سيتم تفعيلها بعد تهيئة Supabase)
function setupAuthStateListener() {
    if (!supabase) {
        return;
    }

    supabase.auth.onAuthStateChange(async (event, session) => {

        // التحقق من صحة معرف المستخدم في الجلسة
        if (session && session.user) {
            if (!isValidUUID(session.user.id)) {
                console.error('❌ معرف مستخدم غير صالح في الجلسة:', session.user.id);
                showToast('خطأ في المصادقة. سيتم تسجيل الخروج.', 'error');
                supabase.auth.signOut();
                return;
            }
        }

        if (event === 'SIGNED_OUT') {
            clearSavedState();
            window.location.href = '/';
        } else if (event === 'TOKEN_REFRESHED') {} else if (event === 'SIGNED_IN' || (event === 'INITIAL_SESSION' && session)) {

            // 🔵 معالجة Google OAuth callback أو Email Login أو استعادة الجلسة
            if (session && session.user) {

                // 🔑 تحديث currentUser global variable
                currentUser = session.user;

                // حفظ معلومات المستخدم في الخلفية (بدون انتظار/تعليق)
                saveUserProfile(session.user).catch(err => {
                    console.error('❌ خطأ غير متوقع في حفظ ملف المستخدم:', err);
                });

                // تحديث واجهة المستخدم فوراً
                updateSetupUIForLoggedInUser(session.user);
                updateWidgetUrls();

                // 🔄 إعادة محاولة Socket join if needed
                if (socket && socket.connected && currentUser) {
                    emitJoinEvent();
                }
            }
        }
    });
}

// إضافة مستمع للأخطاء العامة
window.addEventListener('error', (event) => {
    if (event.error && event.error.message && event.error.message.includes('supabase')) {
        console.error('خطأ Supabase:', event.error);
        showToast('حدث خطأ في الاتصال بقاعدة البيانات');
    }
});

// إضافة مستمع لأخطاء الشبكة
window.addEventListener('offline', () => {
    showToast('انقطع الاتصال بالإنترنت. بعض الميزات قد لا تعمل بشكل صحيح');
    connectionStatus.textContent = 'غير متصل (بدون إنترنت)';
    connectionStatus.className = 'status-indicator offline';
});

window.addEventListener('online', () => {
    showToast('تم استعادة الاتصال بالإنترنت');
    // إعادة فحص حالة الاتصال
    setTimeout(checkConnectionStatus, 1000);
});

// وظائف حفظ واستعادة الحالة
function saveConnectionState(username, connected) {
    const state = {
        username: username,
        connected: connected,
        userId: currentUser ? .id,
        timestamp: Date.now()
    };

    localStorage.setItem('tiktok_connection_state', JSON.stringify(state));
}

function loadSavedState() {
    try {
        const savedState = localStorage.getItem('tiktok_connection_state');
        if (!savedState) return;

        const state = JSON.parse(savedState);

        // التحقق من أن الحالة ليست قديمة جداً (أكثر من 24 ساعة)
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000; // 24 ساعة

        if (now - state.timestamp > maxAge) {
            localStorage.removeItem('tiktok_connection_state');
            return;
        }

        if (state.username) {
            savedUsername = state.username;
            // لا نملأ الحقل هنا، سنتركه لـ checkConnectionStatus
            // التي ستجلب القيمة من قاعدة البيانات
        }

    } catch (error) {
        console.error('خطأ في تحميل الحالة المحفوظة:', error);
        localStorage.removeItem('tiktok_connection_state');
    }
}

function clearSavedState() {
    localStorage.removeItem('tiktok_connection_state');
    savedUsername = null;
}

// وظائف إضافية لتحسين تجربة المتابعة
function playNotificationSound() {
    // WebAudio oscillator removed — no sound will be produced here.
    // Keep function as no-op to avoid changing call sites.
    return;
}




// ابني روابط 1..5 من نفس التوكن
function getOverlayUrls(widgetToken) {
    const base = location.origin; // يعمل محلياً وعلى الدومين الحقيقي
    return [1, 2, 3, 4, 5].map(n => ({
        screen: n,
        url: `${base}/overlay?token=${encodeURIComponent(widgetToken)}&screen=${n}`
    }));
}

function renderOverlaySettings(widgetToken, userId) {
    const container = document.getElementById('overlay-list');
    if (!container) {
        return;
    }

    container.innerHTML = '';

    const rows = getOverlayUrls(widgetToken).map(({
        screen,
        url
    }) => {
        return `
      <div class="overlay-row" data-screen="${screen}" style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
        <strong style="width:72px;">Screen ${screen}</strong>
        <input type="text" class="overlay-url" value="${url}" readonly
               style="flex:1;padding:6px 8px;border-radius:8px;border:1px solid #444;background:#111;color:#eee;">
        <button class="copy-btn" data-url="${url}" style="padding:6px 10px;border-radius:8px;">نسخ</button>
        <span class="status-dot" style="width:10px;height:10px;border-radius:50%;background:#555;display:inline-block;"></span>
        <span class="status-text" style="min-width:60px;">Offline</span>
      </div>`;
    }).join('');

    container.insertAdjacentHTML('beforeend', rows);

    // أزرار النسخ
    container.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            navigator.clipboard.writeText(btn.dataset.url);
            btn.textContent = '✔ تم النسخ';
            setTimeout(() => (btn.textContent = 'نسخ'), 1200);
        });
    });

    // ابدأ التحديث الدوري للحالة
    startOverlayStatusPolling(userId);
}

let overlayStatusTimer = null;

function startOverlayStatusPolling(userId) {
    const container = document.getElementById('overlay-list');
    if (!container) {
        return;
    }

    async function tick() {
        try {
            const res = await fetch(`/api/overlay/status/${encodeURIComponent(userId)}`);
            const data = await res.json(); // { screens: [bool,bool,bool,bool,bool] }
            const container = document.getElementById('overlay-list');
            if (!container) return;

            data.screens.forEach((on, i) => {
                const row = container.querySelector(`.overlay-row[data-screen="${i + 1}"]`);
                if (!row) return;
                const dot = row.querySelector('.status-dot');
                const text = row.querySelector('.status-text');
                if (on) {
                    dot.style.background = '#19c37d';
                    text.textContent = 'Ready';
                } else {
                    dot.style.background = '#555';
                    text.textContent = 'Offline';
                }
            });
        } catch (e) {
            console.error('overlay status error', e);
        }
    }
    clearInterval(overlayStatusTimer);
    tick();
    overlayStatusTimer = setInterval(tick, 4000);
}

function showFollowAnimation() {
    // إنشاء عنصر رسوم متحركة للمتابعة
    const followAnimation = document.createElement('div');
    followAnimation.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(45deg, #ff6b6b, #ee5a52);
        color: white;
        padding: 15px 25px;
        border-radius: 25px;
        font-size: 18px;
        font-weight: bold;
        z-index: 10000;
        box-shadow: 0 4px 15px rgba(255, 107, 107, 0.4);
        transform: translateX(100%);
        transition: all 0.5s ease-out;
        display: flex;
        align-items: center;
        gap: 10px;
    `;

    followAnimation.innerHTML = `
        <span style="font-size: 24px;">❤️</span>
        <span>متابع جديد!</span>
    `;

    document.body.appendChild(followAnimation);

    // إظهار الرسوم المتحركة
    setTimeout(() => {
        followAnimation.style.transform = 'translateX(0)';
    }, 100);

    // إخفاء الرسوم المتحركة بعد 3 ثواني
    setTimeout(() => {
        followAnimation.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(followAnimation);
        }, 500);
    }, 3000);
}



// ====== Popup Management ======
function initializePopup() {
    const addActionBtn = document.getElementById('addActionBtn');
    const actionPopup = document.getElementById('actionPopup');
    const closePopupBtn = document.getElementById('closePopupBtn');
    const cancelActionBtn = document.getElementById('cancelActionBtn');

    // 🆕 تهيئة أولية: تجهيز النموذج للاستخدام
    resetActionForm();
    setupFileDeleteListeners();

    // فتح النافذة المنبثقة
    if (addActionBtn) {
        addActionBtn.addEventListener('click', async () => {
            openActionPopup();
        });
    }

    // إغلاق النافذة المنبثقة
    [closePopupBtn, cancelActionBtn].forEach(btn => {
        if (btn) {
            btn.addEventListener('click', () => {
                closeActionPopup();
            });
        }
    });

    // إغلاق النافذة عند النقر على الخلفية - معطل الآن
    // if (actionPopup) {
    //     actionPopup.addEventListener('click', (e) => {
    //         if (e.target === actionPopup) {
    //             closeActionPopup();
    //         }
    //     });
    // }

    // إغلاق النافذة بالضغط على ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && actionPopup.style.display === 'flex') {
            closeActionPopup();
        }
    });

    // تهيئة التحكم في نوع الحدث (checkboxes)
    initializeTriggerTypeControls();
}

// ====== Trigger Type Controls ======
// متغير لتتبع ما إذا تم تهيئة event listeners
let triggerListenersInitialized = false;

function initializeTriggerTypeControls() {
    // إذا تم التهيئة من قبل، لا نعيد التهيئة
    if (triggerListenersInitialized) {
        return;
    }

    const triggerCheckboxes = document.querySelectorAll('input[name="triggerType"]');

    triggerCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            handleTriggerTypeChange(this);
        });
    });

    // وضع علامة أن التهيئة تمت
    triggerListenersInitialized = true;;

    // إضافة event listener لخيار "من شخص معين" في التعليقات المعينة
    const specificCommentUserCheckbox = document.getElementById('specificCommentUser');
    if (specificCommentUserCheckbox) {
        specificCommentUserCheckbox.addEventListener('change', function() {
            const userOptions = document.getElementById('specificCommentUserOptions');
            if (userOptions) {
                userOptions.style.display = this.checked ? 'block' : 'none';
            }
        });
    }
}

function handleTriggerTypeChange(selectedCheckbox) {
    const allCheckboxes = document.querySelectorAll('input[name="triggerType"]');
    const triggerType = selectedCheckbox.value;

    // إلغاء تحديد جميع الـ checkboxes الأخرى
    if (selectedCheckbox.checked) {
        allCheckboxes.forEach(cb => {
            if (cb !== selectedCheckbox) {
                cb.checked = false;
                // إخفاء الخيارات الفرعية للـ checkboxes الأخرى
                const subOptions = document.getElementById(getSubOptionsId(cb.value));
                if (subOptions) {
                    subOptions.style.display = 'none';
                }
                // إزالة class active
                const parentOption = cb.closest('.trigger-option');
                if (parentOption) {
                    parentOption.classList.remove('active');
                }
            }
        });

        // إظهار الخيارات الفرعية للـ checkbox المحدد
        const subOptions = document.getElementById(getSubOptionsId(triggerType));
        if (subOptions) {
            subOptions.style.display = 'block';
        }

        // إضافة class active
        const parentOption = selectedCheckbox.closest('.trigger-option');
        if (parentOption) {
            parentOption.classList.add('active');
        }
    } else {
        // إذا تم إلغاء التحديد، إخفاء الخيارات الفرعية
        const subOptions = document.getElementById(getSubOptionsId(triggerType));
        if (subOptions) {
            subOptions.style.display = 'none';
        }

        // إزالة class active
        const parentOption = selectedCheckbox.closest('.trigger-option');
        if (parentOption) {
            parentOption.classList.remove('active');
        }
    }
}

function getSubOptionsId(triggerType) {
    const mapping = {
        'specific_gift': 'specificGiftOptions',
        'min_diamonds': 'minDiamondsOptions',
        'min_likes': 'minLikesOptions',
        'follow': 'followOptions',
        'join': 'joinOptions',
        'specific_user_join': 'specificUserJoinOptions',
        'specific_comment': 'specificCommentOptions'
    };
    return mapping[triggerType] || '';
}


function openActionPopup() {
    const actionPopup = document.getElementById('actionPopup');
    if (actionPopup) {
        // فقط اعرض النافذة - جاهزة فوراً
        actionPopup.style.display = 'flex';

        // منع scroll في الخلفية
        document.body.style.overflow = 'hidden';
    }
}

async function closeActionPopup(actionSaved = false) {
    const actionPopup = document.getElementById('actionPopup');
    if (actionPopup) {
        // إخفاء النافذة
        actionPopup.style.display = 'none';

        // استعادة scroll في الخلفية
        document.body.style.overflow = 'auto';

        // 🗑️ حذف الملفات المرفوعة فقط إذا لم يتم حفظ الإجراء
        if (!actionSaved) {
            await cleanupUnusedUploads();
        }

        // ✅ الآن نعمل reset كامل للنموذج (يجهّز النافذة للفتح القادم)
        resetActionForm();
    }
}

// دالة لحذف الملفات المرفوعة التي لم يتم استخدامها
async function cleanupUnusedUploads() {
    const videoInput = document.getElementById('actVideoFile');
    const soundInput = document.getElementById('actSoundFile');

    // حذف الفيديو المرفوع إذا لم يتم حفظه في إجراء
    if (videoInput ? .dataset.uploadedPath && !window.editingActionId) {
        try {
            await supabase.storage.from('videos').remove([videoInput.dataset.uploadedPath]);
        } catch (err) {
            console.error('خطأ في حذف الفيديو:', err);
        }
    }

    // حذف الصوت المرفوع إذا لم يتم حفظه في إجراء
    if (soundInput ? .dataset.uploadedPath && !window.editingActionId) {
        try {
            await supabase.storage.from('sounds').remove([soundInput.dataset.uploadedPath]);
        } catch (err) {
            console.error('خطأ في حذف الصوت:', err);
        }
    }
}

function resetActionForm() {

    // إعادة تعيين جميع الحقول
    document.getElementById('actName').value = '';
    document.getElementById('actMinValue').value = '100';
    document.getElementById('actMinLikes').value = '50';
    document.getElementById('actDurationSec').value = '10';
    document.getElementById('actTargetScreen').selectedIndex = 0;
    document.getElementById('actPlaySound').checked = false;
    document.getElementById('actPlayVideo').checked = false;
    document.getElementById('actShowGiftImageSpecific').checked = false;
    document.getElementById('actShowGiftImageDiamonds').checked = false;

    // 🔊 إعادة تعيين مستوى الصوت
    const volumeSlider = document.getElementById('actVolume');
    const volumeValue = document.getElementById('volumeValue');
    if (volumeSlider) {
        volumeSlider.value = 100;
        volumeSlider.style.setProperty('--slider-value', '100%');
    }
    if (volumeValue) {
        volumeValue.textContent = '100%';
    }

    // 🆕 إعادة تعيين الرسالة
    document.getElementById('actShowThankYou').checked = false;
    document.getElementById('actThankYouMessage').value = '';
    document.getElementById('thankYouMessageOptions').style.display = 'none';

    // 🌍 إعادة تعيين فلتر الدول
    const countryFilterCheckbox = document.getElementById('actCountryFilter');
    const countrySelect = document.getElementById('actCountrySelect');
    const selectedCountriesDisplay = document.getElementById('selectedCountriesDisplay');

    if (countryFilterCheckbox) {
        countryFilterCheckbox.checked = false;
        document.getElementById('countryFilterOptions').style.display = 'none';
    }

    if (countrySelect) {
        Array.from(countrySelect.options).forEach(option => {
            option.selected = false;
        });
    }

    if (selectedCountriesDisplay) {
        selectedCountriesDisplay.innerHTML = '<span class="placeholder-text">لم يتم اختيار دول (الإجراء يعمل لجميع الدول)</span>';
    }

    // إعادة تعيين checkboxes نوع الحدث
    const triggerCheckboxes = document.querySelectorAll('input[name="triggerType"]');
    triggerCheckboxes.forEach(cb => {
        cb.checked = false;
        const subOptions = document.getElementById(getSubOptionsId(cb.value));
        if (subOptions) {
            subOptions.style.display = 'none';
        }
        const parentOption = cb.closest('.trigger-option');
        if (parentOption) {
            parentOption.classList.remove('active');
        }
    });

    // 👤 إعادة تعيين حقل اسم المستخدم الخاص بانضمام شخص معين
    const specificUsernameInput = document.getElementById('specificUsername');
    if (specificUsernameInput) {
        specificUsernameInput.value = '';
    }

    // 🔢 إعادة تعيين حقل عدد مرات التنفيذ
    const executionLimitInput = document.getElementById('specificUserExecutionLimit');
    if (executionLimitInput) {
        executionLimitInput.value = '1';
    }

    // إخفاء أقسام رفع الملفات
    document.getElementById('soundUploadWrapper').style.display = 'none';
    document.getElementById('videoUploadWrapper').style.display = 'none';

    // إعادة تعيين عرض الصوت المحدد
    const selectedSoundDisplay = document.getElementById('selectedSoundDisplay');
    if (selectedSoundDisplay) {
        selectedSoundDisplay.style.display = 'none';
    }

    // إعادة تعيين متغير الصوت من المكتبة
    selectedLibrarySound = null;

    // إخفاء عرض الفيديو المخزن
    const currentVideoFile = document.getElementById('currentVideoFile');
    if (currentVideoFile) {
        currentVideoFile.style.display = 'none';
    }

    // إخفاء عرض الفيديو المحدد الجديد
    const selectedVideoDisplay = document.getElementById('selectedVideoDisplay');
    if (selectedVideoDisplay) {
        selectedVideoDisplay.style.display = 'none';
    }

    // 🆕 إعادة تعيين checkboxes صورة الهدية الجديدة
    document.getElementById('actShowGiftImageSpecific').checked = false;
    document.getElementById('actShowGiftImageDiamonds').checked = false;

    // مسح الملفات المرفوعة
    const soundFileInput = document.getElementById('actSoundFile');
    const videoFileInput = document.getElementById('actVideoFile');

    if (soundFileInput) {
        soundFileInput.value = '';
        delete soundFileInput.dataset.uploadedUrl;
        delete soundFileInput.dataset.uploadedPath;
    }

    if (videoFileInput) {
        videoFileInput.value = '';
        delete videoFileInput.dataset.uploadedUrl;
        delete videoFileInput.dataset.uploadedPath;
    }

    // إخفاء شريط التقدم وتنظيف النصوص
    const videoProgressContainer = document.getElementById('videoUploadProgress');
    const soundProgressContainer = document.getElementById('soundUploadProgress');

    if (videoProgressContainer) {
        videoProgressContainer.style.display = 'none';
        const videoProgressBar = document.getElementById('videoProgressBar');
        const videoProgressText = document.getElementById('videoProgressPercent');
        if (videoProgressBar) videoProgressBar.style.width = '0%';
        if (videoProgressText) videoProgressText.textContent = '0%';
    }

    if (soundProgressContainer) {
        soundProgressContainer.style.display = 'none';
        const soundProgressBar = document.getElementById('soundProgressBar');
        const soundProgressText = document.getElementById('soundProgressPercent');
        if (soundProgressBar) soundProgressBar.style.width = '0%';
        if (soundProgressText) soundProgressText.textContent = '0%';
    }

    // إعادة تعيين اختيار الهدية
    const giftSelector = document.getElementById('actGiftSelect');
    if (giftSelector) {
        giftSelector.selectedIndex = 0;
        const selectedGiftDiv = document.getElementById('selectedGift');
        if (selectedGiftDiv) {
            selectedGiftDiv.innerHTML = '<span>جميع الهدايا (حسب القيمة الدنيا)</span>';
        }

        const minValueInput = document.getElementById('actMinValue');
        minValueInput.disabled = false;
        minValueInput.style.opacity = '1';
        minValueInput.title = 'القيمة الدنيا للألماسات';

        // إخفاء معاينة الهدية
        document.getElementById('giftPreview').style.display = 'none';
    }

    // إعادة تعيين وضع التعديل
    delete window.editingActionId;

    // إعادة تعيين الإعدادات المتقدمة
    window.advancedDisplaySettings = null;

    // تحديث عنوان النافذة وزر الإنشاء
    const popupTitle = document.getElementById('popupTitle');
    const createBtn = document.getElementById('createActionBtn');
    if (popupTitle) popupTitle.textContent = 'إنشاء إجراء جديد 🎁';
    if (createBtn) createBtn.textContent = 'Create Action';
}

async function openEditActionPopup(actionItem, userId) {
    try {

        if (!actionItem) {
            throw new Error('actionItem is null or undefined');
        }

        if (!actionItem.dataset) {
            throw new Error('actionItem.dataset is null or undefined');
        }

        // تعيين وضع التعديل
        window.editingActionId = actionItem.dataset.id;

        // فتح النافذة المنبثقة أولاً
        openActionPopup();

        // تحديث عنوان النافذة وزر الحفظ
        const popupTitle = document.getElementById('popupTitle');
        const createBtn = document.getElementById('createActionBtn');
        if (popupTitle) popupTitle.textContent = 'تعديل الإجراء ✏️';
        if (createBtn) createBtn.textContent = 'حفظ التعديلات';

        // تحميل البيانات الحالية
        document.getElementById('actName').value = actionItem.dataset.name || '';
        document.getElementById('actMinValue').value = actionItem.dataset.minValue || '1';
        document.getElementById('actDurationSec').value = actionItem.dataset.duration || '10';

        // تحديد الشاشة المستهدفة
        const targetScreenSelect = document.getElementById('actTargetScreen');
        targetScreenSelect.value = actionItem.dataset.targetScreen || '1';

        // تحديد الصوت والفيديو وإظهار صورة الهدية
        const playSound = actionItem.dataset.playSound === 'true';
        const playVideo = actionItem.dataset.playVideo === 'true';
        const showGiftImage = actionItem.dataset.showGiftImage === 'true';
        const triggerType = actionItem.dataset.triggerType || 'specific_gift';

        const soundCheckbox = document.getElementById('actPlaySound');
        const videoCheckbox = document.getElementById('actPlayVideo');

        soundCheckbox.checked = playSound;
        videoCheckbox.checked = playVideo;

        // 🆕 تحميل الرسالة
        const message = actionItem.dataset.message || '';
        const showThankYou = message.trim() !== '';

        const thankYouCheckbox = document.getElementById('actShowThankYou');
        const thankYouTextarea = document.getElementById('actThankYouMessage');

        if (thankYouCheckbox) {
            thankYouCheckbox.checked = showThankYou;
            document.getElementById('thankYouMessageOptions').style.display = showThankYou ? 'block' : 'none';
        }

        if (thankYouTextarea && showThankYou) {
            thankYouTextarea.value = message;
        }

        // ✅ تحديد checkbox صورة الهدية حسب نوع التفعيل
        if (triggerType === 'specific_gift') {
            const checkbox = document.getElementById('actShowGiftImageSpecific');
            if (checkbox) checkbox.checked = showGiftImage;
        } else if (triggerType === 'min_diamonds') {
            const checkbox = document.getElementById('actShowGiftImageDiamonds');
            if (checkbox) checkbox.checked = showGiftImage;
        }

        // إظهار أقسام رفع الملفات إذا كانت مفعلة
        document.getElementById('soundUploadWrapper').style.display = playSound ? 'block' : 'none';
        document.getElementById('videoUploadWrapper').style.display = playVideo ? 'block' : 'none';

        // عرض الملفات المخزنة إذا كانت موجودة
        const soundFileName = actionItem.dataset.soundFileName;
        const videoFileName = actionItem.dataset.videoFileName;

        // عرض الصوت المخزن (إما من المكتبة أو ملف مرفوع)
        const soundKey = actionItem.dataset.soundKey;
        if (soundFileName && soundFileName.trim() !== '') {
            // التحقق إذا كان الصوت من المكتبة
            if (soundKey && soundKey.startsWith('library-')) {
                // صوت من المكتبة
                const libraryId = soundKey.replace('library-', '');
                const soundUrl = actionItem.dataset.soundUrl;
                selectedLibrarySound = {
                    id: libraryId,
                    name: soundFileName,
                    url: soundUrl
                };
                showSelectedSound(soundFileName, 'مكتبة الأصوات');
            } else {
                // ملف مرفوع محلياً
                showSelectedSound(soundFileName, 'ملف محلي');
            }
        } else {}

        // عرض ملف الفيديو المخزن
        const currentVideoFile = document.getElementById('currentVideoFile');
        const currentVideoFileName = document.getElementById('currentVideoFileName');

        if (videoFileName && videoFileName.trim() !== '') {
            currentVideoFileName.textContent = videoFileName;
            currentVideoFile.style.display = 'block';
        } else {
            currentVideoFile.style.display = 'none';
        }

        // تطبيق الـ trigger لضمان عمل event listeners
        soundCheckbox.dispatchEvent(new Event('change'));
        videoCheckbox.dispatchEvent(new Event('change'));

        // استخدام triggerType المعرّف مسبقاً (السطر 2173)

        // إعادة تعيين جميع checkboxes الأحداث أولاً
        const triggerCheckboxes = document.querySelectorAll('input[name="triggerType"]');
        triggerCheckboxes.forEach(cb => {
            cb.checked = false;
            const subOptions = document.getElementById(getSubOptionsId(cb.value));
            if (subOptions) {
                subOptions.style.display = 'none';
            }
            const parentOption = cb.closest('.trigger-option');
            if (parentOption) {
                parentOption.classList.remove('active');
            }
        });

        // تفعيل نوع الحدث المناسب
        const triggerCheckbox = document.querySelector(`input[name="triggerType"][value="${triggerType}"]`);
        if (triggerCheckbox) {
            triggerCheckbox.checked = true;
            const subOptions = document.getElementById(getSubOptionsId(triggerType));
            if (subOptions) {
                subOptions.style.display = 'block';
            }
            const parentOption = triggerCheckbox.closest('.trigger-option');
            if (parentOption) {
                parentOption.classList.add('active');
            }
        }

        // تحميل البيانات حسب نوع الحدث
        if (triggerType === 'specific_gift') {
            // تحديد الهدية إذا كانت محددة
            const giftName = actionItem.dataset.giftName;

            // التأكد من تحميل قائمة الهدايا أولاً
            const giftSelector = document.getElementById('actGiftSelect');
            if (giftSelector.options.length <= 1) {
                await loadTikTokGifts(); // انتظار تحميل الهدايا
            }

            const selectedGiftDiv = document.getElementById('selectedGift');

            if (giftName && giftName.trim() !== '') {
                // البحث عن الهدية في القائمة وتحديدها
                let giftFound = false;
                const giftImage = actionItem.dataset.giftImage;
                const giftDiamonds = actionItem.dataset.giftDiamonds;

                for (let i = 0; i < giftSelector.options.length; i++) {
                    if (giftSelector.options[i].value === giftName) {
                        giftSelector.selectedIndex = i;
                        giftFound = true;

                        // تحديث واجهة القائمة المخصصة لإظهار الهدية المحددة مع صورتها
                        if (giftImage) {
                            selectedGiftDiv.innerHTML = `
                                <img src="${giftImage}" alt="${giftName}" style="width: 28px; height: 28px; border-radius: 4px; margin-left: 8px;" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                <div style="width: 28px; height: 28px; background: linear-gradient(45deg, #ff6b35, #f7931e); border-radius: 4px; display: none; align-items: center; justify-content: center; font-size: 14px; color: white; border: 1px solid #e1e5e9;">🎁</div>
                                <div class="gift-info">
                                    <span class="gift-name">${giftName}</span>
                                    <span class="gift-diamonds">${giftDiamonds || '0'} 💎</span>
                                </div>
                            `;
                        } else {
                            selectedGiftDiv.innerHTML = `<span>🎁 ${giftName}</span>`;
                        }
                        break;
                    }
                }

                if (!giftFound) {
                    // إعادة تعيين إلى "جميع الهدايا" إذا لم توجد الهدية
                    giftSelector.selectedIndex = 0;
                    selectedGiftDiv.innerHTML = '<span>اختر هدية</span>';
                }

                // إظهار معاينة الهدية إذا كانت متوفرة
                if (giftFound) {
                    showGiftPreview();
                }
            }
        } else if (triggerType === 'min_diamonds') {
            // تحميل قيمة الألماسات الدنيا
            const minValue = actionItem.dataset.minValue || '100';
            document.getElementById('actMinValue').value = minValue;
        } else if (triggerType === 'follow') {
            // المتابعة - لا توجد معاملات إضافية
        } else if (triggerType === 'join') {
            // الانضمام - لا توجد معاملات إضافية
        } else if (triggerType === 'specific_user_join') {
            // انضمام شخص معين - تحميل اليوزرنيم وعدد مرات التنفيذ
            const specificUsername = actionItem.dataset.specificUsername || '';
            const executionLimit = actionItem.dataset.executionLimit || '1';

            document.getElementById('specificUsername').value = specificUsername;
            document.getElementById('specificUserExecutionLimit').value = executionLimit;
        } else if (triggerType === 'specific_comment') {
            // تعليق معين - تحميل نص التعليق واسم المستخدم
            const commentText = actionItem.dataset.commentText || '';
            const specificCommentUsername = actionItem.dataset.specificCommentUsername || '';

            document.getElementById('commentText').value = commentText;

            // تحديد checkbox إذا كان هناك اسم مستخدم محدد
            const specificCommentUserCheckbox = document.getElementById('specificCommentUser');
            const specificCommentUsernameInput = document.getElementById('specificCommentUsername');

            if (specificCommentUsername) {
                if (specificCommentUserCheckbox) {
                    specificCommentUserCheckbox.checked = true;
                    document.getElementById('specificCommentUserOptions').style.display = 'block';
                }
                if (specificCommentUsernameInput) {
                    specificCommentUsernameInput.value = specificCommentUsername;
                }
            } else {
                if (specificCommentUserCheckbox) {
                    specificCommentUserCheckbox.checked = false;
                    document.getElementById('specificCommentUserOptions').style.display = 'none';
                }
                if (specificCommentUsernameInput) {
                    specificCommentUsernameInput.value = '';
                }
            }
        } else if (triggerType === 'min_likes') {
            // تحميل قيمة اللايكات الدنيا
            const minLikes = actionItem.dataset.minLikes || '50';
            document.getElementById('actMinLikes').value = minLikes;
        }

        // 🔊 تحميل مستوى الصوت
        const volumeData = actionItem.dataset.volume;
        const volume = (volumeData !== undefined && volumeData !== null && volumeData !== '') ?
            parseInt(volumeData, 10) :
            100;
        const volumeSlider = document.getElementById('actVolume');
        const volumeValue = document.getElementById('volumeValue');
        if (volumeSlider) {
            volumeSlider.value = volume;
            volumeSlider.style.setProperty('--slider-value', volume + '%');
        }
        if (volumeValue) {
            volumeValue.textContent = volume + '%';
        }

        // ⚙️ تحميل الإعدادات المتقدمة
        window.advancedDisplaySettings = {
            profileImageSize: parseInt(actionItem.dataset.profileImageSize) || 150,
            usernameFontSize: parseInt(actionItem.dataset.usernameFontSize) || 34,
            messageFontSize: parseInt(actionItem.dataset.messageFontSize) || 24,
            usernameFontFamily: actionItem.dataset.usernameFontFamily || 'system-ui',
            messageFontFamily: actionItem.dataset.messageFontFamily || 'system-ui',
            usernameColor: actionItem.dataset.usernameColor || '#ffffff',
            messageColor: actionItem.dataset.messageColor || '#ffffff',
            usernameTextShadow: actionItem.dataset.usernameTextShadow !== 'false',
            messageTextShadow: actionItem.dataset.messageTextShadow !== 'false'
        };

        // 🌍 تحميل فلتر الدول المختارة
        const allowedCountriesData = actionItem.dataset.allowedCountries;
        let allowedCountries = [];

        try {
            if (allowedCountriesData) {
                allowedCountries = JSON.parse(allowedCountriesData);
            }
        } catch (e) {}

        const countryFilterCheckbox = document.getElementById('actCountryFilter');
        const countrySelect = document.getElementById('actCountrySelect');

        if (allowedCountries && allowedCountries.length > 0) {
            // تفعيل فلتر الدول
            if (countryFilterCheckbox) {
                countryFilterCheckbox.checked = true;
                document.getElementById('countryFilterOptions').style.display = 'block';
            }

            // تحديد الدول المحفوظة في القائمة
            if (countrySelect) {
                Array.from(countrySelect.options).forEach(option => {
                    option.selected = allowedCountries.includes(option.value);
                });

                // تحديث العرض
                countrySelect.dispatchEvent(new Event('change'));
            }
        } else {
            // إلغاء تفعيل فلتر الدول
            if (countryFilterCheckbox) {
                countryFilterCheckbox.checked = false;
                document.getElementById('countryFilterOptions').style.display = 'none';
            }
        }
    } catch (error) {
        console.error('❌ خطأ في فتح نافذة التعديل:', error);
        showToast('❌ خطأ في فتح نافذة التعديل');
        closeActionPopup();
    }
}

// ====== Actions UI ======
async function loadActions(userId) {

    // 🔍 التحقق من صحة UUID
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(userId)) {
        console.error('❌ معرف المستخدم غير صالح (ليس UUID صحيح):', userId);
        const list = document.getElementById('actionsList');
        list.innerHTML = '<div style="text-align: center; color: #ff0000; padding: 20px;">خطأ: معرف المستخدم غير صالح. يرجى تسجيل الدخول مرة أخرى.</div>';
        return;
    }

    const res = await fetch(`/api/actions/${encodeURIComponent(userId)}`);
    const data = await res.json();
    const list = document.getElementById('actionsList');

    if (!data.actions || data.actions.length === 0) {
        list.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">لا توجد إجراءات بعد</div>';
        return;
    }

    list.innerHTML = data.actions.map(a => {
        // تحديد نوع الإجراء بناءً على trigger_type
        let actionType = '';
        const triggerType = a.trigger_type || 'specific_gift';

        if (triggerType === 'specific_gift' && a.giftName && a.giftName.trim() !== '') {
            // هدية محددة
            const gift = giftsCache ? .find(g => g.name === a.giftName);
            const giftImage = a.giftImage || gift ? .image || '';

            if (giftImage) {
                actionType = `<img src="${giftImage}" alt="${a.giftName}" style="width: 20px; height: 20px; vertical-align: middle; margin-left: 4px; border-radius: 4px;" onerror="this.style.display='none'; this.nextElementSibling.style.display='inline';"><span style="display:none;">🎁</span> ${a.giftName}`;
            } else {
                actionType = `🎁 ${a.giftName}`;
            }
        } else if (triggerType === 'min_diamonds') {
            // حد أدنى للألماسات
            actionType = `💎 ${a.minValue || 1}+ ألماسات`;
        } else if (triggerType === 'follow') {
            // متابعة
            actionType = `👥 متابعة`;
        } else if (triggerType === 'join') {
            // انضمام
            actionType = `🚪 انضمام`;
        } else if (triggerType === 'specific_user_join') {
            // انضمام شخص معين
            const username = a.specific_username || 'غير محدد';
            actionType = `👤 انضمام: @${username}`;
        } else if (triggerType === 'specific_comment') {
            // تعليق معين
            const commentText = a.commentText || 'غير محدد';
            // عرض أول 20 حرف من التعليق
            const displayText = commentText.length > 20 ? commentText.substring(0, 20) + '...' : commentText;
            actionType = `💬 تعليق: ${displayText}`;
        } else if (triggerType === 'min_likes') {
            // حد أدنى للايكات
            actionType = `❤️ ${a.min_likes || 1}+ لايك`;
        }

        // تحديد الميزات الإضافية
        const features = [];
        if (a.playSound) features.push('🔊 صوت');
        if (a.playVideo) features.push('🎥 فيديو');
        if (a.message && a.message.trim() !== '') features.push('💌 رسالة');

        const duration = a.displayDurationMs ? Math.round(a.displayDurationMs / 1000) : 10;

        return `
      <div class="action-item" data-id="${a.id}" 
           data-name="${(a.name || '').replace(/"/g, '&quot;')}"
           data-trigger-type="${triggerType}"
           data-gift-name="${(a.giftName || '').replace(/"/g, '&quot;')}"
           data-gift-image="${(a.giftImage || '').replace(/"/g, '&quot;')}"
           data-gift-id="${a.giftId || ''}"
           data-gift-diamonds="${a.giftDiamonds || ''}"
           data-min-value="${a.minValue || 1}"
           data-min-likes="${a.min_likes || 1}"
           data-specific-username="${(a.specific_username || '').replace(/"/g, '&quot;')}"
           data-execution-limit="${a.execution_limit || 1}"
           data-comment-text="${(a.commentText || '').replace(/"/g, '&quot;')}"
           data-target-screen="${a.targetScreen || 1}"
           data-duration="${duration}"
           data-duration-ms="${a.displayDurationMs || 10000}"
           data-play-sound="${a.playSound ? 'true' : 'false'}"
           data-play-video="${a.playVideo ? 'true' : 'false'}"
           data-show-gift-image="${a.showGiftImage ? 'true' : 'false'}"
           data-message="${(a.message || '').replace(/"/g, '&quot;')}"
           data-sound-file="${a.soundFile || ''}"
           data-sound-key="${(a.soundKey || '').replace(/"/g, '&quot;')}"
           data-sound-url="${(a.soundUrl || '').replace(/"/g, '&quot;')}"
           data-video-file="${a.videoFile || ''}"
           data-sound-file-name="${a.soundFileName || ''}"
           data-video-file-name="${a.videoFileName || ''}"
           data-volume="${a.volume !== undefined && a.volume !== null ? a.volume : 100}"
           data-profile-image-size="${a.profileImageSize || 150}"
           data-username-font-size="${a.usernameFontSize || 34}"
           data-message-font-size="${a.messageFontSize || 24}"
           data-username-font-family="${(a.usernameFontFamily || 'system-ui').replace(/"/g, '&quot;')}"
           data-message-font-family="${(a.messageFontFamily || 'system-ui').replace(/"/g, '&quot;')}"
           data-username-color="${a.usernameColor || '#ffffff'}"
           data-message-color="${a.messageColor || '#ffffff'}"
           data-username-text-shadow="${a.usernameTextShadow !== false ? 'true' : 'false'}"
           data-message-text-shadow="${a.messageTextShadow !== false ? 'true' : 'false'}"
           data-allowed-countries='${JSON.stringify(a.allowedCountries || [])}'
           data-enabled="${a.enabled !== false}">
        <div class="action-content">
          <div class="action-name">${a.name || 'إجراء بدون اسم'}</div>
          <div class="action-tags">
            <span class="tag tag-screen">Screen ${a.targetScreen}</span>
            <span class="tag-separator">•</span>
            <span class="tag tag-gift">${actionType}</span>
            <span class="tag-separator">•</span>
            <span class="tag tag-duration"> ${duration}ث</span>
            ${features.length > 0 ? `<span class="tag-separator">•</span>${features.map(f => `<span class="tag tag-feature">${f}</span>`).join('<span class="tag-separator">•</span>')}` : ''}
            ${(() => {
                if (a.allowedCountries && a.allowedCountries.length === 1) {
                    const countryCode = a.allowedCountries[0];
                    const countryName = COUNTRY_NAMES[countryCode] || `🌍 ${countryCode}`;
                    return `<span class="tag-separator">•</span><span class="tag tag-country" title="فلتر الدولة">${countryName}</span>`;
                } else if (a.allowedCountries && a.allowedCountries.length > 1) {
                    return ` < span class = "tag-separator" > • < /span><span class="tag tag-country" title="فلتر الدول: ${a.allowedCountries.join(', ')}">🌍 ${a.allowedCountries.length} دول</span > `;
                }
                return '';
            })()}
          </div>
        </div>
        <div class="action-buttons">
          ${triggerType === 'specific_user_join' ? '<button class="action-btn reset-btn" title="إعادة تعيين الكاش - السماح بتنفيذ الإجراء مرة أخرى" style="background: linear-gradient(219deg, #b81717, #ff000091);"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg></button>' : ''}
          <button class="action-btn toggle-btn ${a.enabled !== false ? 'enabled' : 'disabled'}" title="${a.enabled !== false ? 'مفعّل - اضغط للتعطيل' : 'معطّل - اضغط للتفعيل'}">
            <span class="toggle-icon">${a.enabled !== false ? '✓' : '✗'}</span>
          </button>
         
          <button class="action-btn test-btn" title="تشغيل تجريبي">تجربة</button>
          <button class="action-btn edit-btn" title="تعديل الإجراء">تعديل</button>
          <button class="action-btn delete-btn" title="حذف الإجراء">حذف</button>
        </div>
      </div>
    `;
    }).join('');


    // معالج أزرار الحذف
    list.querySelectorAll('.delete-btn').forEach(btn => {
        btn.onclick = async () => {
            const actionItem = btn.closest('.action-item');
            const id = actionItem.dataset.id;
            const actionName = actionItem.dataset.name || 'الإجراء';
            const confirmed = await showCustomConfirm(
                'حذف الإجراء',
                `هل تريد حذف الإجراء "${actionName}"؟ سيتم حذف جميع الملفات المرتبطة به.`,
                'حذف',
                '🗑️'
            );
            if (confirmed) {
                const response = await fetch(`/api/actions/${encodeURIComponent(userId)}/${encodeURIComponent(id)}`, {
                    method: 'DELETE'
                });

                // 🔐 معالجة طلب الاشتراك
                if (response.status === 403 || response.status === 402) {
                    const data = await response.json();
                    if (handleApiError(data, data)) {
                        return;
                    }
                }

                showToast('تم حذف الإجراء 🗑️');
                loadActions(userId);
            }
        };
    });

    // معالج أزرار التفعيل/التعطيل
    list.querySelectorAll('.toggle-btn').forEach(btn => {
        btn.onclick = async () => {
            const actionItem = btn.closest('.action-item');
            const actionId = actionItem.dataset.id;
            const actionName = actionItem.dataset.name || 'الإجراء';
            const currentEnabled = actionItem.dataset.enabled === 'true';
            const newEnabled = !currentEnabled;

            try {
                const response = await fetch(`/api/actions/toggle/${encodeURIComponent(userId)}/${encodeURIComponent(actionId)}`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        enabled: newEnabled
                    })
                });

                if (response.ok) {
                    // تحديث UI فوراً
                    actionItem.dataset.enabled = newEnabled;
                    btn.className = `action-btn toggle-btn ${newEnabled ? 'enabled' : 'disabled'}`;
                    btn.title = newEnabled ? 'مفعّل - اضغط للتعطيل' : 'معطّل - اضغط للتفعيل';
                    btn.querySelector('.toggle-icon').textContent = newEnabled ? '✓' : '✗';

                    showToast(newEnabled ? `تم تفعيل "${actionName}" ✓` : `تم تعطيل "${actionName}" ✗`);
                } else {
                    const data = await response.json();
                    showToast('خطأ في تحديث حالة الإجراء ❌', 'error');
                    console.error('Toggle error:', data);
                }
            } catch (error) {
                console.error('Toggle error:', error);
                showToast('خطأ في الاتصال ❌', 'error');
            }
        };
    });

    // معالج أزرار التست
    list.querySelectorAll('.test-btn').forEach(btn => {
        btn.onclick = async () => {
            const actionItem = btn.closest('.action-item');
            const actionId = actionItem.dataset.id;
            const actionName = actionItem.dataset.name || 'Test';

            try {

                // استدعاء الـ endpoint الجديد الذي ينفذ الإجراء بكامل إعداداته
                const response = await fetch(`/api/actions/test/${encodeURIComponent(userId)}/${encodeURIComponent(actionId)}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                const data = await response.json();

                // 🔐 معالجة طلب الاشتراك
                if (response.status === 403 || response.status === 402) {
                    if (handleApiError(data, data)) {
                        return;
                    }
                }

                if (data.success) {
                    showToast(`🧪 تم تشغيل اختبار "${actionName}" بنجاح`);
                } else {
                    showToast(`❌ فشل اختبار الإجراء: ${data.message || 'خطأ غير معروف'}`);
                }
            } catch (error) {
                console.error('❌ خطأ في تشغيل الاختبار:', error);
                showToast('❌ خطأ في تشغيل الاختبار');
            }
        };
    });

    // معالج أزرار التعديل
    list.querySelectorAll('.edit-btn').forEach(btn => {
        btn.onclick = async () => {

            const actionItem = btn.closest('.action-item');

            if (!actionItem) {
                console.error('❌ لم يتم العثور على .action-item');

                // محاولة البحث يدوياً
                let current = btn.parentElement;
                while (current && current !== document.body) {
                    if (current.classList ? .contains('action-item')) {
                        await openEditActionPopup(current, userId);
                        return;
                    }
                    current = current.parentElement;
                }

                showToast('❌ خطأ: لم يتم العثور على بيانات الإجراء');
                return;
            }

            if (!actionItem.dataset) {
                console.error('❌ لا توجد بيانات dataset في العنصر');
                showToast('❌ خطأ: بيانات الإجراء غير متوفرة');
                return;
            }
            await openEditActionPopup(actionItem, userId);
        };
    });

    // معالج أزرار إعادة تعيين الكاش (Reset)
    list.querySelectorAll('.reset-btn').forEach(btn => {
        btn.onclick = async () => {
            const actionItem = btn.closest('.action-item');
            const actionId = actionItem.dataset.id;
            const actionName = actionItem.dataset.name || 'الإجراء';
            const specificUsername = actionItem.dataset.specificUsername || '';

            // تعطيل الزر مؤقتاً لمنع النقر المتكرر
            btn.disabled = true;
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="rotating"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/></svg>';

            try {
                const response = await fetch(`/api/actions/reset-cache/${encodeURIComponent(userId)}/${encodeURIComponent(actionId)}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    if (data.resetPerformed) {
                        showToast(`✅ تم إعادة تعيين كاش "${actionName}" بنجاح`);
                    } else {
                        showToast(`ℹ️ ${data.message}`, 'info');
                    }
                } else {
                    showToast(`❌ ${data.message || 'فشل في إعادة تعيين الكاش'}`, 'error');
                }
            } catch (error) {
                console.error('❌ خطأ في إعادة تعيين الكاش:', error);
                showToast('❌ خطأ في الاتصال', 'error');
            } finally {
                // إعادة تفعيل الزر
                btn.disabled = false;
                btn.innerHTML = originalHTML;
            }
        };
    });
}

// ---------------------------------------------------------
// 🚀 Modern Upload System with Progress Bar
// ---------------------------------------------------------

let activeUploads = {
    video: null, // { xhr, filePath }
    sound: null
};

async function uploadFileWithProgress(file, bucket, userId, onProgress) {
    return new Promise(async (resolve, reject) => {
        const timestamp = Date.now();
        const uuid = Math.random().toString(36).substring(2, 15);
        const safeName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
        const filePath = `users/${userId}/${bucket}/${timestamp}-${uuid}-${safeName}`;

        // 📊 Progress tracking
        let startTime = Date.now();
        let lastBytesUploaded = 0;
        let lastUpdateTime = Date.now();

        // 🔐 Get session token for authenticated upload (fallback to anon key)
        let authToken = SUPABASE_KEY; // Default to anon key
        try {
            const {
                data: {
                    session
                }
            } = await supabase.auth.getSession();
            if (session ? .access_token) {
                authToken = session.access_token;
            } else {}
        } catch (err) {}

        // 🚀 TUS Upload - أسرع طريقة (Resumable, Chunked)
        const upload = new tus.Upload(file, {
            endpoint: `${SUPABASE_URL}/storage/v1/upload/resumable`,
            retryDelays: [0, 1000, 3000, 5000],
            headers: {
                authorization: `Bearer ${authToken}`,
                apikey: SUPABASE_KEY
            },
            uploadDataDuringCreation: true,
            removeFingerprintOnSuccess: true,
            metadata: {
                bucketName: bucket,
                objectName: filePath,
                contentType: file.type,
                cacheControl: '3600'
            },
            chunkSize: 10 * 1024 * 1024, // 10MB chunks for better speed
            onError: function(error) {
                console.error('❌ TUS Upload Failed:', error);
                reject(error);
            },
            onProgress: function(bytesUploaded, bytesTotal) {
                const now = Date.now();
                const percentage = Math.round((bytesUploaded / bytesTotal) * 100);

                // 📈 حساب السرعة (MB/s)
                const deltaBytes = bytesUploaded - lastBytesUploaded;
                const deltaTime = (now - lastUpdateTime) / 1000; // seconds
                const speedMBps = deltaTime > 0 ? (deltaBytes / 1024 / 1024) / deltaTime : 0;

                // ⏱️ حساب الوقت المتبقي (ETA)
                const remainingBytes = bytesTotal - bytesUploaded;
                const etaSeconds = speedMBps > 0 ? remainingBytes / (speedMBps * 1024 * 1024) : 0;

                // Update progress with advanced stats
                onProgress({
                    percent: percentage,
                    uploaded: (bytesUploaded / 1024 / 1024).toFixed(2),
                    total: (bytesTotal / 1024 / 1024).toFixed(2),
                    speed: speedMBps.toFixed(2),
                    eta: etaSeconds > 0 ? Math.ceil(etaSeconds) : 0
                });

                lastBytesUploaded = bytesUploaded;
                lastUpdateTime = now;
            },
            onSuccess: async function() {
                const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

                // Construct public URL
                const {
                    data: publicUrlData
                } = supabase.storage
                    .from(bucket)
                    .getPublicUrl(filePath);

                // Register metadata
                try {
                    await supabase.from('user_media').insert({
                        user_id: userId,
                        bucket_id: bucket,
                        storage_path: filePath,
                        original_filename: file.name,
                        mime_type: file.type,
                        file_size: file.size
                    });
                } catch (err) {}

                resolve({
                    url: publicUrlData.publicUrl,
                    key: filePath,
                    filename: file.name
                });
            }
        });

        // Store reference to abort later
        if (bucket === 'videos') {
            activeUploads.video = upload;
        } else {
            activeUploads.sound = upload;
        }

        // Start the upload
        upload.start();
    });
}

function setupUploadHandler(inputId, type, bucket) {
    const fileInput = document.getElementById(inputId);
    const progressContainer = document.getElementById(`${type}UploadProgress`);
    const progressBar = document.getElementById(`${type}ProgressBar`);
    const progressText = document.getElementById(`${type}ProgressPercent`);
    const cancelBtn = document.getElementById(`cancel${type.charAt(0).toUpperCase() + type.slice(1)}Upload`);
    const createBtn = document.getElementById('createActionBtn');

    if (!fileInput) return;

    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (!currentUser || !currentUser.id) {
            showToast('يجب تسجيل الدخول أولاً', 'error');
            fileInput.value = '';
            return;
        }

        // Reset UI
        progressContainer.style.display = 'block';
        progressBar.style.width = '0%';
        progressText.textContent = '0%';
        createBtn.disabled = true;
        createBtn.textContent = 'جاري الرفع...';
        createBtn.style.opacity = '0.6';
        createBtn.style.cursor = 'not-allowed';

        // Clear previous upload info
        delete fileInput.dataset.uploadedUrl;
        delete fileInput.dataset.uploadedPath;

        try {
            const result = await uploadFileWithProgress(file, bucket, currentUser.id, (stats) => {
                if (typeof stats === 'object') {
                    progressBar.style.width = `${stats.percent}%`;
                    progressText.textContent = `${stats.percent}% • ${stats.uploaded}/${stats.total} MB • ${stats.speed} MB/s ${stats.eta > 0 ? `• ${stats.eta}s` : ''}`;
                } else {
                    // Fallback for old percentage format
                    progressBar.style.width = `${stats}%`;
                    progressText.textContent = `${stats}%`;
                }
            });

            // Upload Complete
            fileInput.dataset.uploadedUrl = result.url;
            fileInput.dataset.uploadedPath = result.key;

            progressBar.style.width = '100%';
            progressText.textContent = '✅ تم الرفع';

            // Enable create button
            createBtn.disabled = false;
            createBtn.textContent = window.editingActionId ? 'حفظ التعديلات' : 'إنشاء الإجراء';
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';

        } catch (error) {
            console.error('Upload failed:', error);
            if (error.message !== 'Upload cancelled') {
                progressText.textContent = '❌ فشل الرفع';
                showToast('فشل رفع الملف', 'error');
            }
            createBtn.disabled = false;
            createBtn.textContent = window.editingActionId ? 'حفظ التعديلات' : 'إنشاء الإجراء';
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
            fileInput.value = ''; // Clear input
        } finally {
            activeUploads[type] = null;
        }
    });

    cancelBtn.addEventListener('click', async () => {
        // 🛑 إلغاء الرفع الجاري
        if (activeUploads[type]) {
            if (typeof activeUploads[type].abort === 'function') {
                activeUploads[type].abort();
            }
            activeUploads[type] = null;
        }

        // 🗑️ حذف الملف المرفوع من Storage إذا كان موجوداً
        if (fileInput.dataset.uploadedPath) {
            try {
                const {
                    error
                } = await supabase.storage.from(bucket).remove([fileInput.dataset.uploadedPath]);
                if (error) {
                    console.error('❌ فشل حذف الملف:', error);
                } else {}
            } catch (err) {
                console.error('❌ خطأ في حذف الملف:', err);
            }
        }

        // 🧹 تنظيف الواجهة بالكامل
        progressContainer.style.display = 'none';
        progressBar.style.width = '0%';
        progressText.textContent = '0%';
        fileInput.value = '';
        delete fileInput.dataset.uploadedUrl;
        delete fileInput.dataset.uploadedPath;

        // إخفاء عرض الملف المحدد
        const selectedDisplay = document.getElementById(`selected${type.charAt(0).toUpperCase() + type.slice(1)}Display`);
        if (selectedDisplay) {
            selectedDisplay.style.display = 'none';
        }

        createBtn.disabled = false;
        createBtn.textContent = window.editingActionId ? 'حفظ التعديلات' : 'إنشاء الإجراء';
        createBtn.style.opacity = '1';
        createBtn.style.cursor = 'pointer';
        showToast('✅ تم إلغاء الرفع وحذف الملف');
    });
}

// Initialize handlers
function initializeModernUploads() {
    setupUploadHandler('actVideoFile', 'video', 'videos');
    setupUploadHandler('actSoundFile', 'sound', 'sounds');
}

// Call this on load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializeModernUploads, 1000);
});

// 🚀 دالة لرفع الفيديو مباشرة إلى Supabase (بدون المرور بالسيرفر)
async function uploadVideoDirectToSupabase(file, userId) {
    try {

        // ✅ SECURITY: userId يُؤخذ من session فقط، لا يمكن تمريره يدوياً
        // RLS على storage.objects تضمن أن المستخدم يرفع فقط إلى مجلده
        const {
            data: {
                user
            }
        } = await supabase.auth.getUser();
        if (!user) {
            throw new Error('يجب تسجيل الدخول أولاً');
        }
        const secureUserId = user.id; // ✅ من session فقط

        // ✅ SECURITY: اسم ملف آمن بدون user input
        const ext = file.name.split('.').pop().toLowerCase();
        const safeFileName = `${Date.now()}-${crypto.randomUUID()}.${ext}`;

        // ✅ ENFORCED PATH: users/{user_id}/videos/{filename}
        const filePath = `users/${secureUserId}/videos/${safeFileName}`;

        // رفع الملف مباشرة إلى Supabase Storage
        // ✅ إضافة timeout 5 دقائق لتجنب التعليق
        const uploadPromise = supabase.storage
            .from('videos')
            .upload(filePath, file, {
                contentType: file.type || 'video/mp4',
                upsert: false
            });

        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('انتهت مهلة الرفع (5 دقائق). يرجى التحقق من سرعة الإنترنت.')), 300000)
        );

        const {
            data,
            error
        } = await Promise.race([uploadPromise, timeoutPromise]);

        if (error) {
            console.error('❌ خطأ في رفع الفيديو:', error);
            throw error;
        }

        // الحصول على الرابط العام
        const {
            data: publicUrlData
        } = supabase.storage
            .from('videos')
            .getPublicUrl(filePath);

        // ✅ تسجيل الملف في جدول user_media للتتبع
        try {
            const {
                error: metadataError
            } = await supabase
                .from('user_media')
                .insert({
                    user_id: secureUserId,
                    bucket_id: 'videos',
                    storage_path: filePath,
                    original_filename: file.name,
                    mime_type: file.type,
                    file_size: file.size
                });

            if (metadataError) {
                // نكمل العملية حتى لو فشل التسجيل (الملف موجود)
            }
        } catch (metaErr) {}

        return {
            url: publicUrlData.publicUrl,
            key: filePath,
            filename: file.name
        };
    } catch (error) {
        console.error('❌ فشل رفع الفيديو:', error);
        throw error;
    }
}

// 🚀 دالة لرفع الصوت مباشرة إلى Supabase (بدون المرور بالسيرفر)
async function uploadSoundDirectToSupabase(file, userId) {
    try {

        // ✅ SECURITY: userId يُؤخذ من session فقط، لا يمكن تمريره يدوياً
        // RLS على storage.objects تضمن أن المستخدم يرفع فقط إلى مجلده
        const {
            data: {
                user
            }
        } = await supabase.auth.getUser();
        if (!user) {
            throw new Error('يجب تسجيل الدخول أولاً');
        }
        const secureUserId = user.id; // ✅ من session فقط

        // ✅ SECURITY: اسم ملف آمن بدون user input
        const ext = file.name.split('.').pop().toLowerCase();
        const safeFileName = `${Date.now()}-${crypto.randomUUID()}.${ext}`;

        // ✅ ENFORCED PATH: users/{user_id}/{filename}
        const filePath = `users/${secureUserId}/${safeFileName}`;

        // رفع الملف مباشرة إلى Supabase Storage
        // ✅ إضافة timeout 5 دقائق
        const uploadPromise = supabase.storage
            .from('sounds')
            .upload(filePath, file, {
                contentType: file.type || 'audio/mpeg',
                upsert: false
            });

        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('انتهت مهلة الرفع (5 دقائق). يرجى التحقق من سرعة الإنترنت.')), 300000)
        );

        const {
            data,
            error
        } = await Promise.race([uploadPromise, timeoutPromise]);

        if (error) {
            console.error('❌ خطأ في رفع الصوت:', error);
            throw error;
        }

        // الحصول على الرابط العام
        const {
            data: publicUrlData
        } = supabase.storage
            .from('sounds')
            .getPublicUrl(filePath);

        // ✅ تسجيل الملف في جدول user_media للتتبع
        try {
            const {
                error: metadataError
            } = await supabase
                .from('user_media')
                .insert({
                    user_id: secureUserId,
                    bucket_id: 'sounds',
                    storage_path: filePath,
                    original_filename: file.name,
                    mime_type: file.type,
                    file_size: file.size
                });

            if (metadataError) {
                // نكمل العملية حتى لو فشل التسجيل (الملف موجود)
            }
        } catch (metaErr) {}

        return {
            url: publicUrlData.publicUrl,
            key: filePath,
            filename: file.name
        };
    } catch (error) {
        console.error('❌ فشل رفع الصوت:', error);
        throw error;
    }
}

async function createAction(userId) {
    const createBtn = document.getElementById('createActionBtn');

    // منع الضغط المتكرر
    if (createBtn.disabled) {
        return;
    }

    // 🔒 التحقق من تسجيل الدخول و userId
    if (!userId) {
        console.error('❌ خطأ: userId غير موجود في المعامل');
        if (!currentUser || !currentUser.id) {
            console.error('❌ خطأ: currentUser غير موجود أيضاً');
            showToast('❌ يجب تسجيل الدخول أولاً', 'error');
            createBtn.disabled = false;
            return;
        }
        // استخدام currentUser.id إذا لم يتم تمرير userId
        userId = currentUser.id;
    }

    // تحقق نهائي
    if (!userId) {
        console.error('❌ خطأ فادح: userId ما زال غير موجود بعد كل المحاولات!');
        showToast('❌ خطأ في تحديد المستخدم، يرجى تحديث الصفحة', 'error');
        createBtn.disabled = false;
        return;
    }

    try {
        const isEditing = window.editingActionId;
        const actionId = window.editingActionId;

        // تعطيل الزر وتغيير النص
        const originalText = createBtn.textContent;
        createBtn.disabled = true;
        createBtn.textContent = isEditing ? 'جاري التعديل...' : 'جاري الإنشاء...';
        createBtn.style.opacity = '0.6';
        createBtn.style.cursor = 'not-allowed';

        // ✅ استخدام JSON بدلاً من FormData (لا توجد ملفات - تم رفعها مسبقاً)
        const requestData = {
            userId: userId,
            name: document.getElementById('actName').value
        };

        if (isEditing) {
            requestData.actionId = actionId;
        }

        // تحديد نوع الحدث المختار
        let selectedTriggerType = null;
        const triggerCheckboxes = document.querySelectorAll('input[name="triggerType"]');
        triggerCheckboxes.forEach(cb => {
            if (cb.checked) {
                selectedTriggerType = cb.value;
            }
        });

        // التحقق من اختيار نوع حدث
        if (!selectedTriggerType) {
            console.error('❌ لم يتم اختيار نوع الحدث');
            showToast('❌ لم تقم باختيار نوع الحدث', 'error');
            createBtn.disabled = false;
            createBtn.textContent = originalText;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
            return;
        }

        requestData.triggerType = selectedTriggerType;

        // معالجة البيانات حسب نوع الحدث
        if (selectedTriggerType === 'specific_gift') {
            // هدية محددة
            const giftSelector = document.getElementById('actGiftSelect');
            const selectedGiftName = giftSelector.value;

            if (!selectedGiftName || selectedGiftName.trim() === '') {
                showToast('❌ يرجى اختيار هدية محددة');
                createBtn.disabled = false;
                createBtn.textContent = originalText;
                createBtn.style.opacity = '1';
                createBtn.style.cursor = 'pointer';
                return;
            }

            requestData.giftName = selectedGiftName;

            // حفظ بيانات الهدية الكاملة
            const selectedOption = giftSelector.options[giftSelector.selectedIndex];
            if (selectedOption) {
                requestData.giftId = selectedOption.dataset.giftId || '';
                requestData.giftImage = selectedOption.dataset.image || '';
                requestData.giftDiamonds = selectedOption.dataset.diamonds || '';
            }

            requestData.minValue = '';
            requestData.minLikes = '';
        } else if (selectedTriggerType === 'min_diamonds') {
            // حد أدنى للألماسات
            const minValue = document.getElementById('actMinValue').value;

            if (!minValue || minValue < 1) {
                showToast('❌ يرجى تحديد قيمة ألماسات صحيحة (1 على الأقل)');
                createBtn.disabled = false;
                createBtn.textContent = originalText;
                createBtn.style.opacity = '1';
                createBtn.style.cursor = 'pointer';
                return;
            }

            requestData.minValue = minValue;
            requestData.giftName = '';
            requestData.giftId = '';
            requestData.giftImage = '';
            requestData.giftDiamonds = '';
            requestData.minLikes = '';
        } else if (selectedTriggerType === 'follow') {
            // لا توجد معاملات إضافية للمتابعة - فقط تفعيل الإجراء عند كل متابعة
            requestData.minValue = '1';
            requestData.giftName = '';
            requestData.giftId = '';
            requestData.giftImage = '';
            requestData.giftDiamonds = '';
            requestData.minLikes = '';
        } else if (selectedTriggerType === 'join') {
            // لا توجد معاملات إضافية للانضمام - فقط تفعيل الإجراء عند كل انضمام
            requestData.minValue = '1';
            requestData.giftName = '';
            requestData.giftId = '';
            requestData.giftImage = '';
            requestData.giftDiamonds = '';
            requestData.minLikes = '';
        } else if (selectedTriggerType === 'specific_user_join') {
            // انضمام شخص معين - يجب إدخال اليوزرنيم
            const specificUsername = document.getElementById('specificUsername').value;

            if (!specificUsername || specificUsername.trim() === '') {
                showToast('❌ يرجى إدخال اسم المستخدم (Username)');
                createBtn.disabled = false;
                createBtn.textContent = originalText;
                createBtn.style.opacity = '1';
                createBtn.style.cursor = 'pointer';
                return;
            }

            // جلب عدد مرات التنفيذ المسموحة
            const executionLimitInput = document.getElementById('specificUserExecutionLimit');
            let executionLimit = executionLimitInput ? parseInt(executionLimitInput.value) : 1;

            // التحقق من القيمة
            if (!executionLimit || executionLimit < 1) {
                executionLimit = 1;
            }
            if (executionLimit > 100) {
                executionLimit = 100;
            }

            // إزالة @ إن وُجد في البداية
            requestData.specificUsername = specificUsername.trim().replace(/^@/, '');
            requestData.executionLimit = executionLimit;
            requestData.minValue = '1';
            requestData.giftName = '';
            requestData.giftId = '';
            requestData.giftImage = '';
            requestData.giftDiamonds = '';
            requestData.minLikes = '';
        } else if (selectedTriggerType === 'min_likes') {
            // حد أدنى للايكات
            const minLikes = document.getElementById('actMinLikes').value;

            if (!minLikes || minLikes < 1) {
                showToast('❌ يرجى تحديد عدد لايكات صحيح (1 على الأقل)');
                createBtn.disabled = false;
                createBtn.textContent = originalText;
                createBtn.style.opacity = '1';
                createBtn.style.cursor = 'pointer';
                return;
            }

            requestData.minLikes = minLikes;
            requestData.giftName = '';
            requestData.giftId = '';
            requestData.giftImage = '';
            requestData.giftDiamonds = '';
            requestData.minValue = '';
        } else if (selectedTriggerType === 'specific_comment') {
            // تعليق معين - يجب إدخال نص التعليق
            const commentText = document.getElementById('commentText').value;

            if (!commentText || commentText.trim() === '') {
                showToast('❌ يرجى إدخال نص التعليق');
                createBtn.disabled = false;
                createBtn.textContent = originalText;
                createBtn.style.opacity = '1';
                createBtn.style.cursor = 'pointer';
                return;
            }

            // التحقق من خيار "من شخص معين"
            const specificCommentUserCheckbox = document.getElementById('specificCommentUser');
            const specificCommentUsernameInput = document.getElementById('specificCommentUsername');

            if (specificCommentUserCheckbox && specificCommentUserCheckbox.checked) {
                const username = specificCommentUsernameInput ? specificCommentUsernameInput.value.trim() : '';
                if (!username) {
                    showToast('❌ يرجى إدخال اسم المستخدم');
                    createBtn.disabled = false;
                    createBtn.textContent = originalText;
                    createBtn.style.opacity = '1';
                    createBtn.style.cursor = 'pointer';
                    return;
                }
                requestData.specificCommentUsername = username;
            } else {
                requestData.specificCommentUsername = '';
            }

            requestData.commentText = commentText.trim();
            requestData.minValue = '1';
            requestData.giftName = '';
            requestData.giftId = '';
            requestData.giftImage = '';
            requestData.giftDiamonds = '';
            requestData.minLikes = '';
        }

        requestData.targetScreen = document.getElementById('actTargetScreen').value;

        const playSoundChecked = document.getElementById('actPlaySound').checked;
        const playVideoChecked = document.getElementById('actPlayVideo').checked;

        requestData.playSound = playSoundChecked;
        requestData.playVideo = playVideoChecked;

        // التحقق من اختيار ملف صوت عند تفعيل "تشغيل صوت"
        const soundFileInput = document.getElementById('actSoundFile');
        const hasSoundFile = soundFileInput.files.length > 0;
        const hasLibrarySound = selectedLibrarySound !== null;

        // في حالة التعديل، التحقق من وجود ملف صوت موجود مسبقاً
        const hasExistingSound = isEditing && document.getElementById('selectedSoundDisplay') ? .style.display === 'block';

        if (playSoundChecked && !hasSoundFile && !hasLibrarySound && !hasExistingSound) {
            console.error('❌ تم تفعيل الصوت لكن لا يوجد ملف صوت محدد');
            showToast('❌ لم تقم بتحديد ملف الصوت', 'error');
            createBtn.disabled = false;
            createBtn.textContent = originalText;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
            return;
        }

        // التحقق من اختيار ملف فيديو عند تفعيل "تشغيل فيديو"
        const videoFileInput = document.getElementById('actVideoFile');
        const hasVideoFile = videoFileInput.files.length > 0;

        // في حالة التعديل، التحقق من وجود ملف فيديو موجود مسبقاً
        const hasExistingVideo = isEditing && document.getElementById('currentVideoFile') ? .style.display === 'block';

        if (playVideoChecked && !hasVideoFile && !hasExistingVideo) {
            console.error('❌ تم تفعيل الفيديو لكن لا يوجد ملف فيديو محدد');
            showToast('❌ لم تقم بتحديد ملف الفيديو', 'error');
            createBtn.disabled = false;
            createBtn.textContent = originalText;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
            return;
        }

        // 🆕 إضافة الرسالة
        const showThankYou = document.getElementById('actShowThankYou').checked;
        const message = showThankYou ? document.getElementById('actThankYouMessage').value.trim() : '';
        requestData.message = message;

        // 🌍 إضافة فلتر الدولة
        const countryFilterEnabled = document.getElementById('actCountryFilter').checked;
        const countrySelect = document.getElementById('actCountrySelect');
        const selectedCountries = countryFilterEnabled && countrySelect ?
            Array.from(countrySelect.selectedOptions).map(opt => opt.value) :
            [];

        requestData.allowedCountries = selectedCountries;

        // ✅ تحديد showGiftImage حسب نوع التفعيل
        let showGiftImage = false;
        if (selectedTriggerType === 'specific_gift') {
            showGiftImage = document.getElementById('actShowGiftImageSpecific').checked;
        } else if (selectedTriggerType === 'min_diamonds') {
            showGiftImage = document.getElementById('actShowGiftImageDiamonds').checked;
        }
        requestData.showGiftImage = showGiftImage;

        // المدة بالثواني ← ملي ثانية
        const durSec = Number(document.getElementById('actDurationSec').value || '10');
        requestData.displayDurationMs = Math.max(1000, Math.floor(durSec * 1000));

        // 🔊 إضافة مستوى الصوت
        const volumeInput = document.getElementById('actVolume').value;
        const volumeValue = Number.isNaN(parseInt(volumeInput, 10)) ? 100 : parseInt(volumeInput, 10);
        requestData.volume = Math.max(0, Math.min(100, volumeValue));

        // ⚙️ إضافة الإعدادات المتقدمة
        if (window.advancedDisplaySettings) {
            requestData.profileImageSize = window.advancedDisplaySettings.profileImageSize || 150;
            requestData.usernameFontSize = window.advancedDisplaySettings.usernameFontSize || 34;
            requestData.messageFontSize = window.advancedDisplaySettings.messageFontSize || 24;
            requestData.usernameFontFamily = window.advancedDisplaySettings.usernameFontFamily || 'system-ui';
            requestData.messageFontFamily = window.advancedDisplaySettings.messageFontFamily || 'system-ui';
            requestData.usernameColor = window.advancedDisplaySettings.usernameColor || '#ffffff';
            requestData.messageColor = window.advancedDisplaySettings.messageColor || '#ffffff';
            requestData.usernameTextShadow = window.advancedDisplaySettings.usernameTextShadow !== false;
            requestData.messageTextShadow = window.advancedDisplaySettings.messageTextShadow !== false;
        } else {
            // القيم الافتراضية
            requestData.profileImageSize = 150;
            requestData.usernameFontSize = 34;
            requestData.messageFontSize = 24;
            requestData.usernameFontFamily = 'system-ui';
            requestData.messageFontFamily = 'system-ui';
            requestData.usernameColor = '#ffffff';
            requestData.messageColor = '#ffffff';
            requestData.usernameTextShadow = true;
            requestData.messageTextShadow = true;
        }

        // Handle sound: either from file upload or from library
        const soundFileInputEl = document.getElementById('actSoundFile');

        // 🚀 رفع الصوت مباشرة إلى Supabase إن وُجد
        if (soundFileInputEl.files.length > 0) {
            // ✅ Check if already uploaded via progress bar
            if (soundFileInputEl.dataset.uploadedUrl) {
                requestData.uploadedSoundUrl = soundFileInputEl.dataset.uploadedUrl;
                requestData.uploadedSoundKey = soundFileInputEl.dataset.uploadedPath;
                requestData.uploadedSoundFilename = soundFileInputEl.files[0].name;
            } else {
                const soundFile = soundFileInputEl.files[0];

                // فحص حجم ملف الصوت (الحد الأقصى 50 ميجابايت)
                if (soundFile.size > 50 * 1024 * 1024) {
                    console.error('❌ ملف الصوت كبير جداً:', soundFile.size, 'bytes');
                    showToast('❌ ملف الصوت كبير جداً! الحد الأقصى 50 ميجابايت');
                    createBtn.disabled = false;
                    createBtn.textContent = originalText;
                    createBtn.style.opacity = '1';
                    createBtn.style.cursor = 'pointer';
                    return;
                }

                try {
                    createBtn.textContent = '🔊 جاري رفع الصوت...';
                    const soundData = await uploadSoundDirectToSupabase(soundFile, userId);
                    requestData.uploadedSoundUrl = soundData.url;
                    requestData.uploadedSoundKey = soundData.key;
                    requestData.uploadedSoundFilename = soundData.filename;
                } catch (error) {
                    console.error('❌ فشل رفع الصوت:', error);
                    showToast('❌ فشل رفع الصوت: ' + error.message);
                    createBtn.disabled = false;
                    createBtn.textContent = originalText;
                    createBtn.style.opacity = '1';
                    createBtn.style.cursor = 'pointer';
                    return;
                }
            }
        }
        // Check if using library sound
        else if (selectedLibrarySound) {
            requestData.librarySoundId = selectedLibrarySound.id;
            requestData.librarySoundUrl = selectedLibrarySound.url;
            requestData.librarySoundName = selectedLibrarySound.name;
        }
        // إذا كان playSound مفعل لكن لا يوجد ملف - يعني تم حذفه
        else if (!playSoundChecked) {
            // إذا تم إلغاء تفعيل الصوت، أرسل إشارة لحذف الملف القديم
            requestData.removeSoundFile = 'true';
        }

        // 🚀 رفع الفيديو مباشرة إلى Supabase إن وُجد
        if (videoFileInput.files.length > 0) {
            // ✅ Check if already uploaded via progress bar
            if (videoFileInput.dataset.uploadedUrl) {
                requestData.uploadedVideoUrl = videoFileInput.dataset.uploadedUrl;
                requestData.uploadedVideoKey = videoFileInput.dataset.uploadedPath;
                requestData.uploadedVideoFilename = videoFileInput.files[0].name;
            } else {
                const videoFile = videoFileInput.files[0];

                // التحقق من نوع الملف
                const allowedVideoTypes = [
                    'video/mp4',
                    'video/avi',
                    'video/quicktime',
                    'video/x-msvideo',
                    'video/mov',
                    'video/webm',
                    'video/x-matroska'
                ];

                const isValidType = allowedVideoTypes.some(type =>
                    videoFile.type.toLowerCase().includes(type.split('/')[1]) ||
                    videoFile.name.toLowerCase().endsWith('.mp4') ||
                    videoFile.name.toLowerCase().endsWith('.avi') ||
                    videoFile.name.toLowerCase().endsWith('.mov') ||
                    videoFile.name.toLowerCase().endsWith('.webm') ||
                    videoFile.name.toLowerCase().endsWith('.mkv')
                );

                if (!isValidType && videoFile.type && !videoFile.type.startsWith('video/')) {
                    console.error('❌ نوع ملف غير مدعوم:', videoFile.type);
                    showToast('❌ نوع الفيديو غير مدعوم! استخدم MP4, AVI, MOV, أو WEBM');
                    createBtn.disabled = false;
                    createBtn.textContent = originalText;
                    createBtn.style.opacity = '1';
                    createBtn.style.cursor = 'pointer';
                    return;
                }

                // فحص حجم ملف الفيديو (الحد الأقصى 50 ميجابايت)
                if (videoFile.size > 50 * 1024 * 1024) {
                    console.error('❌ ملف الفيديو كبير جداً:', videoFile.size, 'bytes');
                    showToast('❌ ملف الفيديو كبير جداً! الحد الأقصى 50 ميجابايت');
                    createBtn.disabled = false;
                    createBtn.textContent = originalText;
                    createBtn.style.opacity = '1';
                    createBtn.style.cursor = 'pointer';
                    return;
                }

                try {
                    createBtn.textContent = '🎥 جاري رفع الفيديو...';
                    const videoData = await uploadVideoDirectToSupabase(videoFile, userId);
                    requestData.uploadedVideoUrl = videoData.url;
                    requestData.uploadedVideoKey = videoData.key;
                    requestData.uploadedVideoFilename = videoData.filename;
                    createBtn.textContent = isEditing ? 'جاري التعديل...' : 'جاري الإنشاء...';
                } catch (error) {
                    console.error('❌ فشل رفع الفيديو:', error);
                    showToast('❌ فشل رفع الفيديو: ' + error.message);
                    createBtn.disabled = false;
                    createBtn.textContent = originalText;
                    createBtn.style.opacity = '1';
                    createBtn.style.cursor = 'pointer';
                    return;
                }
            }
        } else if (!playVideoChecked) {
            requestData.removeVideoFile = 'true';
        }

        const apiEndpoint = isEditing ? `/api/actions/${encodeURIComponent(userId)}/${encodeURIComponent(actionId)}` : '/api/actions';
        const apiMethod = isEditing ? 'PUT' : 'POST';

        const res = await fetch(apiEndpoint, {
            method: apiMethod,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });

        let data;
        let responseText = ''; // تعريف responseText خارج try block
        try {
            responseText = await res.text();
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('❌ خطأ في تحليل JSON:', parseError);
            console.error('📝 النص الذي فشل تحليله:', responseText);
            showToast('❌ خطأ في معالجة استجابة الخادم');
            createBtn.disabled = false;
            createBtn.textContent = originalText;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
            return;
        }

        // 🔐 معالجة طلب الاشتراك
        if (res.status === 403 || res.status === 402) {
            if (handleApiError(data, data)) {
                createBtn.disabled = false;
                createBtn.textContent = originalText;
                createBtn.style.opacity = '1';
                createBtn.style.cursor = 'pointer';
                return;
            }
        }

        if (data.success) {
            const successMessage = isEditing ? 'تم تحديث الإجراء ✅' : 'تم إنشاء الإجراء ✅';
            showToast(successMessage);
            loadActions(userId);

            // إغلاق النافذة المنبثقة وإعادة تعيين النموذج
            closeActionPopup(true); // ✅ تم حفظ الإجراء - لا تحذف الملفات

            // إعادة تفعيل الزر (سيتم إعادة تعيينه مع النموذج)
            createBtn.disabled = false;
            createBtn.textContent = originalText;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
        } else {
            const errorMessage = isEditing ? 'فشل تحديث الإجراء' : 'فشل إنشاء الإجراء';
            console.error('❌ فشل:', errorMessage);
            console.error('📋 رسالة الخطأ من السيرفر:', data.message);
            console.error('📋 تفاصيل إضافية:', data.error);
            showToast(`❌ ${errorMessage}: ${data.message || data.error || 'خطأ غير معروف'}`);

            // إعادة تفعيل الزر عند الفشل
            createBtn.disabled = false;
            createBtn.textContent = originalText;
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
        }
    } catch (error) {
        const isEditing = window.editingActionId;
        const errorAction = isEditing ? 'تحديث الإجراء' : 'إنشاء الإجراء';
        console.error(`❌❌❌ خطأ في ${errorAction}:`, error);
        console.error('📋 نوع الخطأ:', error.name);
        console.error('📋 رسالة الخطأ:', error.message);
        console.error('📋 Stack:', error.stack);
        showToast(`❌ خطأ في ${errorAction}: ${error.message}`);

        // إعادة تفعيل الزر عند حدوث خطأ
        if (createBtn) {
            createBtn.disabled = false;
            createBtn.textContent = isEditing ? 'حفظ التعديلات' : 'Create Action';
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
        }
    }
}


// دوال حذف الملفات
async function deleteActionFile(fileType) {
    if (!window.editingActionId) {
        showToast('❌ لا يوجد إجراء محدد للتعديل');
        return;
    }

    if (!currentUser) {
        showToast('❌ يجب تسجيل الدخول أولاً');
        return;
    }

    const title = fileType === 'sound' ? 'حذف ملف الصوت' : 'حذف ملف الفيديو';
    const message = fileType === 'sound' ?
        'هل تريد حذف ملف الصوت من هذا الإجراء؟ لا يمكن التراجع عن هذا الإجراء.' :
        'هل تريد حذف ملف الفيديو من هذا الإجراء؟ لا يمكن التراجع عن هذا الإجراء.';
    const icon = '🗑️';
    const okText = 'حذف';

    const confirmed = await showCustomConfirm(title, message, okText, icon);
    if (!confirmed) {
        return;
    }

    try {
        // إظهار حالة التحميل
        showToast('⏳ جاري حذف الملف...', 'info');

        const response = await fetch(`/api/actions/${encodeURIComponent(currentUser.id)}/${encodeURIComponent(window.editingActionId)}/delete-file`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                fileType
            })
        });

        const result = await response.json();

        if (result.success) {
            showToast(`🗑️ تم حذف ملف ${fileType === 'sound' ? 'الصوت' : 'الفيديو'} بنجاح`, 'success');

            // إخفاء عرض الملف المحذوف
            if (fileType === 'sound') {
                clearSelectedSound();
            } else {
                const currentVideoFile = document.getElementById('currentVideoFile');
                if (currentVideoFile) {
                    currentVideoFile.style.display = 'none';
                }
            }

            // تحديث قائمة الإجراءات
            await loadActions(currentUser.id);
        } else {
            showToast(`❌ فشل في حذف ملف ${fileType === 'sound' ? 'الصوت' : 'الفيديو'}: ${result.error}`);
        }
    } catch (error) {
        console.error('خطأ في حذف الملف:', error);
        showToast('❌ خطأ في حذف الملف');
    }
}

// إضافة event listeners لأزرار الحذف
function setupFileDeleteListeners() {
    const deleteSoundBtn = document.getElementById('deleteSoundBtn');
    const deleteVideoBtn = document.getElementById('deleteVideoBtn');

    if (deleteSoundBtn) {
        deleteSoundBtn.addEventListener('click', () => deleteActionFile('sound'));
    }

    if (deleteVideoBtn) {
        deleteVideoBtn.addEventListener('click', () => deleteActionFile('video'));
    }
}

// نافذة التأكيد المخصصة
function showCustomConfirm(title, message, okText = 'تأكيد', icon = '⚠️') {
    return new Promise((resolve) => {
        const modal = document.getElementById('customConfirmModal');
        const titleElement = document.getElementById('confirmTitle');
        const messageElement = document.getElementById('confirmMessage');
        const iconElement = document.getElementById('confirmIconText');
        const okTextElement = document.getElementById('confirmOkText');
        const okBtn = document.getElementById('confirmOkBtn');
        const cancelBtn = document.getElementById('confirmCancelBtn');
        const backdrop = modal.querySelector('.confirm-backdrop');

        // تعيين المحتوى
        titleElement.textContent = title;
        messageElement.textContent = message;
        iconElement.textContent = icon;
        okTextElement.textContent = okText;

        // تخصيص نمط الزر حسب نوع العملية
        if (okText === 'حذف') {
            okBtn.className = 'confirm-btn confirm-ok confirm-delete';
        } else {
            okBtn.className = 'confirm-btn confirm-ok';
        }

        // منع قفز المحتوى عند إخفاء شريط التمرير: أضف padding-right مساوي لعرض الشريط
        const scrollBarWidth = window.innerWidth - document.documentElement.clientWidth;
        if (scrollBarWidth > 0) {
            document.body.style.paddingRight = `${scrollBarWidth}px`;
        }
        // إظهار النافذة (عرض كـ flex ليتمركز بنفس طريقة modal-overlay)
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';

        // دالة الإغلاق
        const closeModal = (result) => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            // إعادة تعيين padding-right الذي أضفناه
            document.body.style.paddingRight = '';
            resolve(result);
        };

        // معالجات الأحداث
        const handleOk = () => closeModal(true);
        const handleCancel = () => closeModal(false);

        // إزالة المعالجات القديمة وإضافة الجديدة
        okBtn.replaceWith(okBtn.cloneNode(true));
        cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        backdrop.replaceWith(backdrop.cloneNode(true));

        // إعادة الحصول على العناصر بعد الاستنساخ
        const newOkBtn = document.getElementById('confirmOkBtn');
        const newCancelBtn = document.getElementById('confirmCancelBtn');
        const newBackdrop = modal.querySelector('.confirm-backdrop');

        newOkBtn.addEventListener('click', handleOk);
        newCancelBtn.addEventListener('click', handleCancel);
        newBackdrop.addEventListener('click', handleCancel);

        // إضافة معالج ESC key
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                document.removeEventListener('keydown', handleEsc);
                handleCancel();
            }
        };
        document.addEventListener('keydown', handleEsc);
    });
}

// تهيئة event listeners عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    setupFileDeleteListeners();
});

// دالة حفظ ملف المستخدم (منقولة من auth.js)
async function saveUserProfile(user) {
    try {
        // التحقق من وجود المستخدم في قاعدة البيانات
        const {
            data: existingUser,
            error: checkError
        } = await supabase
            .from('users')
            .select('*')
            .eq('user_id', user.id)
            .single();

        if (checkError && checkError.code !== 'PGRST116') { // PGRST116 = no rows found
            throw checkError;
        }

        // إذا لم يكن المستخدم موجود، أنشئ ملف تعريف جديد
        if (!existingUser) {
            const uniqueCode = generateUniqueCode();
            const widgetToken = generateWidgetToken();

            const {
                error: insertError
            } = await supabase
                .from('users')
                .insert([{
                    user_id: user.id,
                    email: user.email,
                    unique_code: uniqueCode,
                    widget_token: widgetToken
                }]);

            if (insertError) {
                throw insertError;
            }
        }

    } catch (error) {
        console.error('خطأ في حفظ ملف المستخدم:', error);
    }
}

function generateUniqueCode() {
    return Math.random().toString(36).substr(2, 10).toUpperCase();
}

function generateWidgetToken() {
    return Math.random().toString(36).substr(2, 20) + Date.now().toString(36);
}

// ==================== دوال إعدادات Podium ====================

// تحميل التصاميم المتاحة ديناميكياً
async function loadAvailableThemes() {
    try {

        const response = await fetch('/api/themes/likers', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            const data = await response.json();

            const select = document.getElementById('likersThemeSelect');

            if (select && data.themes && data.themes.length > 0) {
                // حفظ القيمة الحالية
                const currentValue = select.value;

                // مسح الخيارات القديمة
                select.innerHTML = '';

                // إضافة التصاميم الجديدة
                data.themes.forEach(theme => {
                    const option = document.createElement('option');
                    option.value = theme.id;
                    option.textContent = theme.name;
                    select.appendChild(option);
                });

                // استعادة القيمة المحفوظة إذا كانت موجودة
                if (currentValue && data.themes.some(t => t.id === currentValue)) {
                    select.value = currentValue;
                }
            }
        } else {
            console.error('❌ خطأ في الاستجابة:', response.status);
        }
    } catch (error) {
        console.error('❌ خطأ في تحميل التصاميم:', error);
    }
}

// فتح نافذة الإعدادات
function openPodiumSettings() {
    const modal = document.getElementById('podiumSettingsModal');
    modal.classList.add('active');

    // تحميل التصاميم المتاحة أولاً
    loadAvailableThemes();

    // تحميل الإعدادات الحالية
    loadPodiumSettings();
    loadLikersTheme();
}

// إغلاق نافذة الإعدادات
function closePodiumSettings() {
    const modal = document.getElementById('podiumSettingsModal');
    modal.classList.remove('active');
}

// فتح نافذة إعدادات الداعمين
function openSupportersSettings() {
    const modal = document.getElementById('supportersSettingsModal');
    modal.classList.add('active');

    // تحميل الإعدادات الحالية
    loadSupportersSettings();
}

// إغلاق نافذة إعدادات الداعمين
function closeSupportersSettings() {
    const modal = document.getElementById('supportersSettingsModal');
    modal.classList.remove('active');
}

// تحميل التصميم المحفوظ
async function loadLikersTheme() {
    try {
        if (!currentUser) return;

        const response = await fetch('/api/user-theme/likers', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'x-user-id': currentUser.id
            }
        });

        if (response.ok) {
            const data = await response.json();
            const select = document.getElementById('likersThemeSelect');
            if (select) {
                select.value = data.theme || 'horizontal-podium';
                updateLikersTheme(); // تحديث واجهة المراكز
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل التصميم:', error);
    }
}

// تحديث التصميم (تحديد الخيارات المتاحة)
function updateLikersTheme() {
    const themeSelect = document.getElementById('likersThemeSelect');
    const ranksSelect = document.getElementById('ranksCountSelect');
    const ranksContainer = document.getElementById('likersRanksContainer');

    if (!themeSelect || !ranksSelect || !ranksContainer) return;

    const selectedTheme = themeSelect.value;
    const currentValue = ranksSelect.value; // 💾 حفظ القيمة الحالية

    // تحديث خيارات المراكز حسب التصميم
    if (selectedTheme === 'bear-top3') {
        // تصميم الدب: 3 مراكز فقط
        ranksSelect.innerHTML = '<option value="3" selected>3 مراكز</option>';
        ranksSelect.disabled = true;
        ranksContainer.style.opacity = '0.6';
    } else if (selectedTheme === 'cyber-blade-podium') {
        // Cyber Blade: من 1 إلى 3 مراكز
        ranksSelect.disabled = false;
        ranksContainer.style.opacity = '1';
        ranksSelect.innerHTML = `
            <option value="1">1 مركز</option>
            <option value="2">2 مركز</option>
            <option value="3">3 مراكز</option>
        `;
        // 🔄 استرجاع القيمة المحفوظة
        if (currentValue && currentValue >= 1 && currentValue <= 3) {
            ranksSelect.value = currentValue;
        }
    } else if (selectedTheme === 'horizontal-podium') {
        // التصميم الأفقي: من 1 إلى 10
        ranksSelect.disabled = false;
        ranksContainer.style.opacity = '1';
        ranksSelect.innerHTML = `
            <option value="1">1 مركز</option>
            <option value="2">2 مركز</option>
            <option value="3">3 مراكز</option>
            <option value="4">4 مراكز</option>
            <option value="5">5 مراكز</option>
            <option value="6">6 مراكز</option>
            <option value="7">7 مراكز</option>
            <option value="8">8 مراكز</option>
            <option value="9">9 مراكز</option>
            <option value="10">10 مراكز</option>
        `;
        // 🔄 استرجاع القيمة المحفوظة
        if (currentValue && currentValue >= 1 && currentValue <= 10) {
            ranksSelect.value = currentValue;
        }
    }
}

// تحميل الإعدادات من السيرفر
async function loadPodiumSettings() {
    try {
        if (!currentUser) {
            console.error('لا يوجد مستخدم متصل');
            return;
        }

        // 💾 تحميل فوري من localStorage (تجنب القفزات)
        const cachedRanks = localStorage.getItem('podium_ranks_count');
        const cachedFlip = localStorage.getItem('podium_flip_direction');

        const select = document.getElementById('ranksCountSelect');
        const flipToggle = document.getElementById('podiumFlipToggle');
        const flipStatus = document.getElementById('podiumFlipStatus');

        if (cachedRanks && select) {
            select.value = cachedRanks;
        }

        if (cachedFlip && flipToggle && flipStatus) {
            flipToggle.checked = cachedFlip === 'ltr';
            flipStatus.textContent = cachedFlip === 'ltr' ? 'يسار إلى يمين (LTR)' : 'يمين إلى يسار (RTL)';
        }

        const response = await fetch('/api/settings/podium', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'x-user-id': currentUser.id
            }
        });

        if (response.ok) {
            const settings = await response.json();
            if (select) {
                select.value = settings.podium_ranks_count || 10;
                localStorage.setItem('podium_ranks_count', select.value); // 💾 حفظ
            }

            // تحميل إعداد الـ Flip
            if (flipToggle && settings.podium_flip_direction) {
                flipToggle.checked = settings.podium_flip_direction === 'ltr';
                localStorage.setItem('podium_flip_direction', settings.podium_flip_direction); // 💾 حفظ
                if (flipStatus) {
                    flipStatus.textContent = settings.podium_flip_direction === 'ltr' ? 'يسار إلى يمين (LTR)' : 'يمين إلى يسار (RTL)';
                }
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل الإعدادات:', error);
    }
}

// تحميل إعدادات الداعمين من السيرفر
async function loadSupportersSettings() {
    try {
        if (!currentUser) {
            console.error('لا يوجد مستخدم متصل');
            return;
        }

        // 💾 تحميل فوري من localStorage
        const cachedRanks = localStorage.getItem('supporters_ranks_count');
        const cachedDirection = localStorage.getItem('supporters_flip_direction');
        const cachedTheme = localStorage.getItem('supporters_theme');
        const ranksSelect = document.getElementById('supportersRanksCountSelect');
        const directionSelect = document.getElementById('supportersFlipDirectionSelect');
        const themeSelect = document.getElementById('supportersThemeSelect');

        if (cachedRanks && ranksSelect) {
            ranksSelect.value = cachedRanks;
        }

        if (cachedDirection && directionSelect) {
            directionSelect.value = cachedDirection;
        }

        if (cachedTheme && themeSelect) {
            themeSelect.value = cachedTheme;
            updateSupportersTheme(); // تحديث خيارات المراكز
        }

        const response = await fetch('/api/settings/supporters', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'x-user-id': currentUser.id
            }
        });

        if (response.ok) {
            const settings = await response.json();
            if (ranksSelect) {
                ranksSelect.value = settings.supporters_ranks_count || 10;
                localStorage.setItem('supporters_ranks_count', ranksSelect.value); // 💾 حفظ
            }
            if (directionSelect) {
                directionSelect.value = settings.supporters_flip_direction || 'ltr';
                localStorage.setItem('supporters_flip_direction', directionSelect.value); // 💾 حفظ
            }
            if (themeSelect && settings.supporters_theme) {
                themeSelect.value = settings.supporters_theme;
                localStorage.setItem('supporters_theme', themeSelect.value); // 💾 حفظ
                updateSupportersTheme(); // تحديث خيارات المراكز
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات الداعمين:', error);
    }
}

// تحديث العدد مباشرة (معاينة)
function updateRanksCount() {
    const select = document.getElementById('ranksCountSelect');
    const count = parseInt(select.value);
    localStorage.setItem('podium_ranks_count', count); // 💾 حفظ فوري
}

// تبديل اتجاه التصميم
function togglePodiumFlip() {
    const flipToggle = document.getElementById('podiumFlipToggle');
    const flipStatus = document.getElementById('podiumFlipStatus');

    if (flipToggle && flipStatus) {
        const direction = flipToggle.checked ? 'ltr' : 'rtl';
        flipStatus.textContent = flipToggle.checked ? 'يسار إلى يمين (LTR)' : 'يمين إلى يسار (RTL)';
        localStorage.setItem('podium_flip_direction', direction); // 💾 حفظ فوري
    }
}

// تحديث عدد الداعمين مباشرة (معاينة)
function updateSupportersRanksCount() {
    const select = document.getElementById('supportersRanksCountSelect');
    const count = parseInt(select.value);
    localStorage.setItem('supporters_ranks_count', count); // 💾 حفظ فوري
}

// حفظ الإعدادات
async function savePodiumSettings() {
    const themeSelect = document.getElementById('likersThemeSelect');
    const ranksSelect = document.getElementById('ranksCountSelect');
    const flipToggle = document.getElementById('podiumFlipToggle');
    const selectedTheme = themeSelect.value;
    const ranksCount = parseInt(ranksSelect.value);
    const flipDirection = flipToggle && flipToggle.checked ? 'ltr' : 'rtl';

    if (!currentUser) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        // 1. حفظ التصميم
        const themeResponse = await fetch('/api/user-theme/likers', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-user-id': currentUser.id
            },
            body: JSON.stringify({
                themeId: selectedTheme
            })
        });

        if (!themeResponse.ok) {
            const errorData = await themeResponse.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ التصميم'), 'error');
            return;
        }

        // 2. حفظ عدد المراكز واتجاه التصميم
        const settingsPayload = {
            podium_flip_direction: flipDirection
        };

        // إضافة عدد المراكز (تصميم الدب فقط مقفول على 3)
        if (selectedTheme !== 'bear-top3') {
            settingsPayload.podium_ranks_count = ranksCount;
        }

        const settingsResponse = await fetch('/api/settings/podium', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-user-id': currentUser.id
            },
            body: JSON.stringify(settingsPayload)
        });

        if (!settingsResponse.ok) {
            const errorData = await settingsResponse.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
            return;
        }

        // 3. إغلاق النافذة وإعادة تحميل
        closePodiumSettings();

        // عرض رسالة توضح الاتجاه المحفوظ
        const directionText = flipDirection === 'ltr' ? 'يسار إلى يمين (LTR)' : 'يمين إلى يسار (RTL)';
        showToast(`✅ تم حفظ الإعدادات - الاتجاه: ${directionText}`, 'success');

        // إعادة تحميل الـ iframe للـ podium لتطبيق التغييرات فوراً
        const iframe = document.getElementById('horizontalPodiumPreview');
        if (iframe && iframe.src) {
            const currentSrc = iframe.src;
            iframe.src = '';
            setTimeout(() => {
                iframe.src = currentSrc;
            }, 100);
        }

        // 4. إرسال تحديث Socket.IO لإبلاغ overlay-composer-view بتحديث التصميم
        if (typeof socket !== 'undefined' && socket && socket.connected) {
            socket.emit('podiumThemeChanged', {
                token: widgetToken,
                theme: selectedTheme
            });
        }
    } catch (error) {
        console.error('خطأ في حفظ الإعدادات:', error);
        showToast('❌ حدث خطأ في حفظ الإعدادات', 'error');
    }
}

// حفظ إعدادات الداعمين
async function saveSupportersSettings() {
    const ranksSelect = document.getElementById('supportersRanksCountSelect');
    const directionSelect = document.getElementById('supportersFlipDirectionSelect');
    const themeSelect = document.getElementById('supportersThemeSelect');
    const ranksCount = parseInt(ranksSelect.value);
    const flipDirection = directionSelect.value;
    const selectedTheme = themeSelect.value;

    if (!currentUser) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/settings/supporters', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-user-id': currentUser.id
            },
            body: JSON.stringify({
                supporters_ranks_count: ranksCount,
                supporters_flip_direction: flipDirection,
                supporters_theme: selectedTheme
            })
        });

        if (response.ok) {
            // حفظ في localStorage
            localStorage.setItem('supporters_ranks_count', ranksCount);
            localStorage.setItem('supporters_flip_direction', flipDirection);
            localStorage.setItem('supporters_theme', selectedTheme);

            // إغلاق النافذة فوراً (حفظ صامت)
            closeSupportersSettings();

            // إعادة تحميل الـ iframe للـ supporters لتطبيق التغييرات فوراً
            const iframe = document.getElementById('horizontalPodiumSupportersPreview');
            if (iframe && iframe.src) {
                // إعادة تحميل كاملة للـ iframe
                const currentSrc = iframe.src;
                iframe.src = '';
                setTimeout(() => {
                    iframe.src = currentSrc;
                }, 100);
            }
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ إعدادات الداعمين'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات الداعمين:', error);
        showToast('❌ حدث خطأ في حفظ إعدادات الداعمين', 'error');
    }
}

// تحديث خيارات التصميم للداعمين
function updateSupportersTheme() {
    const themeSelect = document.getElementById('supportersThemeSelect');
    const ranksSelect = document.getElementById('supportersRanksCountSelect');
    const ranksContainer = document.getElementById('supportersRanksContainer');

    if (!themeSelect || !ranksSelect || !ranksContainer) return;

    const selectedTheme = themeSelect.value;
    const currentValue = ranksSelect.value; // 💾 حفظ القيمة الحالية

    // تحديث خيارات المراكز حسب التصميم
    if (selectedTheme === 'bear-top3-supporters') {
        // تصميم الدب: 3 مراكز فقط
        ranksSelect.innerHTML = '<option value="3" selected>3 مراكز</option>';
        ranksSelect.disabled = true;
        ranksContainer.style.opacity = '0.6';
    } else if (selectedTheme === 'cyber-blade-podium-supporters') {
        // Cyber Blade: من 1 إلى 3 مراكز
        ranksSelect.disabled = false;
        ranksContainer.style.opacity = '1';
        ranksSelect.innerHTML = `
            <option value="1">1 مركز</option>
            <option value="2">2 مركز</option>
            <option value="3">3 مراكز</option>
        `;
        // 🔄 استرجاع القيمة المحفوظة
        if (currentValue && currentValue >= 1 && currentValue <= 3) {
            ranksSelect.value = currentValue;
        }
    } else if (selectedTheme === 'horizontal-podium-supporters') {
        // التصميم الأفقي: من 1 إلى 10
        ranksSelect.disabled = false;
        ranksContainer.style.opacity = '1';
        ranksSelect.innerHTML = `
            <option value="1">1 مركز</option>
            <option value="2">2 مركز</option>
            <option value="3">3 مراكز</option>
            <option value="4">4 مراكز</option>
            <option value="5">5 مراكز</option>
            <option value="6">6 مراكز</option>
            <option value="7">7 مراكز</option>
            <option value="8">8 مراكز</option>
            <option value="9">9 مراكز</option>
            <option value="10">10 مراكز</option>
        `;
        // 🔄 استرجاع القيمة المحفوظة
        if (currentValue && currentValue >= 1 && currentValue <= 10) {
            ranksSelect.value = currentValue;
        }
    }
}


// إغلاق النافذة عند الضغط خارجها
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('podiumSettingsModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closePodiumSettings();
            }
        });
    }

    const likesModal = document.getElementById('likesSettingsModal');
    if (likesModal) {
        likesModal.addEventListener('click', function(e) {
            if (e.target === likesModal) {
                closeLikesSettings();
            }
        });
    }

    // 🔊 معالج شريط التحكم بالصوت
    const volumeSlider = document.getElementById('actVolume');
    const volumeValue = document.getElementById('volumeValue');

    if (volumeSlider && volumeValue) {
        // تحديث القيمة عند تحريك الشريط
        volumeSlider.addEventListener('input', function() {
            const value = this.value;
            volumeValue.textContent = value + '%';
            // تحديث لون التعبئة
            this.style.setProperty('--slider-value', value + '%');
        });

        // تعيين القيمة الأولية
        volumeSlider.style.setProperty('--slider-value', '100%');
    }
});


// ==================== دوال إعدادات الإعجابات ====================

// فتح نافذة إعدادات الإعجابات
function openLikesSettings() {
    const modal = document.getElementById('likesSettingsModal');
    modal.classList.add('active');

    // تحميل الإعدادات الحالية
    loadLikesSettings();
}

// إغلاق نافذة إعدادات الإعجابات
function closeLikesSettings() {
    const modal = document.getElementById('likesSettingsModal');
    modal.classList.remove('active');
}

// تحميل إعدادات الإعجابات من السيرفر
async function loadLikesSettings() {
    try {
        if (!widgetToken) {
            console.error('لا يوجد توكن');
            return;
        }

        const response = await fetch(`/api/widget/likes-settings/${widgetToken}`);

        if (response.ok) {
            const settings = await response.json();
            document.getElementById('nameColorPicker').value = settings.likes_name_color || '#ff1515';
            document.getElementById('frameColorPicker').value = settings.likes_frame_color || '#ff0000';

            // تحميل إعدادات الصوت
            const soundEnabled = settings.likes_sound_enabled || false;
            document.getElementById('likesSoundEnabled').checked = soundEnabled;
            document.getElementById('likesSoundVolume').value = settings.likes_sound_volume || 80;
            document.getElementById('likesSoundVolumeValue').textContent = settings.likes_sound_volume || 80;

            // إظهار/إخفاء خيارات الصوت
            toggleLikesSoundOptions();

            // عرض الصوت المحدد إذا كان موجوداً
            if (soundEnabled && settings.likes_sound_id) {
                selectedLikesLibrarySound = {
                    id: settings.likes_sound_id,
                    url: settings.likes_sound_url,
                    name: settings.likes_sound_name
                };
                showLikesSelectedSound(settings.likes_sound_name, 'مكتبة الأصوات');
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات الإعجابات:', error);
    }
}

// حفظ إعدادات الإعجابات
async function saveLikesSettings() {
    const nameColor = document.getElementById('nameColorPicker').value;
    const frameColor = document.getElementById('frameColorPicker').value;
    const soundEnabled = document.getElementById('likesSoundEnabled').checked;
    const soundVolume = document.getElementById('likesSoundVolume').value;

    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const requestData = {
            token: widgetToken,
            likes_name_color: nameColor,
            likes_frame_color: frameColor,
            likes_sound_enabled: soundEnabled,
            likes_sound_volume: soundVolume
        };

        // إضافة معلومات الصوت إذا كان مفعلاً
        if (soundEnabled && selectedLikesLibrarySound) {
            requestData.likes_sound_id = selectedLikesLibrarySound.id;
            requestData.likes_sound_url = selectedLikesLibrarySound.url;
            requestData.likes_sound_name = selectedLikesLibrarySound.name;
        }

        const response = await fetch('/api/widget/likes-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });

        if (response.ok) {
            // إغلاق النافذة
            closeLikesSettings();
            showToast('✅ تم حفظ إعدادات الإعجابات بنجاح', 'success');

            // تطبيق الإعدادات على الـ iframe مباشرة
            const iframe = document.getElementById('likesWidgetPreview');
            if (iframe && iframe.contentWindow && iframe.contentWindow.saveLikesSettingsWidget) {
                iframe.contentWindow.saveLikesSettingsWidget(nameColor, frameColor);
            }

            // إرسال التحديث عبر Socket.io لجميع الـ widgets
            if (window.socket && window.socket.connected) {
                window.socket.emit('updateLikesSettings', {
                    token: widgetToken,
                    likes_name_color: nameColor,
                    likes_frame_color: frameColor,
                    likes_sound_enabled: soundEnabled,
                    likes_sound_volume: soundVolume,
                    likes_sound_id: requestData.likes_sound_id,
                    likes_sound_url: requestData.likes_sound_url,
                    likes_sound_name: requestData.likes_sound_name
                });
            }
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات الإعجابات:', error);
        showToast('❌ حدث خطأ في حفظ إعدادات الإعجابات', 'error');
    }
}

// دالة اختبار الإعجاب
async function testLikeWidget() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'warning');
        return;
    }

    try {
        const response = await fetch('/api/widget/test-like', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken
            })
        });

        if (response.ok) {
            // الإعجاب التجريبي تم إرساله بنجاح لجميع الويدجتات المفتوحة
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إرسال الإعجاب التجريبي'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إرسال الإعجاب التجريبي:', error);
        showToast('❌ حدث خطأ في إرسال الإعجاب التجريبي', 'error');
    }
}

async function testFollowWidget() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'warning');
        return;
    }

    try {
        const response = await fetch('/api/widget/test-follow', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken
            })
        });

        if (response.ok) {
            // المتابعة التجريبية تم إرسالها بنجاح لجميع الويدجتات المفتوحة
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إرسال المتابعة التجريبية'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إرسال المتابعة التجريبية:', error);
        showToast('❌ حدث خطأ في إرسال المتابعة التجريبية', 'error');
    }
}

// ==================== دوال اختبار وإعدادات الألعاب النارية ====================

async function testFireworkWidget() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'warning');
        return;
    }

    try {
        // تحميل ملف الهدايا للحصول على هدية عشوائية
        let randomGift;
        try {
            const giftsResponse = await fetch('/assets/img/gifts/gifts-info.json');
            const giftsData = await giftsResponse.json();

            // اختيار هدية عشوائية
            randomGift = giftsData[Math.floor(Math.random() * giftsData.length)];
        } catch (err) {
            randomGift = {
                id: 5655,
                name: 'Rose',
                diamonds: 1,
                imageUrl: 'https://p19-webcast.tiktokcdn.com/img/maliva/webcast-va/eba3a9bb85c33e017f3648eaf88d7189~tplv-obj.png'
            };
        }

        // أسماء تجريبية عشوائية
        const testNames = [
            'مستخدم تجريبي 🎆',
            'Test User ⭐',
            'مشاهد كريم 💎',
            'داعم مميز 🌟',
            'Supporter 🎁'
        ];
        const randomName = testNames[Math.floor(Math.random() * testNames.length)];

        const response = await fetch('/api/widget/test-gift', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                giftData: {
                    nickname: randomName,
                    profilePictureUrl: '/assets/img/avatar1.png',
                    giftPictureUrl: randomGift.imageUrl || randomGift.fileName ? `/assets/img/gifts/${randomGift.fileName}` : randomGift.imageUrl,
                    diamondCount: randomGift.diamonds || 1,
                    giftId: randomGift.id,
                    giftName: randomGift.name,
                    isTest: true
                }
            })
        });

        if (response.ok) {} else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إرسال الهدية التجريبية'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إرسال الهدية التجريبية:', error);
        showToast('❌ حدث خطأ في إرسال الهدية التجريبية', 'error');
    }
}

async function openFireworkSettings() {
    document.getElementById('fireworkSettingsModal').style.display = 'flex';
    await loadFireworkSettings();
}

// إغلاق نافذة إعدادات الألعاب النارية
function closeFireworkSettings() {
    document.getElementById('fireworkSettingsModal').style.display = 'none';
}

// تحميل إعدادات الألعاب النارية من السيرفر
async function loadFireworkSettings() {
    try {
        if (!widgetToken) {
            console.error('لا يوجد توكن');
            return;
        }

        // 💾 تحميل فوري من localStorage
        const cachedEnabled = localStorage.getItem('firework_soundenabled');
        const cachedVolume = localStorage.getItem('firework_soundvolume');
        const cachedMinCoins = localStorage.getItem('firework_mincoins');
        const cachedMaxConcurrent = localStorage.getItem('firework_maxconcurrent');

        if (cachedEnabled !== null) {
            document.getElementById('fireworkSoundEnabled').checked = cachedEnabled === 'true';
        }
        if (cachedVolume !== null) {
            const volumeValue = parseInt(cachedVolume);
            document.getElementById('fireworkSoundVolume').value = volumeValue;
            document.getElementById('fireworkSoundVolumeValue').textContent = volumeValue;
        }
        if (cachedMinCoins !== null) {
            document.getElementById('fireworkMinCoins').value = cachedMinCoins;
        }
        if (cachedMaxConcurrent !== null) {
            document.getElementById('fireworkMaxConcurrent').value = cachedMaxConcurrent;
        }

        const response = await fetch(`/api/widget/firework-settings/${widgetToken}`);

        if (response.ok) {
            const settings = await response.json();
            const soundEnabled = settings.firework_soundenabled !== false;
            const volumeValue = settings.firework_soundvolume !== null && settings.firework_soundvolume !== undefined ? settings.firework_soundvolume : 80;
            const minCoins = settings.firework_mincoins || 1;
            const maxConcurrentValue = settings.firework_maxconcurrent !== undefined && settings.firework_maxconcurrent !== null ? settings.firework_maxconcurrent : 1;

            document.getElementById('fireworkSoundEnabled').checked = soundEnabled;
            document.getElementById('fireworkSoundVolume').value = volumeValue;
            document.getElementById('fireworkSoundVolumeValue').textContent = volumeValue;
            document.getElementById('fireworkMinCoins').value = minCoins;
            document.getElementById('fireworkMaxConcurrent').value = Math.min(Math.max(maxConcurrentValue, 1), 7);

            // 💾 حفظ في localStorage
            localStorage.setItem('firework_soundenabled', soundEnabled);
            localStorage.setItem('firework_soundvolume', volumeValue);
            localStorage.setItem('firework_mincoins', minCoins);
            localStorage.setItem('firework_maxconcurrent', Math.min(Math.max(maxConcurrentValue, 1), 7));
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات الألعاب النارية:', error);
    }
}

// حفظ إعدادات الألعاب النارية
async function saveFireworkSettings() {
    const soundEnabled = document.getElementById('fireworkSoundEnabled').checked;
    const soundVolume = parseInt(document.getElementById('fireworkSoundVolume').value);
    const minCoins = parseInt(document.getElementById('fireworkMinCoins').value);
    let maxConcurrent = parseInt(document.getElementById('fireworkMaxConcurrent').value);

    // التحقق من الحد الأقصى
    if (maxConcurrent > 7) {
        showToast('⚠️ الحد الأقصى للألعاب النارية المتزامنة هو 7', 'warning');
        maxConcurrent = 7;
        document.getElementById('fireworkMaxConcurrent').value = 7;
        return;
    }
    if (maxConcurrent < 1) {
        maxConcurrent = 1;
        document.getElementById('fireworkMaxConcurrent').value = 1;
    }

    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/firework-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                firework_soundenabled: soundEnabled,
                firework_soundvolume: soundVolume,
                firework_mincoins: minCoins,
                firework_maxconcurrent: maxConcurrent
            })
        });

        if (response.ok) {
            closeFireworkSettings();
        } else {
            showToast('❌ فشل حفظ الإعدادات', 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات الألعاب النارية:', error);
        showToast('❌ حدث خطأ أثناء حفظ الإعدادات', 'error');
    }
}

// ==================== دوال إعدادات المتابعات ====================

// فتح نافذة إعدادات المتابعات
async function openFollowsSettings() {
    document.getElementById('followsSettingsModal').style.display = 'flex';
    await loadFollowsSettings();
}

// إغلاق نافذة إعدادات المتابعات
function closeFollowsSettings() {
    document.getElementById('followsSettingsModal').style.display = 'none';
}

// تحميل إعدادات المتابعات من السيرفر
async function loadFollowsSettings() {
    try {
        if (!widgetToken) {
            console.error('لا يوجد توكن');
            return;
        }

        const response = await fetch(`/api/widget/follows-settings/${widgetToken}`);

        if (response.ok) {
            const settings = await response.json();
            document.getElementById('followsNameColorPicker').value = settings.follows_name_color || '#1900ff';
            document.getElementById('followsFrameColorPicker').value = settings.follows_frame_color || '#3700ff';
            document.getElementById('followsThanksColorPicker').value = settings.follows_thanks_color || '#ffffff';

            // تحميل إعدادات الصوت
            const soundEnabled = settings.follows_sound_enabled || false;
            document.getElementById('followsSoundEnabled').checked = soundEnabled;
            document.getElementById('followsSoundVolume').value = settings.follows_sound_volume || 80;
            document.getElementById('followsSoundVolumeValue').textContent = settings.follows_sound_volume || 80;

            // إظهار/إخفاء خيارات الصوت
            toggleFollowsSoundOptions();

            // عرض الصوت المحدد إذا كان موجوداً
            if (soundEnabled && settings.follows_sound_id) {
                selectedFollowsLibrarySound = {
                    id: settings.follows_sound_id,
                    url: settings.follows_sound_url,
                    name: settings.follows_sound_name
                };
                showFollowsSelectedSound(settings.follows_sound_name, 'مكتبة الأصوات');
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات المتابعات:', error);
    }
}

// حفظ إعدادات المتابعات
async function saveFollowsSettings() {
    const nameColor = document.getElementById('followsNameColorPicker').value;
    const frameColor = document.getElementById('followsFrameColorPicker').value;
    const thanksColor = document.getElementById('followsThanksColorPicker').value;
    const soundEnabled = document.getElementById('followsSoundEnabled').checked;
    const soundVolume = document.getElementById('followsSoundVolume').value;

    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const requestData = {
            token: widgetToken,
            follows_name_color: nameColor,
            follows_frame_color: frameColor,
            follows_thanks_color: thanksColor,
            follows_sound_enabled: soundEnabled,
            follows_sound_volume: soundVolume
        };

        // إضافة معلومات الصوت إذا كان مفعلاً
        if (soundEnabled && selectedFollowsLibrarySound) {
            requestData.follows_sound_id = selectedFollowsLibrarySound.id;
            requestData.follows_sound_url = selectedFollowsLibrarySound.url;
            requestData.follows_sound_name = selectedFollowsLibrarySound.name;
        }

        const response = await fetch('/api/widget/follows-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });

        if (response.ok) {
            // إغلاق النافذة
            closeFollowsSettings();
            showToast('✅ تم حفظ إعدادات المتابعات بنجاح', 'success');

            // تطبيق الإعدادات على الـ iframe مباشرة
            const iframe = document.getElementById('followsWidgetPreview');
            if (iframe && iframe.contentWindow && iframe.contentWindow.saveFollowsSettingsWidget) {
                iframe.contentWindow.saveFollowsSettingsWidget(nameColor, frameColor, thanksColor);
            }

            // إرسال التحديث عبر Socket.io لجميع الـ widgets
            if (window.socket && window.socket.connected) {
                window.socket.emit('updateFollowsSettings', {
                    token: widgetToken,
                    follows_name_color: nameColor,
                    follows_frame_color: frameColor,
                    follows_thanks_color: thanksColor,
                    follows_sound_enabled: soundEnabled,
                    follows_sound_volume: soundVolume,
                    follows_sound_id: requestData.follows_sound_id,
                    follows_sound_url: requestData.follows_sound_url,
                    follows_sound_name: requestData.follows_sound_name
                });
            }
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات المتابعات:', error);
        showToast('❌ حدث خطأ في حفظ الإعدادات', 'error');
    }
}

// ====================================
// دوال إدارة خيارات الصوت للمتابعات
// ====================================
let selectedFollowsLibrarySound = null;

function toggleFollowsSoundOptions() {
    const soundEnabled = document.getElementById('followsSoundEnabled').checked;
    const soundOptions = document.getElementById('followsSoundOptions');
    soundOptions.style.display = soundEnabled ? 'block' : 'none';
}

function showFollowsSelectedSound(name, source) {
    const display = document.getElementById('followsSelectedSoundDisplay');
    const nameSpan = document.getElementById('followsSelectedSoundName');
    const sourceSpan = document.getElementById('followsSelectedSoundSource');

    nameSpan.textContent = name;
    sourceSpan.textContent = 'المصدر: ' + source;
    display.style.display = 'block';
}

function clearFollowsSelectedSound() {
    selectedFollowsLibrarySound = null;
    document.getElementById('followsSelectedSoundDisplay').style.display = 'none';
}

function openFollowsSoundLibrary() {
    currentSoundContext = 'follows';
    openSoundLibrary();
}

// ====================================
// دوال إدارة خيارات الصوت للإعجابات
// ====================================
let selectedLikesLibrarySound = null;

function toggleLikesSoundOptions() {
    const soundEnabled = document.getElementById('likesSoundEnabled').checked;
    const soundOptions = document.getElementById('likesSoundOptions');
    soundOptions.style.display = soundEnabled ? 'block' : 'none';
}

function showLikesSelectedSound(name, source) {
    const display = document.getElementById('likesSelectedSoundDisplay');
    const nameSpan = document.getElementById('likesSelectedSoundName');
    const sourceSpan = document.getElementById('likesSelectedSoundSource');

    nameSpan.textContent = name;
    sourceSpan.textContent = 'المصدر: ' + source;
    display.style.display = 'block';
}

function clearLikesSelectedSound() {
    selectedLikesLibrarySound = null;
    document.getElementById('likesSelectedSoundDisplay').style.display = 'none';
}

function openLikesSoundLibrary() {
    currentSoundContext = 'likes';
    openSoundLibrary();
}

// ====================================
// Sound Library Functions
// ====================================

let currentPlayingAudio = null;
let selectedLibrarySound = null;
let currentSoundContext = 'actions'; // يمكن أن يكون: 'actions', 'follows', 'likes'

// Initialize sound library event listeners
document.addEventListener('DOMContentLoaded', function() {
    const uploadSoundBtn = document.getElementById('uploadSoundBtn');
    const soundLibraryBtn = document.getElementById('soundLibraryBtn');
    const actSoundFile = document.getElementById('actSoundFile');
    const closeSoundLibraryBtn = document.getElementById('closeSoundLibraryBtn');
    const soundLibraryModal = document.getElementById('soundLibraryModal');
    const soundSearchInput = document.getElementById('soundSearchInput');
    const deleteSelectedSoundBtn = document.getElementById('deleteSelectedSoundBtn');
    const thankYouMessageTextarea = document.getElementById('actThankYouMessage');
    const charCountSpan = document.getElementById('charCount');

    // 🎥 عناصر الفيديو
    const uploadVideoBtn = document.getElementById('uploadVideoBtn');
    const actVideoFile = document.getElementById('actVideoFile');
    const deleteVideoBtn = document.getElementById('deleteVideoBtn');
    const deleteCurrentVideoBtn = document.getElementById('deleteCurrentVideoBtn');

    // 🔊 أزرار الصوت للمتابعات والإعجابات
    const followsSoundLibraryBtn = document.getElementById('followsSoundLibraryBtn');
    const followsDeleteSoundBtn = document.getElementById('followsDeleteSoundBtn');
    const likesSoundLibraryBtn = document.getElementById('likesSoundLibraryBtn');
    const likesDeleteSoundBtn = document.getElementById('likesDeleteSoundBtn');

    // زر رفع ملف صوت - يفتح file picker مباشرة
    if (uploadSoundBtn) {
        uploadSoundBtn.addEventListener('click', function() {
            actSoundFile.click();
        });
    }

    // زر مكتبة الأصوات - يفتح المكتبة مباشرة
    if (soundLibraryBtn) {
        soundLibraryBtn.addEventListener('click', function() {
            currentSoundContext = 'actions';
            openSoundLibrary();
        });
    }

    // زر حذف الصوت المحدد
    if (deleteSelectedSoundBtn) {
        deleteSelectedSoundBtn.addEventListener('click', function() {
            clearSelectedSound();
        });
    }

    // 🎥 زر رفع ملف فيديو - يفتح file picker مباشرة
    if (uploadVideoBtn) {
        uploadVideoBtn.addEventListener('click', function() {
            actVideoFile.click();
        });
    }

    // 🎥 زر حذف الفيديو المحدد (الجديد)
    if (deleteVideoBtn) {
        deleteVideoBtn.addEventListener('click', function() {
            clearSelectedVideo();
        });
    }

    // 🎥 زر حذف الفيديو المحفوظ (في وضع التعديل)
    if (deleteCurrentVideoBtn) {
        deleteCurrentVideoBtn.addEventListener('click', async function() {
            await clearCurrentVideo();
        });
    }

    // 🔊 أزرار المتابعات
    if (followsSoundLibraryBtn) {
        followsSoundLibraryBtn.addEventListener('click', openFollowsSoundLibrary);
    }
    if (followsDeleteSoundBtn) {
        followsDeleteSoundBtn.addEventListener('click', clearFollowsSelectedSound);
    }

    // 🔊 أزرار الإعجابات
    if (likesSoundLibraryBtn) {
        likesSoundLibraryBtn.addEventListener('click', openLikesSoundLibrary);
    }
    if (likesDeleteSoundBtn) {
        likesDeleteSoundBtn.addEventListener('click', clearLikesSelectedSound);
    }

    // Close modal
    if (closeSoundLibraryBtn) {
        closeSoundLibraryBtn.addEventListener('click', closeSoundLibrary);
    }

    // Close on backdrop click
    if (soundLibraryModal) {
        soundLibraryModal.addEventListener('click', function(e) {
            if (e.target === soundLibraryModal) {
                closeSoundLibrary();
            }
        });
    }

    // Search functionality
    if (soundSearchInput) {
        soundSearchInput.addEventListener('input', function(e) {
            filterSounds(e.target.value);
        });
    }

    // Character counter for thank you message
    if (thankYouMessageTextarea && charCountSpan) {
        // Update counter on input
        thankYouMessageTextarea.addEventListener('input', function() {
            const currentLength = this.value.length;
            charCountSpan.textContent = currentLength;

            // Change color based on character count
            if (currentLength > 180) {
                charCountSpan.style.color = '#f85149'; // Red when close to limit
            } else if (currentLength > 150) {
                charCountSpan.style.color = '#d29922'; // Orange warning
            } else {
                charCountSpan.style.color = '#58a6ff'; // Default blue
            }
        });

        // Initialize counter on page load
        charCountSpan.textContent = thankYouMessageTextarea.value.length;
    }
});

// عرض الصوت المحدد
function showSelectedSound(name, source) {
    const display = document.getElementById('selectedSoundDisplay');
    const nameSpan = document.getElementById('selectedSoundName');
    const sourceSpan = document.getElementById('selectedSoundSource');

    nameSpan.textContent = name;
    sourceSpan.textContent = 'المصدر: ' + source;
    display.style.display = 'block';
}

// حذف الصوت المحدد
async function clearSelectedSound() {
    const display = document.getElementById('selectedSoundDisplay');
    const actSoundFile = document.getElementById('actSoundFile');
    const createBtn = document.getElementById('createActionBtn');

    // 🛑 إيقاف الرفع الجاري إن كان موجوداً
    if (activeUploads.sound) {
        if (typeof activeUploads.sound.abort === 'function') {
            activeUploads.sound.abort();
        }
        activeUploads.sound = null;

        // إعادة تفعيل زر Create Action
        if (createBtn) {
            createBtn.disabled = false;
            createBtn.textContent = window.editingActionId ? 'حفظ التعديلات' : 'Create Action';
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
        }
    }

    // إذا كان في وضع التعديل وهناك صوت محفوظ، احذفه من قاعدة البيانات
    if (window.editingActionId) {
        // استخدام currentUser المتغير العام بدلاً من sessionStorage
        if (currentUser && currentUser.id) {
            try {
                const response = await fetch(`/api/actions/${currentUser.id}/${window.editingActionId}/delete-file`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        fileType: 'sound'
                    })
                });

                const result = await response.json();
                if (result.success) {
                    showToast('🗑️ تم حذف ملف الصوت من قاعدة البيانات', 'success');
                } else {
                    console.error('فشل حذف الملف من قاعدة البيانات:', result.error);
                }
            } catch (error) {
                console.error('خطأ في حذف الملف:', error);
            }
        }
    }

    // إخفاء العرض
    display.style.display = 'none';
    // إخفاء شريط التقدم إن كان موجوداً
    const soundProgress = document.getElementById('soundUploadProgress');
    if (soundProgress) soundProgress.style.display = 'none';

    // حذف الملف المحلي
    actSoundFile.value = '';

    // حذف الصوت من المكتبة
    selectedLibrarySound = null;

    if (!window.editingActionId) {
        showToast('تم إلغاء تحديد الصوت', 'info');
    }
}

// 🎥 عرض الفيديو المحدد
function showSelectedVideo(name) {
    const display = document.getElementById('selectedVideoDisplay');
    const nameSpan = document.getElementById('selectedVideoName');

    nameSpan.textContent = name;
    display.style.display = 'block';
}

// 🎥 حذف الفيديو المحدد (الجديد)
function clearSelectedVideo() {
    const display = document.getElementById('selectedVideoDisplay');
    const actVideoFile = document.getElementById('actVideoFile');
    const createBtn = document.getElementById('createActionBtn');

    // 🛑 إيقاف الرفع الجاري إن كان موجوداً
    if (activeUploads.video) {
        if (typeof activeUploads.video.abort === 'function') {
            activeUploads.video.abort();
        }
        activeUploads.video = null;

        // إعادة تفعيل زر Create Action
        if (createBtn) {
            createBtn.disabled = false;
            createBtn.textContent = window.editingActionId ? 'حفظ التعديلات' : 'Create Action';
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
        }
    }

    // إخفاء العرض
    display.style.display = 'none';
    // إخفاء شريط التقدم إن كان موجوداً
    const videoProgress = document.getElementById('videoUploadProgress');
    if (videoProgress) videoProgress.style.display = 'none';

    // حذف الملف
    actVideoFile.value = '';

    if (!window.editingActionId) {
        showToast('تم إلغاء تحديد الفيديو', 'info');
    }
}

// 🎥 حذف الفيديو المحفوظ (في وضع التعديل)
async function clearCurrentVideo() {
    const currentVideoFile = document.getElementById('currentVideoFile');
    const actVideoFile = document.getElementById('actVideoFile');
    const createBtn = document.getElementById('createActionBtn');

    // 🛑 إيقاف الرفع الجاري إن كان موجوداً
    if (activeUploads.video) {
        if (typeof activeUploads.video.abort === 'function') {
            activeUploads.video.abort();
        }
        activeUploads.video = null;

        // إعادة تفعيل زر Create Action
        if (createBtn) {
            createBtn.disabled = false;
            createBtn.textContent = window.editingActionId ? 'حفظ التعديلات' : 'Create Action';
            createBtn.style.opacity = '1';
            createBtn.style.cursor = 'pointer';
        }
    }

    // إذا كان في وضع التعديل، احذف الملف من قاعدة البيانات
    if (window.editingActionId) {
        // استخدام currentUser المتغير العام بدلاً من sessionStorage
        if (currentUser && currentUser.id) {
            try {
                const response = await fetch(`/api/actions/${currentUser.id}/${window.editingActionId}/delete-file`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        fileType: 'video'
                    })
                });

                const result = await response.json();
                if (result.success) {
                    showToast('🗑️ تم حذف ملف الفيديو', 'success');
                } else {
                    console.error('فشل حذف الملف من قاعدة البيانات:', result.error);
                }
            } catch (error) {
                console.error('خطأ في حذف الملف:', error);
            }
        }
    }

    // إخفاء عرض الملف المحفوظ
    currentVideoFile.style.display = 'none';
    // إخفاء شريط التقدم إن كان موجوداً
    const videoProgress = document.getElementById('videoUploadProgress');
    if (videoProgress) videoProgress.style.display = 'none';

    // حذف الملف من input
    actVideoFile.value = '';
}


// Open sound library and load sounds
async function openSoundLibrary() {
    const modal = document.getElementById('soundLibraryModal');
    modal.style.display = 'flex';

    // Load sounds from database
    await loadSoundsFromLibrary();
}

// Close sound library
function closeSoundLibrary() {
    const modal = document.getElementById('soundLibraryModal');
    modal.style.display = 'none';

    // Stop any playing audio
    if (currentPlayingAudio) {
        currentPlayingAudio.pause();
        currentPlayingAudio = null;
    }
}

// Load sounds from database
async function loadSoundsFromLibrary() {
    const soundList = document.getElementById('soundLibraryList');
    soundList.innerHTML = `
        <div class="loading-sounds">
            <div class="spinner-circle"></div>
            <p>جاري تحميل الأصوات...</p>
        </div>
    `;

    try {
        const response = await fetch('/api/sound-library');
        const data = await response.json();

        if (data.success && data.sounds.length > 0) {
            renderSounds(data.sounds);

            // 🚀 تحميل جميع الأصوات مسبقاً في الخلفية
            preloadAllSounds(data.sounds);
        } else {
            soundList.innerHTML = `
                <div class="no-sounds-message">
                    <i class="fas fa-music"></i>
                    <p>لا توجد أصوات في المكتبة حالياً</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('خطأ في تحميل الأصوات:', error);
        soundList.innerHTML = `
            <div class="no-sounds-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>حدث خطأ في تحميل الأصوات</p>
            </div>
        `;
    }
}

// 🚀 تحميل جميع الأصوات مسبقاً
const preloadedAudio = new Map();

function preloadAllSounds(sounds) {

    sounds.forEach((sound, index) => {
        if (!sound.file_url) return;

        // تحميل بالتدريج لتجنب الضغط على المتصفح
        setTimeout(() => {
            const audio = new Audio();
            audio.preload = 'auto';
            audio.src = sound.file_url;

            audio.addEventListener('canplaythrough', () => {
                preloadedAudio.set(sound.file_url, audio);
            }, {
                once: true
            });

            audio.addEventListener('error', (e) => {}, {
                once: true
            });

            audio.load();
        }, index * 100); // تأخير 100ms بين كل صوت
    });
}

// Render sounds list
function renderSounds(sounds) {
    const soundList = document.getElementById('soundLibraryList');
    soundList.innerHTML = '';

    sounds.forEach(sound => {
        const soundItem = document.createElement('div');
        soundItem.className = 'sound-item';
        soundItem.dataset.soundId = sound.id;
        soundItem.dataset.soundName = sound.name.toLowerCase();

        soundItem.innerHTML = `
            <span class="sound-item-name">${sound.name}</span>
            <div class="sound-item-actions">
                <button class="sound-play-btn" onclick="playSoundPreview('${sound.file_url}', this)">
                    <i class="fas fa-play"></i>
                    Play
                </button>
                <button class="sound-apply-btn" onclick="applyLibrarySound(${sound.id}, '${sound.name}', '${sound.file_url}')">
                    <i class="fas fa-check"></i>
                    Apply
                </button>
            </div>
        `;

        soundList.appendChild(soundItem);
    });
}

// Play sound preview
window.playSoundPreview = function(soundUrl, buttonElement) {
    // Stop current playing audio
    if (currentPlayingAudio) {
        currentPlayingAudio.pause();
        // Reset previous button
        const prevBtn = document.querySelector('.sound-play-btn.playing');
        if (prevBtn) {
            prevBtn.classList.remove('playing');
            prevBtn.innerHTML = '<i class="fas fa-play"></i> Play';
        }
    }

    // If clicking the same button, just stop
    if (buttonElement.classList.contains('playing')) {
        buttonElement.classList.remove('playing');
        buttonElement.innerHTML = '<i class="fas fa-play"></i> Play';
        currentPlayingAudio = null;
        return;
    }

    // 🚀 استخدام الصوت المحمل مسبقاً إن وُجد
    if (preloadedAudio.has(soundUrl)) {
        currentPlayingAudio = preloadedAudio.get(soundUrl);
        currentPlayingAudio.currentTime = 0; // إعادة للبداية
    } else {
        // إنشاء صوت جديد إذا لم يكن محملاً
        currentPlayingAudio = new Audio(soundUrl);
    }

    buttonElement.classList.add('playing');
    buttonElement.innerHTML = '<i class="fas fa-pause"></i> Pause';

    currentPlayingAudio.play();

    currentPlayingAudio.onended = function() {
        buttonElement.classList.remove('playing');
        buttonElement.innerHTML = '<i class="fas fa-play"></i> Play';
        // لا نمسح currentPlayingAudio لأنه محفوظ في preloadedAudio
        currentPlayingAudio = null;
    };
};

// Apply library sound to action
window.applyLibrarySound = function(soundId, soundName, soundUrl) {
    // تطبيق على السياق الحالي
    if (currentSoundContext === 'follows') {
        // إعدادات المتابعات
        selectedFollowsLibrarySound = {
            id: soundId,
            name: soundName,
            url: soundUrl
        };
        showFollowsSelectedSound(soundName, 'مكتبة الأصوات');
    } else if (currentSoundContext === 'likes') {
        // إعدادات الإعجابات
        selectedLikesLibrarySound = {
            id: soundId,
            name: soundName,
            url: soundUrl
        };
        showLikesSelectedSound(soundName, 'مكتبة الأصوات');
    } else {
        // الإجراءات (actions) - السياق الافتراضي
        const actSoundFile = document.getElementById('actSoundFile');
        if (actSoundFile) actSoundFile.value = '';

        selectedLibrarySound = {
            id: soundId,
            name: soundName,
            url: soundUrl
        };
        showSelectedSound(soundName, 'مكتبة الأصوات');
    }

    // Close modal
    closeSoundLibrary();

    // Show success message
    showToast('✅ تم اختيار الصوت: ' + soundName, 'success');
};

// Filter sounds by search
function filterSounds(searchTerm) {
    const soundItems = document.querySelectorAll('.sound-item');
    const term = searchTerm.toLowerCase().trim();

    soundItems.forEach(item => {
        const soundName = item.dataset.soundName;
        if (soundName.includes(term)) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// ========================================
// إعدادات العرض المتقدمة
// ========================================

// متغير عام لحفظ الإعدادات المتقدمة
window.advancedDisplaySettings = null;

// فتح نافذة الإعدادات المتقدمة
function openAdvancedDisplayModal() {
    const modal = document.getElementById('advancedDisplayModal');
    if (!modal) return;

    modal.style.display = 'flex';

    // تحميل الإعدادات الحالية أو القيم الافتراضية
    if (window.advancedDisplaySettings) {
        loadAdvancedSettings(window.advancedDisplaySettings);
    } else {
        // تحميل القيم الافتراضية
        loadAdvancedSettings({
            profileImageSize: 150,
            usernameFontSize: 34,
            messageFontSize: 24,
            usernameFontFamily: 'system-ui',
            messageFontFamily: 'system-ui',
            usernameColor: '#ffffff',
            messageColor: '#ffffff',
            usernameTextShadow: true,
            messageTextShadow: true
        });
    }
}

// إغلاق نافذة الإعدادات المتقدمة
function closeAdvancedDisplayModal() {
    const modal = document.getElementById('advancedDisplayModal');
    if (!modal) return;

    modal.style.display = 'none';
}

// تحميل الإعدادات في النافذة
function loadAdvancedSettings(settings) {

    // حجم الصورة
    const profileImageSize = document.getElementById('profileImageSize');
    const profileImageSizeValue = document.getElementById('profileImageSizeValue');
    if (profileImageSize) {
        const size = settings.profileImageSize !== undefined ? settings.profileImageSize : 150;
        profileImageSize.value = size;
        if (profileImageSizeValue) {
            profileImageSizeValue.textContent = size + 'px';
        }
    }

    // حجم خط الاسم
    const usernameFontSize = document.getElementById('usernameFontSize');
    const usernameFontSizeValue = document.getElementById('usernameFontSizeValue');
    if (usernameFontSize) {
        const size = settings.usernameFontSize !== undefined ? settings.usernameFontSize : 34;
        usernameFontSize.value = size;
        if (usernameFontSizeValue) {
            usernameFontSizeValue.textContent = size + 'px';
        }
    }

    // حجم خط الرسالة
    const messageFontSize = document.getElementById('messageFontSize');
    const messageFontSizeValue = document.getElementById('messageFontSizeValue');
    if (messageFontSize) {
        const size = settings.messageFontSize !== undefined ? settings.messageFontSize : 24;
        messageFontSize.value = size;
        if (messageFontSizeValue) {
            messageFontSizeValue.textContent = size + 'px';
        }
    }

    // نوع الخط للاسم
    const usernameFontFamily = document.getElementById('usernameFontFamily');
    if (usernameFontFamily) {
        usernameFontFamily.value = settings.usernameFontFamily || 'system-ui';
    }

    // نوع الخط للرسالة
    const messageFontFamily = document.getElementById('messageFontFamily');
    if (messageFontFamily) {
        messageFontFamily.value = settings.messageFontFamily || 'system-ui';
    }

    // لون الاسم
    const usernameColor = document.getElementById('usernameColor');
    const usernameColorValue = document.getElementById('usernameColorValue');
    if (usernameColor) {
        const color = settings.usernameColor || '#ffffff';
        usernameColor.value = color;
        if (usernameColorValue) {
            usernameColorValue.textContent = color;
        }
    }

    // لون الرسالة
    const messageColor = document.getElementById('messageColor');
    const messageColorValue = document.getElementById('messageColorValue');
    if (messageColor) {
        const color = settings.messageColor || '#ffffff';
        messageColor.value = color;
        if (messageColorValue) {
            messageColorValue.textContent = color;
        }
    }

    // ظل النص للاسم
    const usernameTextShadow = document.getElementById('usernameTextShadow');
    if (usernameTextShadow) {
        usernameTextShadow.checked = settings.usernameTextShadow !== false;
    }

    // ظل النص للرسالة
    const messageTextShadow = document.getElementById('messageTextShadow');
    if (messageTextShadow) {
        messageTextShadow.checked = settings.messageTextShadow !== false;
    }
}

// حفظ الإعدادات المتقدمة
function saveAdvancedDisplaySettings() {
    window.advancedDisplaySettings = {
        profileImageSize: parseInt(document.getElementById('profileImageSize').value) || 150,
        usernameFontSize: parseInt(document.getElementById('usernameFontSize').value) || 34,
        messageFontSize: parseInt(document.getElementById('messageFontSize').value) || 24,
        usernameFontFamily: document.getElementById('usernameFontFamily').value || 'system-ui',
        messageFontFamily: document.getElementById('messageFontFamily').value || 'system-ui',
        usernameColor: document.getElementById('usernameColor').value || '#ffffff',
        messageColor: document.getElementById('messageColor').value || '#ffffff',
        usernameTextShadow: document.getElementById('usernameTextShadow').checked,
        messageTextShadow: document.getElementById('messageTextShadow').checked
    };

    //console.log('💾 تم حفظ الإعدادات المتقدمة:', window.advancedDisplaySettings);

    closeAdvancedDisplayModal();
    showToast('✅ تم حفظ الإعدادات المتقدمة', 'success');
}

// استعادة الإعدادات الافتراضية
function resetAdvancedDisplaySettings() {
    window.advancedDisplaySettings = {
        profileImageSize: 150,
        usernameFontSize: 34,
        messageFontSize: 24,
        usernameFontFamily: 'system-ui',
        messageFontFamily: 'system-ui',
        usernameColor: '#ffffff',
        messageColor: '#ffffff',
        usernameTextShadow: true,
        messageTextShadow: true
    };

    loadAdvancedSettings(window.advancedDisplaySettings);
    showToast('✅ تم استعادة الإعدادات الافتراضية', 'success');
}

// تهيئة أحداث الإعدادات المتقدمة
document.addEventListener('DOMContentLoaded', function() {
    // زر فتح الإعدادات المتقدمة
    const advancedSettingsBtn = document.getElementById('advancedSettingsBtn');
    if (advancedSettingsBtn) {
        advancedSettingsBtn.addEventListener('click', openAdvancedDisplayModal);
    }

    // زر إغلاق النافذة
    const closeAdvancedDisplayBtn = document.getElementById('closeAdvancedDisplayBtn');
    if (closeAdvancedDisplayBtn) {
        closeAdvancedDisplayBtn.addEventListener('click', closeAdvancedDisplayModal);
    }

    // زر حفظ الإعدادات
    const saveAdvancedDisplay = document.getElementById('saveAdvancedDisplay');
    if (saveAdvancedDisplay) {
        saveAdvancedDisplay.addEventListener('click', saveAdvancedDisplaySettings);
    }

    // زر استعادة الافتراضي
    const resetAdvancedDefaults = document.getElementById('resetAdvancedDefaults');
    if (resetAdvancedDefaults) {
        resetAdvancedDefaults.addEventListener('click', resetAdvancedDisplaySettings);
    }

    // تحديث القيم عند تغيير السلايدر
    const profileImageSize = document.getElementById('profileImageSize');
    if (profileImageSize) {
        profileImageSize.addEventListener('input', function() {
            document.getElementById('profileImageSizeValue').textContent = this.value + 'px';
        });
    }

    const usernameFontSize = document.getElementById('usernameFontSize');
    if (usernameFontSize) {
        usernameFontSize.addEventListener('input', function() {
            document.getElementById('usernameFontSizeValue').textContent = this.value + 'px';
        });
    }

    const messageFontSize = document.getElementById('messageFontSize');
    if (messageFontSize) {
        messageFontSize.addEventListener('input', function() {
            document.getElementById('messageFontSizeValue').textContent = this.value + 'px';
        });
    }

    // تحديث القيم عند تغيير اللون
    const usernameColor = document.getElementById('usernameColor');
    if (usernameColor) {
        usernameColor.addEventListener('input', function() {
            document.getElementById('usernameColorValue').textContent = this.value;
        });
    }

    const messageColor = document.getElementById('messageColor');
    if (messageColor) {
        messageColor.addEventListener('input', function() {
            document.getElementById('messageColorValue').textContent = this.value;
        });
    }

    // تحديث قيمة لون هدف المشاركة
    const shareGoalColorPicker = document.getElementById('shareGoalColorPicker');
    if (shareGoalColorPicker) {
        shareGoalColorPicker.addEventListener('input', function() {
            const colorValue = document.getElementById('shareGoalColorValue');
            if (colorValue) {
                colorValue.textContent = this.value;
            }
        });
    }

    // تحديث قيمة لون هدف المتابعة
    const followGoalColorPicker = document.getElementById('followGoalColorPicker');
    if (followGoalColorPicker) {
        followGoalColorPicker.addEventListener('input', function() {
            const colorValue = document.getElementById('followGoalColorValue');
            if (colorValue) {
                colorValue.textContent = this.value;
            }
        });
    }

    // تحديث قيمة لون هدف اللايكات
    const likeGoalColorPicker = document.getElementById('likeGoalColorPicker');
    if (likeGoalColorPicker) {
        likeGoalColorPicker.addEventListener('input', function() {
            const colorValue = document.getElementById('likeGoalColorValue');
            if (colorValue) {
                colorValue.textContent = this.value;
            }
        });
    }

    // إغلاق النافذة عند الضغط على الخلفية
    const advancedDisplayModal = document.getElementById('advancedDisplayModal');
    if (advancedDisplayModal) {
        advancedDisplayModal.addEventListener('click', function(e) {
            if (e.target === advancedDisplayModal) {
                closeAdvancedDisplayModal();
            }
        });
    }

    // ================================================
    // نظام Zoom للداشبورد - تصغير/تكبير تلقائي
    // ================================================
    // ================================================
    // نظام Zoom للداشبورد - تصغير/تكبير تلقائي
    // ================================================
    // ================================================
    // Dashboard Fixed Layout (Crop Only)
    // ================================================
    const dashboardContainer = document.querySelector('.dashboard-container');

    // المقاس الذي صممت عليه الداشبورد
    const BASE_WIDTH = 1720;
    const BASE_HEIGHT = 980;

    function applyFixedDashboard() {
        // ثبّت حجم الداشبورد
        dashboardContainer.style.width = BASE_WIDTH + 'px';
        dashboardContainer.style.minHeight = BASE_HEIGHT + 'px';

        // ألغِ أي zoom / scale
        dashboardContainer.style.transform = 'none';
        dashboardContainer.style.transformOrigin = 'unset';

        // خلّي القص من النافذة
        document.documentElement.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';
    }

    // طبّق مرة واحدة فقط
    applyFixedDashboard();

});


// ============================================
// 💳 Subscription Management
// ============================================

let userSubscription = null;

// جلب حالة الاشتراك
async function loadSubscriptionStatus() {
    if (!currentUser) return;

    try {
        const response = await fetch(`/api/subscription/status/${currentUser.id}`);
        const data = await response.json();

        if (data.success) {
            userSubscription = data.subscription;
            displaySubscriptionStatus(data.hasSubscription, data.subscription);
        }
    } catch (error) {
        console.error('خطأ في جلب حالة الاشتراك:', error);
    }
}

// عرض حالة الاشتراك
function displaySubscriptionStatus(hasSubscription, subscription) {
    const subscriptionSection = document.getElementById('subscription-section');
    const subscriptionStatus = document.getElementById('subscription-status');
    const pricingPlans = document.getElementById('pricing-plans');

    if (!subscriptionSection) return;

    subscriptionSection.style.display = 'block';

    if (hasSubscription && subscription) {
        // المستخدم مشترك
        subscriptionStatus.innerHTML = `
            <div class="active-subscription-display">
                <div class="active-sub-header">
                    <svg class="success-icon" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                    <h3>اشتراكك نشط</h3>
                </div>
                <div class="sub-info">
                    <div class="info-item">
                        <span class="info-label">الباقة:</span>
                        <span class="info-value">شهرية</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">تاريخ التجديد:</span>
                        <span class="info-value">
                            ${new Date(subscription.current_period_end).toLocaleDateString('ar-EG', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                            })}
                        </span>
                    </div>
                </div>
                ${subscription.cancel_at_period_end ? 
                    '<div class="warning-message"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg><span>سيتم إلغاء الاشتراك في نهاية الفترة</span></div>' : 
                    '<div class="subscription-actions"><button class="cancel-subscription-btn" onclick="cancelSubscription()">إلغاء الاشتراك</button></div>'
                }
            </div>
        `;
        subscriptionStatus.classList.add('subscription-active');
        pricingPlans.style.display = 'none';
    } else {
        // المستخدم غير مشترك - لا نعرض شيء لأن التصميم الجديد موجود في HTML
        subscriptionStatus.innerHTML = '';
        subscriptionStatus.classList.remove('subscription-active');
        pricingPlans.style.display = 'block';

        // إظهار زر محاكاة التجديد (فقط للمطورين/اختبار)
        const simulateBtn = document.getElementById('simulateRenewalBtn');
        if (simulateBtn) {
            simulateBtn.style.display = 'inline-block';
        }
    }
}

// محاكاة التجديد التلقائي - فحص وتجديد الاشتراكات المنتهية
async function simulateAutoRenewal() {
    try {
        showToast('🔄 جاري فحص الاشتراكات المنتهية...', 'info');

        const response = await fetch('/api/subscription/simulate-renewal', {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            if (data.count > 0) {
                showToast(`✅ تم تجديد ${data.count} اشتراك بنجاح!\n\n${data.renewals.map(r => 
                    `📌 حتى: ${new Date(r.new_period_end).toLocaleDateString('ar-JO')}`
                ).join('\n')}`, 'success');

                // تحديث حالة الاشتراك
                setTimeout(() => {
                    loadSubscriptionStatus();
                }, 1000);
            } else {
                showToast('ℹ️ ' + data.message, 'info');
            }
        } else {
            showToast('❌ خطأ: ' + (data.error || 'حدث خطأ غير متوقع'), 'error');
        }
    } catch (error) {
        console.error('خطأ في محاكاة التجديد:', error);
        showToast('❌ خطأ في الاتصال بالسيرفر', 'error');
    }
}

// عرض modal الاشتراك
function showSubscriptionModal() {
    const modal = document.getElementById('subscriptionModal');
    if (modal) {
        modal.style.display = 'flex';
    }
}

// إخفاء modal الاشتراك
function hideSubscriptionModal() {
    const modal = document.getElementById('subscriptionModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// ============================================
// 🎫 Promo Code Management
// ============================================

// تم إزالة نظام الخصومات - Lemon Squeezy يتولى كل شيء

// دالة فارغة للتوافق مع الكود القديم
async function applyPromoCode() {
    // لم يعد مطلوباً - تم إزالة نظام الخصومات
    return;
    const codeInput = document.getElementById('promoCodeInput');
    const code = codeInput.value.trim().toUpperCase();

    if (!code) {
        showPromoMessage('الرجاء إدخال كود الخصم', 'error');
        return;
    }

    if (!currentUser) {
        showPromoMessage('يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        showPromoMessage('جاري التحقق من الكود...', 'info');

        const response = await fetch('/api/promo/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                code: code,
                userId: currentUser.id,
                planType: 'monthly'
            })
        });

        const data = await response.json();

        if (data.success && data.valid) {
            // الكود صحيح
            appliedPromoCode = {
                code: data.promoCode.code,
                type: data.promoCode.type,
                value: data.promoCode.value,
                pricing: data.pricing
            };

            // عرض تفاصيل الخصم
            showPromoDetails(data.pricing);
            showPromoMessage('✅ تم تطبيق الكود بنجاح!', 'success');

            // تحديث السعر المعروض
            document.getElementById('displayedPrice').textContent = `$${data.pricing.finalAmountUSD}`;

        } else {
            showPromoMessage(data.error || 'كود غير صحيح', 'error');
            appliedPromoCode = null;
        }

    } catch (error) {
        console.error('خطأ في تطبيق الكود:', error);
        showPromoMessage('خطأ في التحقق من الكود', 'error');
        appliedPromoCode = null;
    }
}

// دوال الخصومات تم إزالتها بالكامل - Lemon Squeezy يتولى كل شيء
function removePromoCode() { /* تم الإزالة */ }

function showPromoDetails() { /* تم الإزالة */ }

function showPromoMessage() { /* تم الإزالة */ }

function applyModalPromoCode() { /* تم الإزالة */ }

function removeModalPromoCode() { /* تم الإزالة */ }

function showModalPromoDetails() { /* تم الإزالة */ }

function showModalPromoMessage() { /* تم الإزالة */ }

// نهاية دوال الخصومات المحذوفة

// تم حذف جميع دوال الخصومات والـ Stripe بنجاح
// التطبيق الآن يستخدم Lemon Squeezy فقط

// إلغاء الاشتراك
async function cancelSubscription() {
    const codeInput = document.getElementById('modalPromoCodeInput');
    const code = codeInput.value.trim().toUpperCase();

    if (!code) {
        showModalPromoMessage('الرجاء إدخال كود الخصم', 'error');
        return;
    }

    if (!currentUser) {
        showModalPromoMessage('يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        showModalPromoMessage('جاري التحقق من الكود...', 'info');

        const response = await fetch('/api/promo/validate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                code: code,
                userId: currentUser.id,
                planType: 'monthly'
            })
        });

        const data = await response.json();

        if (data.success && data.valid) {
            // الكود صحيح
            modalAppliedPromoCode = {
                code: data.promoCode.code,
                type: data.promoCode.type,
                value: data.promoCode.value,
                pricing: data.pricing
            };
            showModalPromoMessage('✅ تم تطبيق الكود بنجاح!', 'success');
            showModalPromoDetails(data.pricing);
            document.getElementById('modalDisplayedPrice').textContent = `$${data.pricing.finalAmountUSD}`;
        } else {
            showModalPromoMessage(data.error || 'كود غير صحيح', 'error');
            modalAppliedPromoCode = null;
        }
    } catch (error) {
        console.error('خطأ في التحقق من كود الخصم:', error);
        showModalPromoMessage('خطأ في التحقق من الكود', 'error');
        modalAppliedPromoCode = null;
    }
}

// إزالة كود الخصم من Modal
function removeModalPromoCode() {
    modalAppliedPromoCode = null;
    document.getElementById('modalPromoCodeInput').value = '';
    document.getElementById('modalPromoDetails').style.display = 'none';
    showModalPromoMessage('', '');
    document.getElementById('modalDisplayedPrice').textContent = '$9.99';
    showModalPromoMessage('تم إزالة الكود', 'info');
    setTimeout(() => {
        showModalPromoMessage('', '');
    }, 2000);
}

// عرض تفاصيل الخصم في Modal
function showModalPromoDetails(pricing) {
    document.getElementById('modalBasePrice').textContent = `$${pricing.baseAmountUSD}`;
    document.getElementById('modalDiscountAmount').textContent = `-$${pricing.discountUSD}`;
    document.getElementById('modalFinalPrice').textContent = `$${pricing.finalAmountUSD}`;
    document.getElementById('modalPromoDetails').style.display = 'block';
}

// عرض رسالة كود الخصم في Modal
function showModalPromoMessage(message, type) {
    const messageDiv = document.getElementById('modalPromoMessage');

    if (!message) {
        messageDiv.style.display = 'none';
        messageDiv.className = 'modal-promo-message';
        return;
    }

    messageDiv.style.display = 'block';
    messageDiv.className = `modal-promo-message ${type}`;
    messageDiv.textContent = message;
}

// Redirect إلى صفحة الدفع (Lemon Squeezy أو Ko-fi حسب الإعدادات)
async function createCheckoutSession(planType) {
    if (!currentUser) {
        showToast('يجب تسجيل الدخول أولاً');
        return;
    }

    try {
        // التحقق من وضع الدفع (Ko-fi أو Lemon Squeezy)
        const response = await fetch('/api/subscription/payment-mode');
        const data = await response.json();

        if (data.useKofi) {
            // وضع Ko-fi المؤقت: حفظ بيانات المستخدم وتحويل للصفحة

            // حفظ البريد الإلكتروني في sessionStorage لعرضه في صفحة Ko-fi
            sessionStorage.setItem('user', JSON.stringify({
                email: currentUser.email,
                id: currentUser.id
            }));

            showToast('جاري تحويلك إلى صفحة الدفع المؤقتة...', 'info');

            // التحويل لصفحة Ko-fi المؤقتة
            setTimeout(() => {
                window.location.href = '/ko-fi-payment.html';
            }, 800);
        } else {
            // وضع Lemon Squeezy الطبيعي

            const LEMON_SQUEEZY_CHECKOUT_URL = 'https://tikoverlay.lemonsqueezy.com/buy/49571be7-be88-4464-9038-4e2472cad91b';

            showToast('جاري تحويلك إلى صفحة الدفع...', 'info');

            // ✅ (1) تمرير البريد الإلكتروني الصحيح للمستخدم المسجل
            // ✅ (2) تمرير user_id (UUID) في custom metadata لربط الاشتراك في Webhook
            const checkoutUrl = new URL(LEMON_SQUEEZY_CHECKOUT_URL);

            // تعبئة حقل البريد الإلكتروني تلقائيًا في صفحة الدفع
            checkoutUrl.searchParams.set('checkout[email]', currentUser.email);

            // ✅ إرسال supabase_user_id في custom metadata (مهم جدًا)
            // هذا هو المصدر الوحيد الموثوق لربط الاشتراك بالمستخدم
            checkoutUrl.searchParams.set('checkout[custom][supabase_user_id]', currentUser.id);

            // التوجيه المباشر إلى Lemon Squeezy
            window.location.href = checkoutUrl.toString();
        }
    } catch (error) {
        console.error('❌ خطأ في تحديد وضع الدفع:', error);
        showToast('حدث خطأ في تحديد وضع الدفع. يرجى المحاولة لاحقاً.', 'error');
    }
}

// إلغاء الاشتراك
async function cancelSubscription() {
    if (!confirm('هل أنت متأكد من إلغاء الاشتراك؟ سيستمر حتى نهاية الفترة المدفوعة.')) {
        return;
    }

    try {
        const response = await fetch('/api/subscription/cancel', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('تم إلغاء الاشتراك بنجاح. سيستمر حتى: ' + new Date(data.expires_at).toLocaleDateString('ar-EG'), 'success');
        } else {
            showToast('خطأ: ' + data.error, 'error');
        }
    } catch (error) {
        console.error('خطأ في إلغاء الاشتراك:', error);
        showToast('خطأ في إلغاء الاشتراك', 'error');
    }
}

// ==================== دوال إعدادات الهدف ====================

// فتح نافذة إعدادات الهدف
async function openGoalSettings() {
    document.getElementById('goalSettingsModal').style.display = 'flex';
    await loadGoalSettings();
}

// إغلاق نافذة إعدادات الهدف
function closeGoalSettings() {
    document.getElementById('goalSettingsModal').style.display = 'none';
}

// تحميل إعدادات الهدف من السيرفر
async function loadGoalSettings() {
    try {
        if (!widgetToken) {
            console.error('لا يوجد توكن');
            return;
        }

        const response = await fetch(`/api/widget/goal-settings/${widgetToken}`);

        if (response.ok) {
            const settings = await response.json();
            document.getElementById('goalValueInput').value = settings.goal_value || 50;
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات الهدف:', error);
    }
}

// حفظ إعدادات الهدف
async function saveGoalSettings() {
    const goalValue = parseInt(document.getElementById('goalValueInput').value);

    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    if (isNaN(goalValue) || goalValue < 1) {
        showToast('❌ يجب إدخال قيمة صحيحة للهدف', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/goal-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                goal_value: goalValue
            })
        });

        if (response.ok) {
            // إغلاق النافذة
            closeGoalSettings();

            // تحديث الـ iframe
            const iframe = document.getElementById('heartMeGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'updateGoal',
                    goalValue: goalValue
                }, '*');
            }

            // إرسال التحديث عبر Socket.io
            if (window.socket && window.socket.connected) {
                window.socket.emit('updateGoalSettings', {
                    token: widgetToken,
                    goal_value: goalValue
                });
            }
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات الهدف:', error);
        showToast('❌ حدث خطأ في حفظ الإعدادات', 'error');
    }
}

// اختبار الهدف
async function testHeartMeGoal() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/test-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken
            })
        });

        if (response.ok) {} else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في اختبار الهدف'), 'error');
        }
    } catch (error) {
        console.error('خطأ في اختبار الهدف:', error);
        showToast('❌ حدث خطأ في اختبار الهدف', 'error');
    }
}

// إعادة تعيين قيمة الهدف الحالية
// إعدادات هدف المتابعة
function openFollowGoalSettings() {
    const modal = document.getElementById('followGoalSettingsModal');
    if (modal) {
        modal.style.display = 'flex';
        loadFollowGoalSettings();
    }
}

function closeFollowGoalSettings() {
    const modal = document.getElementById('followGoalSettingsModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function loadFollowGoalSettings() {
    if (!widgetToken) return;

    try {
        const response = await fetch(`/api/widget/follow-goal-settings/${widgetToken}`);
        if (response.ok) {
            const data = await response.json();
            const input = document.getElementById('followGoalValueInput');
            if (input) {
                input.value = data.follow_goal_value || 100;
            }

            // تحميل اللون
            const colorPicker = document.getElementById('followGoalColorPicker');
            const colorValue = document.getElementById('followGoalColorValue');
            if (colorPicker && data.follow_goal_color) {
                colorPicker.value = data.follow_goal_color;
                if (colorValue) {
                    colorValue.textContent = data.follow_goal_color;
                }
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات هدف المتابعة:', error);
    }
}

async function saveFollowGoalSettings() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'warning');
        return;
    }

    const goalValue = parseInt(document.getElementById('followGoalValueInput').value);
    const goalColor = document.getElementById('followGoalColorPicker').value;

    if (isNaN(goalValue) || goalValue < 1) {
        showToast('⚠️ يرجى إدخال قيمة صحيحة للهدف', 'warning');
        return;
    }

    try {
        const response = await fetch('/api/widget/follow-goal-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                follow_goal_value: goalValue,
                follow_goal_color: goalColor
            })
        });

        if (response.ok) {
            closeFollowGoalSettings();

            const iframe = document.getElementById('followGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'updateGoal',
                    goalValue: goalValue,
                    goalColor: goalColor
                }, '*');
            }

            if (window.socket && window.socket.connected) {
                window.socket.emit('updateFollowGoalSettings', {
                    token: widgetToken,
                    goal_value: goalValue,
                    goal_color: goalColor
                });
            }
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات هدف المتابعة:', error);
        showToast('❌ حدث خطأ في حفظ الإعدادات', 'error');
    }
}

async function testFollowGoal() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/test-follow-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken
            })
        });

        if (response.ok) {} else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في اختبار الهدف'), 'error');
        }
    } catch (error) {
        console.error('خطأ في اختبار هدف المتابعة:', error);
        showToast('❌ حدث خطأ في اختبار الهدف', 'error');
    }
}

async function resetFollowGoal() {
    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/reset-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                goal_type: 'follow_goal'
            })
        });

        if (response.ok) {
            const iframe = document.getElementById('followGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'resetGoal'
                }, '*');
            }

            if (window.socket && window.socket.connected) {
                window.socket.emit('resetGoal', {
                    token: widgetToken,
                    goal_type: 'follow_goal'
                });
            }

            showToast('✅ تم إعادة تعيين هدف المتابعة', 'success');
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إعادة التعيين'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إعادة تعيين هدف المتابعة:', error);
        showToast('❌ حدث خطأ في إعادة التعيين', 'error');
    }
}

// ============================================
// وظائف Share Goal
// ============================================

function openShareGoalSettings() {
    const modal = document.getElementById('shareGoalSettingsModal');
    if (modal) {
        modal.style.display = 'flex';
        loadShareGoalSettings();
    }
}

function closeShareGoalSettings() {
    const modal = document.getElementById('shareGoalSettingsModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function loadShareGoalSettings() {
    if (!widgetToken) return;

    try {
        const response = await fetch(`/api/widget/share-goal-settings/${widgetToken}`);
        if (response.ok) {
            const data = await response.json();
            const input = document.getElementById('shareGoalValueInput');
            if (input) {
                input.value = data.share_goal_value || 100;
            }

            // تحميل اللون
            const colorPicker = document.getElementById('shareGoalColorPicker');
            const colorValue = document.getElementById('shareGoalColorValue');
            if (colorPicker && data.share_goal_color) {
                colorPicker.value = data.share_goal_color;
                if (colorValue) {
                    colorValue.textContent = data.share_goal_color;
                }
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات هدف المشاركة:', error);
    }
}

async function saveShareGoalSettings() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'warning');
        return;
    }

    const goalValue = parseInt(document.getElementById('shareGoalValueInput').value);
    const goalColor = document.getElementById('shareGoalColorPicker').value;

    if (isNaN(goalValue) || goalValue < 1) {
        showToast('⚠️ يرجى إدخال قيمة صحيحة للهدف', 'warning');
        return;
    }

    try {
        const response = await fetch('/api/widget/share-goal-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                share_goal_value: goalValue,
                share_goal_color: goalColor
            })
        });

        if (response.ok) {
            closeShareGoalSettings();

            const iframe = document.getElementById('shareGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'updateGoal',
                    goalValue: goalValue,
                    goalColor: goalColor
                }, '*');
            }

            if (window.socket && window.socket.connected) {
                window.socket.emit('updateShareGoalSettings', {
                    token: widgetToken,
                    goal_value: goalValue,
                    goal_color: goalColor
                });
            }
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات هدف المشاركة:', error);
        showToast('❌ حدث خطأ في حفظ الإعدادات', 'error');
    }
}

async function testShareGoal() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/test-share-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken
            })
        });

        if (response.ok) {} else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في اختبار الهدف'), 'error');
        }
    } catch (error) {
        console.error('خطأ في اختبار هدف المشاركة:', error);
        showToast('❌ حدث خطأ في اختبار الهدف', 'error');
    }
}

async function resetShareGoal() {
    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/reset-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                goal_type: 'share_goal'
            })
        });

        if (response.ok) {
            const iframe = document.getElementById('shareGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'resetGoal'
                }, '*');
            }

            if (window.socket && window.socket.connected) {
                window.socket.emit('resetGoal', {
                    token: widgetToken,
                    goal_type: 'share_goal'
                });
            }

            showToast('✅ تم إعادة تعيين هدف المشاركة', 'success');
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إعادة التعيين'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إعادة تعيين هدف المشاركة:', error);
        showToast('❌ حدث خطأ في إعادة التعيين', 'error');
    }
}

// ============================================
// وظائف Like Goal
// ============================================

async function testLikeGoal() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/test-like-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken
            })
        });

        if (response.ok) {} else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في اختبار الهدف'), 'error');
        }
    } catch (error) {
        console.error('خطأ في اختبار هدف اللايكات:', error);
        showToast('❌ حدث خطأ في اختبار الهدف', 'error');
    }
}

async function resetLikeGoal() {
    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/reset-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                goal_type: 'like_goal'
            })
        });

        if (response.ok) {
            const iframe = document.getElementById('likeGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'resetGoal'
                }, '*');
            }

            if (window.socket && window.socket.connected) {
                window.socket.emit('resetGoal', {
                    token: widgetToken,
                    goal_type: 'like_goal'
                });
            }

            showToast('✅ تم إعادة تعيين هدف اللايكات', 'success');
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إعادة التعيين'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إعادة تعيين هدف اللايكات:', error);
        showToast('❌ حدث خطأ في إعادة التعيين', 'error');
    }
}

// إعدادات هدف اللايكات (Like Goal)
function openLikeGoalSettings() {
    const modal = document.getElementById('likeGoalSettingsModal');
    if (modal) {
        modal.style.display = 'flex';
        loadLikeGoalSettings();
    }
}

function closeLikeGoalSettings() {
    const modal = document.getElementById('likeGoalSettingsModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function loadLikeGoalSettings() {
    if (!widgetToken) return;

    try {
        const response = await fetch(`/api/widget/like-goal-value?token=${widgetToken}`);
        if (response.ok) {
            const data = await response.json();
            const input = document.getElementById('likeGoalValueInput');
            if (input) {
                input.value = data.like_goal_value || 100;
            }

            // تحميل اللون
            const colorPicker = document.getElementById('likeGoalColorPicker');
            const colorValue = document.getElementById('likeGoalColorValue');
            if (colorPicker && data.like_goal_color) {
                colorPicker.value = data.like_goal_color;
                if (colorValue) {
                    colorValue.textContent = data.like_goal_color;
                }
            }
        }
    } catch (error) {
        console.error('خطأ في تحميل إعدادات هدف اللايكات:', error);
    }
}

async function saveLikeGoalSettings() {
    if (!widgetToken) {
        showToast('⚠️ يرجى تسجيل الدخول أولاً', 'warning');
        return;
    }

    const goalValue = parseInt(document.getElementById('likeGoalValueInput').value);
    const goalColor = document.getElementById('likeGoalColorPicker').value;

    if (isNaN(goalValue) || goalValue < 1) {
        showToast('⚠️ يرجى إدخال قيمة صحيحة للهدف', 'warning');
        return;
    }

    try {
        const response = await fetch('/api/widget/like-goal-value', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                like_goal_value: goalValue,
                like_goal_color: goalColor
            })
        });

        if (response.ok) {
            closeLikeGoalSettings();

            // تحديث الـ iframe
            const iframe = document.getElementById('likeGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'updateGoal',
                    goalValue: goalValue,
                    goalColor: goalColor
                }, '*');
            }

            // إرسال التحديث عبر Socket
            if (window.socket && window.socket.connected) {
                window.socket.emit('updateLikeGoalSettings', {
                    token: widgetToken,
                    goal_value: goalValue,
                    goal_color: goalColor
                });
            }

            showToast('✅ تم حفظ إعدادات هدف اللايكات', 'success');
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('خطأ في حفظ إعدادات هدف اللايكات:', error);
        showToast('❌ حدث خطأ في حفظ الإعدادات', 'error');
    }
}

async function resetHeartMeGoal() {
    if (!widgetToken) {
        showToast('❌ يجب تسجيل الدخول أولاً', 'error');
        return;
    }

    try {
        const response = await fetch('/api/widget/reset-goal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                goal_type: 'heart_me_goal'
            })
        });

        if (response.ok) {
            // تحديث الـ iframe
            const iframe = document.getElementById('heartMeGoalPreview');
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.postMessage({
                    type: 'resetGoal'
                }, '*');
            }

            // إرسال التحديث عبر Socket.io
            if (window.socket && window.socket.connected) {
                window.socket.emit('resetGoal', {
                    token: widgetToken,
                    goal_type: 'heart_me_goal'
                });
            }

            showToast('✅ تم إعادة تعيين الهدف بنجاح', 'success');
        } else {
            const errorData = await response.json();
            showToast('❌ ' + (errorData.error || 'فشل في إعادة التعيين'), 'error');
        }
    } catch (error) {
        console.error('خطأ في إعادة تعيين الهدف:', error);
        showToast('❌ حدث خطأ في إعادة التعيين', 'error');
    }
}

// ============================================
// 🔊 دوال TTS (Text-to-Speech)
// ============================================

// تحميل إعدادات TTS
async function loadTTSSettings() {
    try {
        // استخدام widgetToken بدلاً من localStorage
        if (!widgetToken) {
            return;
        }

        // 💾 تحميل فوري من localStorage
        const cachedEnabled = localStorage.getItem('tts_enabled');
        const cachedVolume = localStorage.getItem('tts_volume');
        const cachedRate = localStorage.getItem('tts_rate');
        const cachedFilterMode = localStorage.getItem('tts_filter_mode');
        const cachedAllowedUsers = localStorage.getItem('tts_allowed_usernames');

        const enabledCheckbox = document.getElementById('ttsEnabled');
        const volumeSlider = document.getElementById('ttsVolume');
        const rateSlider = document.getElementById('ttsRate');
        const filterModeSelect = document.getElementById('ttsFilterMode');
        const allowedUsernamesTextarea = document.getElementById('ttsAllowedUsernames');

        // 🆕 تعريف عناصر الفلاتر
        const filterModeratorsCheckbox = document.getElementById('ttsFilterModerators');
        const filterSubscribersCheckbox = document.getElementById('ttsFilterSubscribers');
        const filterFollowersCheckbox = document.getElementById('ttsFilterFollowers');
        const filterSpecificCheckbox = document.getElementById('ttsFilterSpecific');
        const filterAllCheckbox = document.getElementById('ttsFilterAll');

        if (cachedEnabled !== null && enabledCheckbox) {
            enabledCheckbox.checked = cachedEnabled === 'true';
        }
        if (cachedVolume !== null && volumeSlider) {
            volumeSlider.value = parseFloat(cachedVolume);
            updateTTSVolumeDisplay();
        }
        if (cachedRate !== null && rateSlider) {
            rateSlider.value = parseFloat(cachedRate);
            updateTTSRateDisplay();
        }
        if (cachedFilterMode !== null && filterModeSelect) {
            filterModeSelect.value = cachedFilterMode;
        }
        if (cachedAllowedUsers !== null && allowedUsernamesTextarea) {
            allowedUsernamesTextarea.value = cachedAllowedUsers;
        }
        toggleAllowedUsersBox();

        const response = await fetch(`/api/tts/settings?token=${widgetToken}`);
        const data = await response.json();

        if (data.success && data.settings) {
            const settings = data.settings;

            // تطبيق الإعدادات على النموذج
            if (enabledCheckbox) {
                enabledCheckbox.checked = Boolean(settings.enabled);
                localStorage.setItem('tts_enabled', enabledCheckbox.checked); // 💾 حفظ
            }
            if (volumeSlider) {
                volumeSlider.value = (settings.volume || 1) * 100;
                localStorage.setItem('tts_volume', volumeSlider.value); // 💾 حفظ
            }
            if (rateSlider) {
                rateSlider.value = settings.rate || 1;
                localStorage.setItem('tts_rate', rateSlider.value); // 💾 حفظ
            }

            // إعدادات التصفية
            if (filterModeratorsCheckbox) {
                filterModeratorsCheckbox.checked = Boolean(settings.filter_moderators);
            }
            if (filterSubscribersCheckbox) {
                filterSubscribersCheckbox.checked = Boolean(settings.filter_subscribers);
            }
            if (filterFollowersCheckbox) {
                filterFollowersCheckbox.checked = Boolean(settings.filter_followers);
            }
            if (filterSpecificCheckbox) {
                filterSpecificCheckbox.checked = settings.filter_mode === 'specific';
            }
            // تحديد "جميع التعليقات" إذا لم يكن هناك أي فلتر مفعل
            if (filterAllCheckbox) {
                const hasActiveFilter = Boolean(settings.filter_moderators) ||
                    Boolean(settings.filter_subscribers) ||
                    Boolean(settings.filter_followers) ||
                    (settings.filter_mode === 'specific');
                filterAllCheckbox.checked = !hasActiveFilter;
            }
            if (allowedUsernamesTextarea) {
                allowedUsernamesTextarea.value = settings.allowed_usernames || '';
                localStorage.setItem('tts_allowed_usernames', allowedUsernamesTextarea.value); // 💾 حفظ
            }

            // إظهار/إخفاء صندوق الأسماء
            toggleAllowedUsersBox();

            // تحديث العرض
            updateTTSVolumeDisplay();
            updateTTSRateDisplay();
        } else {}
    } catch (error) {
        console.error('Error loading TTS settings:', error);
    }
}

// حفظ إعدادات TTS
async function saveTTSSettings() {
    try {
        // استخدام widgetToken بدلاً من localStorage
        if (!widgetToken) {
            showToast('❌ الرجاء تسجيل الدخول أولاً', 'error');
            return;
        }

        const enabledCheckbox = document.getElementById('ttsEnabled');
        const volumeSlider = document.getElementById('ttsVolume');
        const rateSlider = document.getElementById('ttsRate');

        // 🆕 فلاتر الصلاحيات (checkboxes)
        const filterModeratorsCheckbox = document.getElementById('ttsFilterModerators');
        const filterSubscribersCheckbox = document.getElementById('ttsFilterSubscribers');
        const filterFollowersCheckbox = document.getElementById('ttsFilterFollowers');
        const filterSpecificCheckbox = document.getElementById('ttsFilterSpecific');
        const allowedUsernamesTextarea = document.getElementById('ttsAllowedUsernames');

        const settings = {
            enabled: Boolean(enabledCheckbox ? .checked),
            auto_play: true, // دائماً تشغيل تلقائي
            volume: volumeSlider ? parseFloat(volumeSlider.value) / 100 : 1.0,
            rate: rateSlider ? parseFloat(rateSlider.value) : 1.0,
            voice: 'ar-SA-ZariyahNeural', // صوت عربي ثابت
            // 🆕 فلاتر الصلاحيات
            filter_moderators: Boolean(filterModeratorsCheckbox ? .checked),
            filter_subscribers: Boolean(filterSubscribersCheckbox ? .checked),
            filter_followers: Boolean(filterFollowersCheckbox ? .checked),
            // الفلتر القديم (مستخدمين محددين)
            filter_mode: filterSpecificCheckbox ? .checked ? 'specific' : 'all',
            allowed_usernames: allowedUsernamesTextarea ? .value ? .trim() || null
        };

        const response = await fetch('/api/tts/settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                settings: settings
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('✅ تم حفظ الإعدادات بنجاح', 'success');

            // إرسال التحديثات مباشرة لصفحة TTS عبر socket
            if (socket && socket.connected) {
                socket.emit('updateTTSSettings', {
                    token: widgetToken,
                    settings: settings
                });
            }
        } else {
            showToast('❌ ' + (data.error || 'فشل حفظ الإعدادات'), 'error');
        }
    } catch (error) {
        console.error('Error saving TTS settings:', error);
        showToast('❌ حدث خطأ أثناء حفظ الإعدادات', 'error');
    }
}

// 🆕 معالجة تغيير فلاتر TTS
function handleTTSFilterChange() {
    const filterAll = document.getElementById('ttsFilterAll');
    const filterModerators = document.getElementById('ttsFilterModerators');
    const filterSubscribers = document.getElementById('ttsFilterSubscribers');
    const filterFollowers = document.getElementById('ttsFilterFollowers');
    const filterSpecific = document.getElementById('ttsFilterSpecific');
    const allowedUsersContainer = document.getElementById('allowedUsersContainer');

    // إذا تم تحديد "جميع التعليقات"، إلغاء تحديد البقية
    if (filterAll ? .checked) {
        if (filterModerators) filterModerators.checked = false;
        if (filterSubscribers) filterSubscribers.checked = false;
        if (filterFollowers) filterFollowers.checked = false;
        if (filterSpecific) filterSpecific.checked = false;
    } else {
        // إذا تم تحديد أي فلتر آخر، إلغاء تحديد "جميع التعليقات"
        if (filterModerators ? .checked || filterSubscribers ? .checked ||
            filterFollowers ? .checked || filterSpecific ? .checked) {
            if (filterAll) filterAll.checked = false;
        }
    }

    // إظهار/إخفاء صندوق المستخدمين المحددين
    if (allowedUsersContainer) {
        allowedUsersContainer.style.display = filterSpecific ? .checked ? 'block' : 'none';
    }

    // حفظ الإعدادات تلقائياً
    saveTTSSettings();
}

// إظهار/إخفاء صندوق الأسماء المسموح لهم (للتوافق مع الكود القديم)
function toggleAllowedUsersBox() {
    const filterSpecific = document.getElementById('ttsFilterSpecific');
    const allowedUsersContainer = document.getElementById('allowedUsersContainer');

    if (filterSpecific && allowedUsersContainer) {
        allowedUsersContainer.style.display = filterSpecific.checked ? 'block' : 'none';
    }
}

// تحديث عرض مستوى الصوت
function updateTTSVolumeDisplay() {
    const volumeSlider = document.getElementById('ttsVolume');
    const volumeDisplay = document.getElementById('ttsVolumeDisplay');
    if (volumeSlider && volumeDisplay) {
        volumeDisplay.textContent = `${volumeSlider.value}%`;
        localStorage.setItem('tts_volume', volumeSlider.value); // 💾 حفظ فوري
    }
}

// تحديث عرض سرعة القراءة (الآن slider بدلاً من select)
function updateTTSRateDisplay() {
    const rateSlider = document.getElementById('ttsRate');
    const rateDisplay = document.getElementById('ttsRateDisplay');
    if (rateSlider && rateDisplay) {
        const value = parseFloat(rateSlider.value);
        rateDisplay.textContent = `${value.toFixed(1)}x`;
        localStorage.setItem('tts_rate', rateSlider.value); // 💾 حفظ فوري
    }
}

// اختبار الصوت
async function testTTSVoice() {
    try {
        // استخدام widgetToken بدلاً من localStorage
        if (!widgetToken) {
            showToast('❌ الرجاء تسجيل الدخول أولاً', 'error');
            return;
        }

        const rateSlider = document.getElementById('ttsRate');
        const volumeSlider = document.getElementById('ttsVolume');

        const testText = 'مرحباً! هذا اختبار للصوت. نتمنى أن تكون جودة الصوت مناسبة لك.';
        const voice = 'ar-SA-ZariyahNeural'; // صوت عربي ثابت
        const rate = rateSlider ? parseFloat(rateSlider.value) : 1.0;
        const volume = volumeSlider ? parseFloat(volumeSlider.value) / 100 : 1.0;

        showToast('⏳ جاري اختبار الصوت...', 'info');

        const response = await fetch('/api/tts/convert', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: widgetToken,
                text: testText,
                voice: voice,
                rate: rate,
                volume: volume
            })
        });

        const data = await response.json();

        if (data.success && data.audioUrl) {
            // تشغيل الصوت
            const audio = new Audio(data.audioUrl);
            audio.volume = volume;
            await audio.play();

            showToast('🎵 يتم تشغيل الصوت الآن...', 'success');
        } else {
            showToast('❌ ' + (data.error || 'فشل اختبار الصوت'), 'error');
        }
    } catch (error) {
        console.error('Error testing TTS voice:', error);
        showToast('❌ حدث خطأ أثناء اختبار الصوت', 'error');
    }
}


// ========================================
// 🤖 Bot Actions Management
// ========================================

let botActions = [];
let editingBotActionId = null;

// تحميل إجراءات البوت
async function loadBotActions() {
    if (!currentUser) return;

    try {
        const response = await fetch(`/api/bot-actions/${currentUser.id}`);
        const data = await response.json();

        if (data.success) {
            botActions = data.actions;
            renderBotActions();
        }
    } catch (error) {
        console.error('Error loading bot actions:', error);
    }
}

// عرض إجراءات البوت
function renderBotActions() {
    const container = document.getElementById('botActionsList');
    const emptyState = document.getElementById('botActionsEmptyState');

    if (!container) return;

    if (botActions.length === 0) {
        container.innerHTML = '';
        if (emptyState) emptyState.style.display = 'block';
        return;
    }

    if (emptyState) emptyState.style.display = 'none';

    const eventIcons = {
        follow: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>`,
        gift: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 12 20 22 4 22 4 12"></polyline>
                <rect x="2" y="7" width="20" height="5"></rect>
                <line x1="12" y1="22" x2="12" y2="7"></line>
                <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path>
                <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path>
            </svg>`,
        comment: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>`,
        join: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                <polyline points="10 17 15 12 10 7"></polyline>
                <line x1="15" y1="12" x2="3" y2="12"></line>
            </svg>`
    };

    const eventNames = {
        follow: 'متابعة',
        gift: 'هدية',
        comment: 'تعليق',
        join: 'انضمام'
    };

    const conditionLabels = {
        none: 'بدون شرط',
        keyword: 'كلمة مفتاحية',
        gift_name: 'هدية محددة',
        min_diamonds: 'حد أدنى للألماس'
    };

    container.innerHTML = botActions.map(action => {
        let conditionBadge = '';
        if (action.condition_type !== 'none' && action.condition_value) {
            conditionBadge = `
                <div style="display: inline-flex; align-items: center; gap: 6px; padding: 5px 10px; background: rgba(102, 126, 234, 0.15); border: 1px solid rgba(102, 126, 234, 0.3); border-radius: 6px; font-size: 12px; margin-top: 8px;">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                    <span>${conditionLabels[action.condition_type]}: <strong>${action.condition_value}</strong></span>
                </div>
            `;
        }

        return `
            <div class="bot-action-item" style="position: relative;">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px;">
                    <div style="flex: 1;">
                        <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 14px; background: linear-gradient(135deg, rgba(102, 126, 234, 0.2) 0%, rgba(118, 75, 162, 0.2) 100%); border: 1px solid rgba(102, 126, 234, 0.4); border-radius: 20px; font-size: 13px; font-weight: 600; color: #667eea;">
                            ${eventIcons[action.event_type]}
                            <span>${eventNames[action.event_type]}</span>
                        </div>
                        ${conditionBadge}
                    </div>
                    <div style="display: flex; gap: 8px; align-items: center;">
                        <label class="toggle-switch" style="position: relative; display: inline-block; width: 44px; height: 24px;">
                            <input type="checkbox" ${action.is_active ? 'checked' : ''} onchange="toggleBotAction(${action.id}, ${action.is_active})" style="opacity: 0; width: 0; height: 0;">
                            <span style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: ${action.is_active ? 'rgba(76, 175, 80, 0.3)' : 'rgba(100, 100, 100, 0.3)'}; border: 2px solid ${action.is_active ? '#4CAF50' : '#555'}; transition: .3s; border-radius: 24px; display: flex; align-items: center; padding: 2px;">
                                <span style="position: absolute; height: 16px; width: 16px; right: ${action.is_active ? '22px' : '2px'}; background: ${action.is_active ? '#4CAF50' : '#888'}; transition: .3s; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"></span>
                            </span>
                        </label>
                        <button onclick="deleteBotAction(${action.id})" style="padding: 6px 10px; background: rgba(231, 76, 60, 0.15); border: 1px solid rgba(231, 76, 60, 0.4); color: #e74c3c; border-radius: 6px; cursor: pointer; font-size: 12px; transition: all 0.3s ease; display: flex; align-items: center; gap: 4px;" onmouseover="this.style.background='rgba(231, 76, 60, 0.25)'; this.style.borderColor='rgba(231, 76, 60, 0.6)';" onmouseout="this.style.background='rgba(231, 76, 60, 0.15)'; this.style.borderColor='rgba(231, 76, 60, 0.4)';">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                            <span>حذف</span>
                        </button>
                    </div>
                </div>
                <div style="padding: 12px; background: rgba(76, 175, 80, 0.08); border-right: 3px solid #4CAF50; border-radius: 8px;">
                    <div style="display: flex; align-items: start; gap: 8px; color: #cbd5e0; font-size: 14px; line-height: 1.6;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink: 0; margin-top: 2px;">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                        <span>${action.response_message}</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// فتح نافذة إضافة إجراء بوت
function openAddBotActionModal() {
    editingBotActionId = null;
    const popup = document.getElementById('botActionPopup');
    const title = document.getElementById('botActionPopupTitle');

    if (popup) popup.style.display = 'flex';
    if (title) title.textContent = 'إنشاء إجراء بوت جديد 🤖';

    // إعادة تعيين جميع الـ checkboxes
    document.querySelectorAll('input[name="botTriggerType"]').forEach(cb => cb.checked = false);

    // إخفاء جميع الخيارات الفرعية
    document.querySelectorAll('.trigger-sub-options').forEach(el => el.style.display = 'none');

    // إعادة تعيين رسالة الرد
    document.getElementById('botResponseMessage').value = '';

    // إعادة تعيين حقول الخيارات الفرعية
    const minValueInput = document.getElementById('botActMinValue');
    const commentKeywordInput = document.getElementById('botCommentKeyword');
    if (minValueInput) minValueInput.value = '100';
    if (commentKeywordInput) commentKeywordInput.value = '';

    // إعادة تعيين gift selector
    const botGiftSelect = document.getElementById('botActGiftSelect');
    if (botGiftSelect) botGiftSelect.value = '';
    const botGiftPreview = document.getElementById('botGiftPreview');
    if (botGiftPreview) botGiftPreview.style.display = 'none';
}

// إغلاق نافذة إجراء البوت
function closeBotActionModal() {
    const popup = document.getElementById('botActionPopup');
    if (popup) popup.style.display = 'none';
}

// تهيئة event listeners لـ bot action trigger checkboxes
function initializeBotTriggerCheckboxes() {
    const triggerCheckboxes = document.querySelectorAll('input[name="botTriggerType"]');

    triggerCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            // إذا تم تحديد هذا الـ checkbox، ألغِ تحديد البقية
            if (this.checked) {
                triggerCheckboxes.forEach(cb => {
                    if (cb !== this) cb.checked = false;
                });
            }

            // إخفاء جميع الخيارات الفرعية أولاً
            document.querySelectorAll('.trigger-sub-options').forEach(el => el.style.display = 'none');

            // إظهار الخيارات الفرعية للحدث المحدد
            if (this.checked) {
                const triggerValue = this.value;
                let subOptionsId = '';

                if (triggerValue === 'specific_gift') subOptionsId = 'botSpecificGiftOptions';
                else if (triggerValue === 'min_diamonds') subOptionsId = 'botMinDiamondsOptions';
                else if (triggerValue === 'comment') subOptionsId = 'botCommentOptions';
                else if (triggerValue === 'follow') subOptionsId = 'botFollowOptions';
                else if (triggerValue === 'join') subOptionsId = 'botJoinOptions';

                const subOptions = document.getElementById(subOptionsId);
                if (subOptions) subOptions.style.display = 'block';
            }
        });
    });
}

// حفظ إجراء البوت
async function saveBotAction() {
    // الحصول على نوع الحدث المحدد
    const selectedCheckbox = document.querySelector('input[name="botTriggerType"]:checked');
    if (!selectedCheckbox) {
        showToast('يجب اختيار نوع الحدث', 'error');
        return;
    }

    const triggerValue = selectedCheckbox.value;
    const responseMessage = document.getElementById('botResponseMessage').value;

    if (!responseMessage) {
        showToast('يجب إدخال رسالة الرد', 'error');
        return;
    }

    let eventType = '';
    let conditionType = 'none';
    let conditionValue = null;

    // تحديد event_type و condition بناءً على trigger type
    if (triggerValue === 'specific_gift') {
        eventType = 'gift';
        const giftSelect = document.getElementById('botActGiftSelect');
        if (giftSelect && giftSelect.value) {
            conditionType = 'gift_name';
            conditionValue = giftSelect.value;
        } else {
            showToast('يجب اختيار هدية محددة', 'error');
            return;
        }
    } else if (triggerValue === 'min_diamonds') {
        eventType = 'gift';
        const minValue = document.getElementById('botActMinValue') ? .value ? .trim();
        if (minValue && parseInt(minValue) > 0) {
            conditionType = 'min_diamonds';
            conditionValue = minValue;
        } else {
            showToast('يجب إدخال قيمة الحد الأدنى للألماسات', 'error');
            return;
        }
    } else if (triggerValue === 'comment') {
        eventType = 'comment';
        const keyword = document.getElementById('botCommentKeyword') ? .value ? .trim();
        if (keyword) {
            conditionType = 'keyword';
            conditionValue = keyword;
        }
    } else if (triggerValue === 'follow') {
        eventType = 'follow';
    } else if (triggerValue === 'join') {
        eventType = 'join';
    }

    // إضافة nickname تلقائياً في بداية الرسالة إذا لم تكن موجودة
    let finalMessage = responseMessage.trim();
    if (!finalMessage.includes('{nickname}')) {
        finalMessage = '@{nickname} ' + finalMessage;
    }

    // 🛡️ التحقق من التكرار (Duplicate Check)
    const isDuplicate = botActions.some(action => {
        // تجاهل الإجراء الحالي إذا كنا في وضع التعديل (editingBotActionId)
        if (editingBotActionId && action.id === editingBotActionId) return false;

        // 1. التحقق من نوع الحدث
        if (action.event_type !== eventType) return false;

        // 2. التحقق حسب النوع
        if (eventType === 'follow' || eventType === 'join') {
            // لا يسمح بتكرار follow أو join
            return true;
        } else if (eventType === 'gift') {
            // التحقق من الشرط (هدية محددة أو حد أدنى)
            if (action.condition_type !== conditionType) return false;

            // إذا كان نفس الشرط، تحقق من القيمة
            if (conditionType === 'gift_name') {
                return action.condition_value === conditionValue;
            } else if (conditionType === 'min_diamonds') {
                return parseInt(action.condition_value) === parseInt(conditionValue);
            }
        } else if (eventType === 'comment') {
            // التحقق من الكلمة المفتاحية
            if (action.condition_type !== conditionType) return false;
            return action.condition_value.toLowerCase() === conditionValue.toLowerCase();
        }

        return false;
    });

    if (isDuplicate) {
        let errorMsg = 'هذا الإجراء موجود بالفعل!';
        if (eventType === 'follow') errorMsg = 'يوجد بالفعل إجراء لحدث المتابعة';
        else if (eventType === 'join') errorMsg = 'يوجد بالفعل إجراء لحدث الانضمام';
        else if (eventType === 'gift' && conditionType === 'gift_name') errorMsg = `يوجد بالفعل إجراء لهذه الهدية (${conditionValue})`;
        else if (eventType === 'gift' && conditionType === 'min_diamonds') errorMsg = `يوجد بالفعل إجراء لهذا الحد الأدنى (${conditionValue})`;
        else if (eventType === 'comment') errorMsg = `يوجد بالفعل إجراء لهذه الكلمة المفتاحية (${conditionValue})`;

        showToast(`⚠️ ${errorMsg}`, 'error');
        return;
    }

    try {
        const response = await fetch(`/api/bot-actions/${currentUser.id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                event_type: eventType,
                condition_type: conditionType,
                condition_value: conditionValue,
                response_message: finalMessage
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('✅ تم حفظ الإجراء بنجاح', 'success');
            closeBotActionModal();
            loadBotActions();
        } else {
            showToast('❌ خطأ: ' + data.error, 'error');
        }
    } catch (error) {
        console.error('Error saving bot action:', error);
        showToast('❌ حدث خطأ أثناء الحفظ', 'error');
    }
}

// تفعيل/تعطيل إجراء البوت
async function toggleBotAction(actionId, currentStatus) {
    try {
        const response = await fetch(`/api/bot-actions/${currentUser.id}/${actionId}/toggle`, {
            method: 'PATCH'
        });

        const data = await response.json();

        if (data.success) {
            loadBotActions();
            showToast(data.action.is_active ? '✅ تم تفعيل الإجراء' : '⏸️ تم تعطيل الإجراء', 'success');
        }
    } catch (error) {
        console.error('Error toggling bot action:', error);
        showToast('❌ حدث خطأ', 'error');
    }
}

// حذف إجراء البوت
async function deleteBotAction(actionId) {
    // استخدم نافذة التأكيد المخصصة إن كانت متوفرة
    try {
        const confirmed = await showCustomConfirm('حذف الإجراء', 'هل أنت متأكد من حذف هذا الإجراء؟', 'حذف', '⚠️');

        if (!confirmed) return;

        const response = await fetch(`/api/bot-actions/${currentUser.id}/${actionId}`, {
            method: 'DELETE'
        });

        const data = await response.json();

        if (data.success) {
            showToast('🗑️ تم حذف الإجراء', 'success');
            loadBotActions();
        }
    } catch (error) {
        console.error('Error deleting bot action:', error);
        showToast('❌ حدث خطأ أثناء الحذف', 'error');
    }
}

// تهيئة أحداث البوت
function initializeBotActionsEvents() {
    const addBtn = document.getElementById('addBotActionBtn');
    const closeBtn = document.getElementById('closeBotActionPopupBtn');
    const saveBtn = document.getElementById('saveBotActionBtn');
    const cancelBtn = document.getElementById('cancelBotActionBtn');

    if (addBtn) {
        addBtn.addEventListener('click', openAddBotActionModal);
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', closeBotActionModal);
    }

    if (saveBtn) {
        saveBtn.addEventListener('click', saveBotAction);
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeBotActionModal);
    }

    // تهيئة checkboxes للـ triggers
    initializeBotTriggerCheckboxes();

    // تهيئة Bot Gift Selector
    initializeBotGiftSelector();

    // تحميل الإجراءات عند تحميل الصفحة
    if (currentUser) {
        loadBotActions();
    }
}

// تهيئة أحداث البوت عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        initializeBotActionsEvents();
    }, 500);

    // معالجات نافذة الاشتراك
    initializeSubscriptionModal();
});

// معالجات نافذة الاشتراك
function initializeSubscriptionModal() {
    // زر إغلاق النافذة
    const closeBtn = document.querySelector('.close-subscription-modal');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            hideSubscriptionModal();
        });
    }

    // زر "اشترك الآن"
    const subscribeBtn = document.querySelector('.subscribe-btn-new');
    if (subscribeBtn) {
        subscribeBtn.addEventListener('click', () => {
            // توجيه المستخدم إلى صفحة الدفع
            window.open('/ko-fi-payment.html', '_blank');
        });
    }

    // إغلاق النافذة عند النقر خارجها
    const modal = document.getElementById('subscriptionModal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                hideSubscriptionModal();
            }
        });
    }
}

// ==========================================
// Social Media Rotator Functions
// ==========================================


// ==========================================
// Social Media Rotator Functions
// ==========================================

const ALL_PLATFORMS = [{
        id: 'ig',
        label: 'FOLLOW ME',
        icon: 'fa-instagram',
        color: '#E1306C',
        name: 'Instagram'
    },
    {
        id: 'tk',
        label: 'WATCH MORE',
        icon: 'fa-tiktok',
        color: '#00F2EA',
        name: 'TikTok'
    },
    {
        id: 'yt',
        label: 'SUBSCRIBE',
        icon: 'fa-youtube',
        color: '#FF0000',
        name: 'YouTube'
    },
    {
        id: 'fb',
        label: 'LIKE PAGE',
        icon: 'fa-facebook',
        color: '#1877F2',
        name: 'Facebook'
    },
    {
        id: 'tw',
        label: 'FOLLOW ME',
        icon: 'fa-twitter',
        color: '#1DA1F2',
        name: 'Twitter'
    },
    {
        id: 'sc',
        label: 'ADD ME',
        icon: 'fa-snapchat',
        color: '#FFFC00',
        name: 'Snapchat'
    },
    {
        id: 'twitch',
        label: 'WATCH LIVE',
        icon: 'fa-twitch',
        color: '#9146FF',
        name: 'Twitch'
    },
    {
        id: 'discord',
        label: 'JOIN SERVER',
        icon: 'fa-discord',
        color: '#5865F2',
        name: 'Discord'
    },
    {
        id: 'linkedin',
        label: 'CONNECT',
        icon: 'fa-linkedin',
        color: '#0A66C2',
        name: 'LinkedIn'
    },
    {
        id: 'pinterest',
        label: 'FOLLOW',
        icon: 'fa-pinterest',
        color: '#E60023',
        name: 'Pinterest'
    },
    {
        id: 'reddit',
        label: 'FOLLOW',
        icon: 'fa-reddit',
        color: '#FF4500',
        name: 'Reddit'
    },
    {
        id: 'telegram',
        label: 'JOIN',
        icon: 'fa-telegram',
        color: '#0088cc',
        name: 'Telegram'
    },
    {
        id: 'whatsapp',
        label: 'MESSAGE',
        icon: 'fa-whatsapp',
        color: '#25D366',
        name: 'WhatsApp'
    },
    {
        id: 'kick',
        label: 'WATCH LIVE',
        icon: 'fa-kickstarter',
        color: '#53FC18',
        name: 'Kick'
    }
];

// Initialize Social Rotator Page
async function initializeSocialRotatorPage() {

    // If data is not ready, wait for it using the event system
    if (!currentUser || !widgetToken) {

        // Create a promise that resolves when data is ready
        await new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error('Timeout waiting for user data'));
            }, 10000); // 10 second timeout

            onUserDataReady(() => {
                clearTimeout(timeoutId);
                resolve();
            });
        }).catch(err => {
            console.error('❌ Failed to load social-rotator:', err);
            const loadingDiv = document.querySelector('#social-rotator-page .loading');
            if (loadingDiv) {
                loadingDiv.innerHTML = '<p>❌ فشل تحميل البيانات. حاول تسجيل الدخول مرة أخرى.</p>';
            }
            return;
        });
    }

    // Set the widget URL
    const socialRotatorUrl = `${window.location.origin}/widget/social-rotator?token=${widgetToken}`;
    const urlElement = document.getElementById('socialRotatorUrl');
    if (urlElement) {
        urlElement.textContent = socialRotatorUrl;
    }

    // Load preview
    const previewIframe = document.getElementById('socialRotatorPreview');
    if (previewIframe) {
        previewIframe.src = socialRotatorUrl;
    }

    // Load settings (for the modal when opened later)
    await loadSocialRotatorSettings();
}

// Load Social Rotator Settings
async function loadSocialRotatorSettings() {
    if (!widgetToken) {
        return;
    }

    try {
        const response = await fetch(`/api/social-rotator/settings?token=${widgetToken}`);
        if (response.ok) {
            const data = await response.json();
            window.socialRotatorSettings = data.settings || {
                platforms: {}
            };
        } else {
            console.error('❌ Failed to load settings:', response.status);
        }
    } catch (error) {
        console.error('❌ Error loading social rotator settings:', error);
    }
}

// Open Social Rotator Settings Modal
function openSocialRotatorSettings() {
    const modal = document.getElementById('socialRotatorSettingsModal');
    modal.style.display = 'flex';
    buildPlatformList();
}

// Close Social Rotator Settings Modal
function closeSocialRotatorSettings() {
    const modal = document.getElementById('socialRotatorSettingsModal');
    modal.style.display = 'none';
}

// Build Platform List in Settings Modal
function buildPlatformList() {
    const settings = window.socialRotatorSettings || {
        platforms: {}
    };
    const container = document.getElementById('platformList');

    container.innerHTML = ALL_PLATFORMS.map(platform => {
        const platformSettings = settings.platforms[platform.id] || {
            enabled: false,
            username: ''
        };

        return `
            <div class="platform-item">
                <div class="platform-header">
                    <input type="checkbox" 
                           class="platform-checkbox" 
                           data-id="${platform.id}"
                           ${platformSettings.enabled ? 'checked' : ''}
                           onchange="togglePlatformInput('${platform.id}')">
                    <i class="fa-brands ${platform.icon} platform-icon" style="color: ${platform.color}"></i>
                    <span class="platform-name">${platform.name}</span>
                </div>
                <input type="text" 
                       class="platform-input" 
                       data-id="${platform.id}"
                       placeholder="أدخل اسم المستخدم أو الرابط"
                       value="${platformSettings.username || ''}"
                       ${!platformSettings.enabled ? 'disabled' : ''}>
            </div>
        `;
    }).join('');
}

// Toggle Platform Input
function togglePlatformInput(platformId) {
    const checkbox = document.querySelector(`.platform-checkbox[data-id="${platformId}"]`);
    const input = document.querySelector(`.platform-input[data-id="${platformId}"]`);
    input.disabled = !checkbox.checked;
}

// Save Social Rotator Settings
async function saveSocialRotatorSettings() {
    if (!widgetToken) {
        showToast('⚠️ لم يتم العثور على توكن الويدجت', 'error');
        return;
    }

    try {
        const settings = {
            platforms: {}
        };

        ALL_PLATFORMS.forEach(platform => {
            const checkbox = document.querySelector(`.platform-checkbox[data-id="${platform.id}"]`);
            const input = document.querySelector(`.platform-input[data-id="${platform.id}"]`);

            settings.platforms[platform.id] = {
                enabled: checkbox.checked,
                username: input.value.trim()
            };
        });

        const response = await fetch(`/api/social-rotator/settings?token=${widgetToken}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                settings
            })
        });

        if (response.ok) {
            window.socialRotatorSettings = settings;
            showToast('✅ تم حفظ الإعدادات بنجاح', 'success');
            closeSocialRotatorSettings();

            // Reload preview
            const previewIframe = document.getElementById('socialRotatorPreview');
            previewIframe.src = previewIframe.src; // Force reload
        } else {
            showToast('❌ فشل حفظ الإعدادات', 'error');
        }
    } catch (error) {
        console.error('Error saving social rotator settings:', error);
        showToast('❌ حدث خطأ أثناء الحفظ', 'error');
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    const modal = document.getElementById('socialRotatorSettingsModal');
    if (e.target === modal) {
        closeSocialRotatorSettings();
    }
});

// Close modal on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const modal = document.getElementById('socialRotatorSettingsModal');
        if (modal && modal.style.display === 'flex') {
            closeSocialRotatorSettings();
        }
    }
});